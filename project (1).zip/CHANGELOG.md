# تغییرات

## 0.2.0
- خواننده کاشی کالیبرهشده برای «بازم بازی» (`ocr/TileReader.kt`) با ۱۸۱ نمونه واقعی حرف و ۱۸۴ نمونه عدد (`assets/ocr/`).
- پیدا کردن خودکار ۱۶ کاشی چوبی در کل اسکرینشات (`WoodTileFinder`)، حذف سرصفحه چوبی، بازسازی کاشیهای بریدهشده.
- عدد گوشه حالا «امتیاز حرف» نامیده میشود؛ امتیاز کلمه = جمع امتیاز کاشیها (مطابق بازی: قانع=۶، مخلف=۶).
- فرهنگ لغت پیشفرض: ۱۰٬۵۹۶ کلمه رایج.
- Gradle Wrapper کامل (gradlew، gradlew.bat، gradle-wrapper.jar) اضافه شد.
- اصلاح importهای rememberSaveable و API سطح ۳۰ در ScreenCaptureService.

## 0.1.2
- ScreenCaptureService: listener هر فریم را با acquireLatestImage میگیرد و فریم قبلی را میبندد. فقط آخرین فریم نگه داشته میشود تا صف ImageReader پر نشود.
- setupDisplay: اول surface جدید روی VirtualDisplay قرار میگیرد، بعد reader قدیمی (و فریم کششدهاش) بسته میشود.
- ساخت OverlayController داخل try/catch (BadTokenException و SecurityException). در صورت خطا، پیام به کاربر و توقف سرویس. افزودن بقیه پنجرهها هم امن شد.
- آیکون واقعی برای دکمه «توقف» در اعلان.
- اندازه صفحه از WindowManager مربوط به Display واقعی (window context تازه) خوانده میشود. تغییرات با DisplayListener دنبال میشوند.
- فریم کاملاً سیاه (FLAG_SECURE) → CaptureResult.Blocked و پیام «این بازی اجازهٔ ضبط صفحه نمیدهد».
- FrameView به فایل جداگانه scanner/FrameView.kt منتقل شد.

## 0.1.1
- وارد کردن فرهنگ لغت: خواندن فایل از UI به `ScanPipeline.importUris` روی `Dispatchers.IO` منتقل شد. نشانگر پیشرفت (فایل n از m) اضافه شد و دکمهها هنگام وارد کردن غیرفعال میشوند.
- تشخیص خودکار کدگذاری: BOM (UTF-8/UTF-16)، UTF-8 سختگیرانه، و در غیر این صورت Windows-1256 (`TextDecoding` + تست).
- اسلایدرهای تنظیمات فقط در `onValueChangeFinished` ذخیره میکنند (`CommitSlider`). تنظیمات حالا ماندگارند (JSON در SharedPreferences).
- پروفایل و امتیاز حروف فقط با دکمه «ثبت» اعمال میشوند. نام پروفایل پاکسازی میشود و با پروفایل کادر شناور همگام است.
- دیالوگ تأیید برای پاک کردن نمونههای یادگرفته.
- صفحه اسکن کاملاً اسکرولشونده (LazyColumn) با `imePadding` و چیدمان ستونی برای عرض کمتر از 360dp. دیالوگ اصلاح خانه اسکرولشونده با حداکثر ۷۵٪ ارتفاع.
- وضعیت مجوز نمایش روی برنامهها در `onResume` بهروز میشود.
- README: توضیح صادقانه معماری واقعی (تکماژوله، DI دستی، ذخیره JSON/فایل).
- ScreenCaptureService: بازسازی VirtualDisplay بعد از چرخش صفحه، جلوگیری از گرفتن فریم قدیمی، بستن امن سرویس.
