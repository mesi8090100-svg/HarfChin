package ir.harfchin.dictionary

import ir.harfchin.solver.Trie
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File

@Serializable
data class DictionaryInfo(
    val id: String,
    val name: String,
    val fileName: String,
    val sizeBytes: Long,
    val wordCount: Int,
    val enabled: Boolean = true,
    val builtIn: Boolean = false
)

/**
 * ذخیره فرهنگ لغت‌ها در حافظه داخلی برنامه: هر فرهنگ لغت یک فایل متنی نرمال‌شده (یک کلمه در هر خط)
 * و یک فایل index.json برای اطلاعات. هیچ منبعی بدون فراخوانی صریح importText (یعنی انتخاب کاربر) اضافه نمی‌شود.
 */
class DictionaryRepository(private val baseDir: File) {
    private val json = Json { prettyPrint = true; ignoreUnknownKeys = true }
    private val dir = File(baseDir, "dictionaries").apply { mkdirs() }
    private val indexFile = File(dir, "index.json")
    @Volatile private var cachedTrie: Trie? = null
    @Volatile private var cacheKey: String? = null

    @Synchronized
    fun list(): List<DictionaryInfo> =
        if (indexFile.exists()) json.decodeFromString(indexFile.readText()) else emptyList()

    @Synchronized
    private fun save(items: List<DictionaryInfo>) {
        indexFile.writeText(json.encodeToString(items))
        cacheKey = null
    }

    /** فقط با انتخاب کاربر (یا نصب فرهنگ پیش‌فرض همراه برنامه در اولین اجرا) فراخوانی می‌شود. */
    @Synchronized
    fun importText(name: String, sourceFileName: String, text: String, builtIn: Boolean = false): DictionaryInfo {
        val words = DictionaryParser.parse(text, DictionaryParser.detect(sourceFileName))
        require(words.isNotEmpty()) { "هیچ کلمه فارسی معتبری در فایل پیدا نشد" }
        val id = System.currentTimeMillis().toString(36) + (0..999).random()
        val f = File(dir, "$id.txt")
        f.writeText(words.joinToString("\n"))
        val info = DictionaryInfo(id, name, sourceFileName, text.toByteArray().size.toLong(), words.size, true, builtIn)
        save(list() + info)
        return info
    }

    fun setEnabled(id: String, enabled: Boolean) = save(list().map { if (it.id == id) it.copy(enabled = enabled) else it })

    fun rename(id: String, name: String) = save(list().map { if (it.id == id) it.copy(name = name) else it })

    @Synchronized
    fun delete(id: String) {
        File(dir, "$id.txt").delete()
        save(list().filterNot { it.id == id })
    }

    fun words(id: String): Sequence<String> = File(dir, "$id.txt").takeIf { it.exists() }
        ?.readLines()?.asSequence() ?: emptySequence()

    /** Trie ترکیبی از همه فرهنگ لغت‌های فعال؛ تا تغییر منابع در حافظه می‌ماند. */
    fun activeTrie(): Trie {
        val active = list().filter { it.enabled }
        val key = active.joinToString { it.id }
        cachedTrie?.let { if (key == cacheKey) return it }
        val t = Trie()
        active.forEach { d -> words(d.id).forEach(t::insert) }
        cachedTrie = t; cacheKey = key
        return t
    }
}
