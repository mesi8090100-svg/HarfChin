package ir.harfchin.core.model

/** یک کاشی جدول. letter خالی یعنی هنوز مشخص نشده. */
data class Tile(
    val letter: String,
    val multiplier: Int = 1,
    val confidence: Float = 1f,
    val alternatives: List<String> = emptyList(),
    /** true یعنی OCR مطمئن نبوده و کاربر باید تأیید کند */
    val needsReview: Boolean = false
)

data class Grid(val tiles: List<Tile>) {
    init { require(tiles.size == SIZE * SIZE) { "Grid must have 16 tiles" } }

    val isComplete: Boolean get() = tiles.all { it.letter.isNotEmpty() }

    fun with(index: Int, tile: Tile) = Grid(tiles.toMutableList().also { it[index] = tile })

    companion object {
        const val SIZE = 4
        fun empty() = Grid(List(16) { Tile("") })
        /** ساخت سریع از رشته ۱۶ حرفی (ردیف به ردیف، از چپ به راست) */
        fun of(letters: String, multipliers: IntArray = IntArray(16) { 1 }): Grid {
            require(letters.length == 16)
            return Grid(letters.mapIndexed { i, c -> Tile(c.toString(), multipliers[i]) })
        }
    }
}

/** path: اندیس خانه‌ها (۰ تا ۱۵، ردیف*۴+ستون) به ترتیب تشکیل کلمه */
data class FoundWord(
    val word: String,
    val path: List<Int>,
    val score: Int,
    val usesUncertainTile: Boolean = false
)

enum class MultiplierMode { LETTER, WORD }
