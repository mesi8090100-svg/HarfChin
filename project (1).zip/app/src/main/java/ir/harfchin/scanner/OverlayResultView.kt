package ir.harfchin.scanner

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import ir.harfchin.core.PersianNormalizer
import ir.harfchin.pipeline.ScanPipeline
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

/** پنل نتیجه داخل پنجره شناور: جدول (لمس = اصلاح)، دکمه حل، فهرست کلمات (لمس = نمایش مسیر) */
@SuppressLint("ViewConstructor")
class OverlayResultView(ctx: Context, private val pipeline: ScanPipeline, onClose: () -> Unit) : LinearLayout(ctx) {
    private val gridView = GridLayout(ctx).apply { columnCount = 4; layoutDirection = View.LAYOUT_DIRECTION_LTR }
    private val list = LinearLayout(ctx).apply { orientation = VERTICAL }
    private val status = TextView(ctx).apply { setTextColor(Color.DKGRAY) }
    private var job: Job? = null
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    init {
        orientation = VERTICAL; setBackgroundColor(Color.parseColor("#FAF6EE")); setPadding(dp(10), dp(8), dp(10), dp(8))
        layoutDirection = View.LAYOUT_DIRECTION_RTL
        val top = LinearLayout(ctx).apply { orientation = HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        top.addView(Button(ctx).apply { text = "حل"; setOnClickListener { pipeline.solve() } })
        top.addView(Button(ctx).apply { text = "بستن"; setOnClickListener { onClose() } })
        top.addView(status, LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f))
        addView(top)
        val body = LinearLayout(ctx).apply { orientation = HORIZONTAL }
        body.addView(gridView, LayoutParams(dp(176), LayoutParams.WRAP_CONTENT))
        body.addView(ScrollView(ctx).apply { addView(list) }, LayoutParams(0, LayoutParams.MATCH_PARENT, 1f))
        addView(body, LayoutParams(LayoutParams.MATCH_PARENT, 0, 1f))
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        job = CoroutineScope(Dispatchers.Main).launch { pipeline.state.collect { render() } }
    }

    override fun onDetachedFromWindow() { job?.cancel(); super.onDetachedFromWindow() }

    private fun render() {
        val s = pipeline.state.value
        status.text = if (s.busy) "در حال پردازش…" else s.message ?: ""
        gridView.removeAllViews()
        val sel = s.selectedWord?.path.orEmpty()
        s.grid.tiles.forEachIndexed { i, t ->
            gridView.addView(TextView(context).apply {
                text = (t.letter.ifEmpty { "؟" }) + if (t.multiplier > 1) "·${t.multiplier}" else ""
                textSize = 20f; gravity = Gravity.CENTER
                setBackgroundColor(when {
                    i in sel -> Color.parseColor("#7CB342")
                    t.needsReview -> Color.parseColor("#FFD54F")
                    else -> Color.parseColor("#E8D3A8")
                })
                setOnClickListener { pick(i) }
            }, GridLayout.LayoutParams().apply { width = dp(40); height = dp(40); setMargins(dp(2), dp(2), dp(2), dp(2)) })
        }
        list.removeAllViews()
        s.words.take(200).forEach { w ->
            list.addView(TextView(context).apply {
                text = "${w.word}   (${w.word.length} حرف، ${w.score} امتیاز)"
                textSize = 17f; setPadding(dp(6), dp(6), dp(6), dp(6))
                if (w == s.selectedWord) setBackgroundColor(Color.parseColor("#DCEDC8"))
                setOnClickListener { pipeline.select(w) }
            })
        }
    }

    /** انتخاب حرف: ابتدا گزینه‌های پیشنهادی OCR، سپس کل الفبا */
    private fun pick(i: Int) {
        val t = pipeline.state.value.grid.tiles[i]
        val letters = (t.alternatives + PersianNormalizer.TILE_LETTERS).distinct()
        list.removeAllViews()
        list.addView(TextView(context).apply { text = "حرف خانه ${i + 1} را انتخاب کنید:" })
        val g = GridLayout(context).apply { columnCount = 7 }
        letters.forEach { l ->
            g.addView(Button(context).apply {
                text = l; textSize = 16f
                if (l in t.alternatives) setBackgroundColor(Color.parseColor("#FFE082"))
                setOnClickListener { pipeline.setTile(i, l) }
            }, GridLayout.LayoutParams().apply { width = dp(44); height = dp(44) })
        }
        listOf(1, 2, 3).forEach { m ->
            g.addView(Button(context).apply { text = "$m"; setOnClickListener { pipeline.setTile(i, t.letter, m) } },
                GridLayout.LayoutParams().apply { width = dp(44); height = dp(44) })
        }
        list.addView(g)
    }
}
