package ir.harfchin.scanner

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.text.InputType
import ir.harfchin.HarfChinApp
import kotlin.math.abs
import kotlin.math.max

/**
 * پنجره‌های شناور روی بازی:
 *  ۱. حباب کوچک «اسکن» (قابل جابه‌جایی)
 *  ۲. کادر ۴×۴ قابل جابه‌جایی و تغییر اندازه از ۴ گوشه + ورود عددی ابعاد + ذخیره برای پروفایل
 *  ۳. پنل نتیجه (جدول و کلمات) — بدون خروج از بازی
 */
class OverlayController(private val service: ScreenCaptureService) {
    private val ctx: Context = service
    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val store = FrameProfileStore(ctx)
    private var bubble: View? = null
    private var frame: FrameView? = null
    private var toolbar: View? = null
    private var result: View? = null
    private val type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY

    /** افزودن امن پنجره؛ اگر مجوز overlay وسط کار لغو شده باشد، سرویس متوقف میشود */
    private fun safeAdd(v: View, lp: WindowManager.LayoutParams): Boolean = try {
        wm.addView(v, lp); true
    } catch (e: WindowManager.BadTokenException) {
        stopForMissingPermission(); false
    } catch (e: SecurityException) {
        stopForMissingPermission(); false
    }

    private fun stopForMissingPermission() {
        android.widget.Toast.makeText(ctx, "مجوز «نمایش روی برنامهها» لغو شده است", android.widget.Toast.LENGTH_LONG).show()
        service.stopSelf()
    }

    private fun dp(v: Int) = (v * ctx.resources.displayMetrics.density).toInt()

    @SuppressLint("ClickableViewAccessibility")
    fun showBubble() {
        val b = TextView(ctx).apply {
            text = "اسکن"; setTextColor(Color.WHITE); textSize = 14f; gravity = Gravity.CENTER
            setBackgroundColor(Color.parseColor("#CC8D5A2B")); setPadding(dp(14), dp(10), dp(14), dp(10))
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = dp(8); y = dp(160) }
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
        b.setOnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    if (abs(e.rawX - sx) + abs(e.rawY - sy) > dp(6)) moved = true
                    lp.x = ox + (e.rawX - sx).toInt(); lp.y = oy + (e.rawY - sy).toInt(); wm.updateViewLayout(v, lp)
                }
                MotionEvent.ACTION_UP -> if (!moved) toggleFrame()
            }
            true
        }
        wm.addView(b, lp); bubble = b
    }

    private fun toggleFrame() { if (frame != null) hideFrame() else showFrame() }

    private fun currentProfile() = store.lastProfile

    private fun showFrame() {
        result?.let { runCatching { wm.removeView(it) } }; result = null
        val w = service.screenW.takeIf { it > 0 } ?: ctx.resources.displayMetrics.widthPixels
        val h = service.screenH.takeIf { it > 0 } ?: ctx.resources.displayMetrics.heightPixels
        val rect = store.load(currentProfile(), w, h) ?: store.default(w, h)
        val fv = FrameView(ctx, rect, dp(26))
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }
        if (!safeAdd(fv, lp)) return; frame = fv
        showToolbar(w, h)
    }

    private fun showToolbar(sw: Int, sh: Int) {
        val bar = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL; setBackgroundColor(Color.parseColor("#EE222222"))
            setPadding(dp(6), dp(4), dp(6), dp(4)); layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        fun btn(t: String, f: () -> Unit) = Button(ctx).apply { text = t; textSize = 13f; setOnClickListener { f() } }
        bar.addView(btn("گرفتن") { captureNow(sw, sh) })
        bar.addView(btn("ذخیره کادر") { frame?.let { store.save(currentProfile(), sw, sh, it.rect) } })
        bar.addView(btn("ابعاد") { showSizeDialog() })
        bar.addView(btn("بستن") { hideFrame() })
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL; y = dp(24) }
        if (safeAdd(bar, lp)) toolbar = bar
    }

    /** ورود دقیق x / y / عرض / ارتفاع (پیکسل) */
    private fun showSizeDialog() {
        val fv = frame ?: return
        val box = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.WHITE); setPadding(dp(12), dp(12), dp(12), dp(12))
        }
        fun field(hint: String, v: Int) = EditText(ctx).apply {
            this.hint = hint; setText(v.toString()); inputType = InputType.TYPE_CLASS_NUMBER
        }.also { box.addView(it) }
        val r = fv.rect
        val fx = field("X", r.x); val fy = field("Y", r.y); val fw = field("عرض", r.width); val fh = field("ارتفاع", r.height)
        val lp = WindowManager.LayoutParams(
            dp(240), WindowManager.LayoutParams.WRAP_CONTENT, type, 0, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.CENTER }
        box.addView(Button(ctx).apply {
            text = "اعمال"
            setOnClickListener {
                fun v(e: EditText, d: Int) = e.text.toString().toIntOrNull() ?: d
                fv.rect = FrameRect(v(fx, r.x), v(fy, r.y), max(40, v(fw, r.width)), max(40, v(fh, r.height)))
                fv.invalidate(); wm.removeView(box)
            }
        })
        safeAdd(box, lp)
    }

    private fun captureNow(sw: Int, sh: Int) {
        val fv = frame ?: return
        val rect = fv.rect
        store.save(currentProfile(), sw, sh, rect)   // آخرین موقعیت همیشه به‌خاطر سپرده می‌شود
        // مخفی کردن موقت همه پنجره‌ها تا در عکس نیفتند
        listOfNotNull(fv, toolbar, bubble).forEach { it.visibility = View.INVISIBLE }
        service.capture(rect) { res ->
            listOfNotNull(toolbar, bubble).forEach { it.visibility = View.VISIBLE }
            hideFrame()
            when (res) {
                is CaptureResult.Success -> {
                    val app = ctx.applicationContext as HarfChinApp
                    app.pipeline.processCapture(res.bitmap, currentProfile())
                    showResult()
                }
                CaptureResult.Blocked -> showMessage("این بازی اجازهٔ ضبط صفحه نمیدهد")
                is CaptureResult.Failed -> showMessage("گرفتن تصویر ناموفق بود: ${res.reason}")
            }
        }
    }

    private fun showMessage(m: String) {
        val t = TextView(ctx).apply { text = m; setBackgroundColor(Color.parseColor("#EE333333")); setTextColor(Color.WHITE); setPadding(dp(12), dp(8), dp(12), dp(8)) }
        val lp = WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT).apply { gravity = Gravity.CENTER }
        if (safeAdd(t, lp)) t.postDelayed({ runCatching { wm.removeView(t) } }, 2200)
    }

    private fun showResult() {
        result?.let { runCatching { wm.removeView(it) } }
        val v = OverlayResultView(ctx, (ctx.applicationContext as HarfChinApp).pipeline) {
            result?.let { runCatching { wm.removeView(it) } }; result = null
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, (service.screenH * 0.55f).toInt().coerceAtLeast(dp(360)), type,
            0, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.BOTTOM }
        if (safeAdd(v, lp)) result = v
    }

    private fun hideFrame() {
        frame?.let { wm.removeView(it) }; frame = null
        toolbar?.let { wm.removeView(it) }; toolbar = null
    }

    fun dismissAll() {
        hideFrame()
        listOfNotNull(bubble, result).forEach { runCatching { wm.removeView(it) } }
        bubble = null; result = null
    }
}

