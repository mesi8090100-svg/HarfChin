package ir.harfchin.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Wood = Color(0xFF8D5A2B)
val TileColor = Color(0xFFEBD7AE)
val Unsure = Color(0xFFFFD54F)
val PathColor = Color(0xFF7CB342)

@Composable
fun HarfChinTheme(content: @Composable () -> Unit) = MaterialTheme(
    colorScheme = lightColorScheme(primary = Wood, secondary = Color(0xFF5D4037), background = Color(0xFFFAF6EE)),
    content = content
)
