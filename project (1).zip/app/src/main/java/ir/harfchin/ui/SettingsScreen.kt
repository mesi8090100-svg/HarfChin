package ir.harfchin.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ir.harfchin.core.model.MultiplierMode
import ir.harfchin.pipeline.ScanPipeline
import ir.harfchin.pipeline.UiState

@Composable
fun SettingsScreen(pipeline: ScanPipeline, state: UiState) {
    val s = state.settings
    var confirmClear by remember { mutableStateOf(false) }
    var profileText by remember(s.profile) { mutableStateOf(s.profile) }

    Column(
        Modifier.fillMaxSize().imePadding().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("کلمات", fontSize = 18.sp)
        CommitSlider(s.minLength.toFloat(), 2f..6f, steps = 3, label = { "حداقل طول کلمه: ${it.toInt()}" }) { v ->
            pipeline.updateSettings { it.copy(minLength = v.toInt()) }
        }

        Text("نحوه حساب امتیاز", fontSize = 18.sp)
        Row(verticalAlignment = Alignment.CenterVertically) {
            RadioButton(s.multiplierMode == MultiplierMode.LETTER, { pipeline.updateSettings { it.copy(multiplierMode = MultiplierMode.LETTER) } })
            Text("جمع امتیاز کاشیها (این بازی)")
            RadioButton(s.multiplierMode == MultiplierMode.WORD, { pipeline.updateSettings { it.copy(multiplierMode = MultiplierMode.WORD) } })
            Text("ضرب در کل کلمه")
        }
        var values by remember(s.letterValuesText) { mutableStateOf(s.letterValuesText) }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(values, { values = it }, Modifier.weight(1f),
                label = { Text("امتیاز حروف (مثال: ا=1، ژ=5). خالی = هر حرف ۱") })
            Button(onClick = { pipeline.updateSettings { it.copy(letterValuesText = values) } },
                enabled = values != s.letterValuesText) { Text("ثبت") }
        }

        Text("OCR", fontSize = 18.sp)
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(profileText, { profileText = it }, Modifier.weight(1f), singleLine = true,
                label = { Text("پروفایل بازی") })
            Button(onClick = { pipeline.applyProfile(profileText) },
                enabled = profileText.isNotBlank() && profileText.trim() != s.profile) { Text("ثبت") }
        }
        Text("پروفایل فعال: ${s.profile} — نمونههای یادگرفته و کادر شناور برای هر پروفایل جدا ذخیره میشوند.",
            fontSize = 12.sp, color = Color.Gray)

        CommitSlider(s.contrast, 0.5f..2.5f, label = { "کنتراست: ${"%.1f".format(it)}" }) { v ->
            pipeline.updateSettings { it.copy(contrast = v) }
        }
        CommitSlider(s.sharpen, 0f..1.5f, label = { "وضوح (شارپ): ${"%.1f".format(it)}" }) { v ->
            pipeline.updateSettings { it.copy(sharpen = v) }
        }
        CommitSlider(s.thresholdBias.toFloat(), -40f..40f, label = { "جابهجایی آستانه: ${it.toInt()}" }) { v ->
            pipeline.updateSettings { it.copy(thresholdBias = v.toInt()) }
        }
        CommitSlider(s.minConfidence, 0.4f..0.95f, label = { "حداقل اطمینان برای ثبت خودکار: ${(it * 100).toInt()}٪" }) { v ->
            pipeline.updateSettings { it.copy(minConfidence = v) }
        }

        OutlinedButton(onClick = { confirmClear = true }, colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFB71C1C))) {
            Text("پاک کردن نمونههای یادگرفته این پروفایل")
        }
    }

    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            title = { Text("پاک کردن نمونهها") },
            text = { Text("همه حروفی که برنامه از اصلاحات شما در پروفایل «${s.profile}» یاد گرفته پاک میشوند. این کار قابل بازگشت نیست.") },
            confirmButton = { TextButton(onClick = { pipeline.clearUserSamples(); confirmClear = false }) { Text("پاک کن") } },
            dismissButton = { TextButton(onClick = { confirmClear = false }) { Text("انصراف") } }
        )
    }
}

/** اسلایدری که هنگام کشیدن فقط مقدار محلی را تغییر میدهد و در پایان (onValueChangeFinished) ذخیره میکند. */
@Composable
private fun CommitSlider(
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    steps: Int = 0,
    label: (Float) -> String,
    onCommit: (Float) -> Unit
) {
    var local by remember(value) { mutableFloatStateOf(value) }
    Column {
        Text(label(local))
        Slider(value = local, onValueChange = { local = it }, valueRange = range, steps = steps,
            onValueChangeFinished = { onCommit(local) })
    }
}
