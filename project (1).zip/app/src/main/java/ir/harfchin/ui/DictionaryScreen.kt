package ir.harfchin.ui

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ir.harfchin.dictionary.DictionaryInfo
import ir.harfchin.pipeline.ScanPipeline
import ir.harfchin.pipeline.UiState

/**
 * مدیریت فرهنگ لغت — فقط فایلهایی که کاربر خودش انتخاب میکند وارد میشوند.
 * خواندن فایل و تشخیص کدگذاری (UTF-8 / UTF-16 / Windows-1256) در ScanPipeline روی Dispatchers.IO انجام میشود.
 */
@Composable
fun DictionaryScreen(pipeline: ScanPipeline, state: UiState) {
    val ctx = LocalContext.current
    var toDelete by remember { mutableStateOf<DictionaryInfo?>(null) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris: List<Uri> ->
        pipeline.importUris(ctx.contentResolver, uris)
    }
    val importing = state.importing

    Column(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Button(
            onClick = { picker.launch(arrayOf("text/*", "application/json", "text/csv", "application/octet-stream")) },
            enabled = importing == null,
            modifier = Modifier.fillMaxWidth()
        ) { Text("افزودن فرهنگ لغت (TXT / CSV / JSON — چند فایل همزمان)") }

        if (importing != null) {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)) {
                Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("در حال وارد کردن ${importing.done + 1} از ${importing.total}: ${importing.current}", fontSize = 13.sp)
                    if (importing.total > 1) {
                        LinearProgressIndicator(
                            progress = { importing.done.toFloat() / importing.total },
                            modifier = Modifier.fillMaxWidth()
                        )
                    } else {
                        LinearProgressIndicator(Modifier.fillMaxWidth())
                    }
                }
            }
        }

        val active = state.dictionaries.filter { it.enabled }
        Text("${state.dictionaries.size} فرهنگ لغت — ${active.size} فعال — مجموع ${active.sumOf { it.wordCount }} کلمه",
            fontSize = 13.sp)
        Text("برنامه به اینترنت دسترسی ندارد و هیچ لغتی را خودکار اضافه نمیکند.", fontSize = 12.sp,
            color = MaterialTheme.colorScheme.secondary)
        LazyColumn(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            items(state.dictionaries, key = { it.id }) { d ->
                Card {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(d.name + if (d.builtIn) "  (پیشفرض)" else "", fontSize = 16.sp)
                            Text("${d.wordCount} کلمه — ${formatSize(d.sizeBytes)} — ${d.fileName}", fontSize = 12.sp)
                        }
                        Switch(d.enabled, { pipeline.toggleDictionary(d.id, it) }, enabled = importing == null)
                        TextButton(onClick = { toDelete = d }, enabled = importing == null) { Text("حذف") }
                    }
                }
            }
        }
    }
    toDelete?.let { d ->
        AlertDialog(onDismissRequest = { toDelete = null },
            confirmButton = { TextButton(onClick = { pipeline.deleteDictionary(d.id); toDelete = null }) { Text("حذف") } },
            dismissButton = { TextButton(onClick = { toDelete = null }) { Text("انصراف") } },
            text = { Text("«${d.name}» حذف شود؟") })
    }
}

fun formatSize(b: Long) = when {
    b >= 1_048_576 -> "%.1f مگابایت".format(b / 1_048_576.0)
    b >= 1024 -> "${b / 1024} کیلوبایت"
    else -> "$b بایت"
}
