package ir.harfchin.ocr

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import ir.harfchin.core.PersianNormalizer
import java.io.File

/**
 * مخزن نمونه‌های مرجع OCR:
 *  - نمونه‌های تولیدی از فونت‌ها: هر فایل .ttf/.otf داخل assets/fonts + فونت‌های سیستم
 *  - نمونه‌های تأییدشده کاربر (هر بار که کاربر حرفی را اصلاح یا تأیید می‌کند) — به ازای هر پروفایل بازی
 * این بخش باعث می‌شود دقت روی فونت خاص هر بازی با استفاده بیشتر شود.
 */
class TemplateStore(private val context: Context) {
    private val userDir = File(context.filesDir, "ocr_samples").apply { mkdirs() }
    @Volatile private var fontTemplates: List<Template>? = null
    @Volatile private var digitTemplates: List<Template>? = null
    private val userTemplates = HashMap<String, MutableList<Template>>()
    var activeProfile: String = "default"

    fun letters(): List<Template> = fonts() + user(activeProfile)

    /** نمونههای واقعی همراه برنامه (assets/ocr) برای بازی «بازم بازی» */
    val bundledReader: TileReader? by lazy {
        runCatching {
            TileReader(
                TileReader.loadTemplates(context.assets.open("ocr/bazambazi_letters.bin")),
                TileReader.loadTemplates(context.assets.open("ocr/bazambazi_digits.bin"))
            )
        }.getOrNull()
    }
    fun digits(): List<Template> = digitTemplates ?: renderSet(listOf("1", "2", "3", "۱", "۲", "۳"), digitsOnly = true)
        .map { Template(PersianNormalizer.normalize(it.letter), it.glyph, false) }.also { digitTemplates = it }

    private fun typefaces(): List<Typeface> {
        val list = ArrayList<Typeface>()
        context.assets.list("fonts")?.filter { it.endsWith(".ttf") || it.endsWith(".otf") }?.forEach {
            runCatching { list.add(Typeface.createFromAsset(context.assets, "fonts/$it")) }
        }
        list.add(Typeface.DEFAULT); list.add(Typeface.DEFAULT_BOLD)
        list.add(Typeface.create(Typeface.SERIF, Typeface.NORMAL))
        list.add(Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD))
        return list
    }

    private fun fonts(): List<Template> = fontTemplates ?: renderSet(PersianNormalizer.TILE_LETTERS).also { fontTemplates = it }

    private fun renderSet(chars: List<String>, digitsOnly: Boolean = false): List<Template> {
        val out = ArrayList<Template>()
        val size = 96
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        for (tf in typefaces()) for (ch in chars) for (stroke in listOf(0f, 3f)) {
            canvas.drawColor(Color.WHITE)
            val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                typeface = tf; textSize = size * 0.7f; color = Color.BLACK; textAlign = Paint.Align.CENTER
                style = if (stroke > 0) Paint.Style.FILL_AND_STROKE else Paint.Style.FILL; strokeWidth = stroke
            }
            canvas.drawText(ch, size / 2f, size * 0.72f, p)
            val px = IntArray(size * size); bmp.getPixels(px, 0, size, 0, 0, size, size)
            val bin = Preprocessor.binarize(GrayImage.fromArgb(px, size, size))
            if (bin.inkCount > 0) out.add(Template(ch, Preprocessor.normalizeGlyph(bin), false))
        }
        return out
    }

    @Synchronized
    fun user(profile: String): List<Template> = userTemplates.getOrPut(profile) {
        val f = File(userDir, "$profile.bin")
        if (!f.exists()) mutableListOf() else decode(f.readBytes()).toMutableList()
    }

    /** ذخیره نمونه تأییدشده کاربر (حداکثر ۲۰ نمونه برای هر حرف) */
    @Synchronized
    fun addUserSample(profile: String, letter: String, glyph: BinImage) {
        val list = user(profile) as MutableList
        list.add(Template(letter, glyph, true))
        val trimmed = list.groupBy { it.letter }.flatMap { it.value.takeLast(20) }
        list.clear(); list.addAll(trimmed)
        File(userDir, "$profile.bin").writeBytes(encode(list))
    }

    fun clearUserSamples(profile: String) { userTemplates.remove(profile); File(userDir, "$profile.bin").delete() }

    // قالب ساده: [len letter][utf8][1024 bit as bytes]
    private fun encode(list: List<Template>): ByteArray {
        val o = java.io.ByteArrayOutputStream(); val d = java.io.DataOutputStream(o)
        d.writeInt(list.size)
        list.forEach { t -> d.writeUTF(t.letter); t.glyph.px.forEach { d.writeBoolean(it) } }
        return o.toByteArray()
    }

    private fun decode(b: ByteArray): List<Template> = runCatching {
        val d = java.io.DataInputStream(b.inputStream()); val n = d.readInt()
        List(n) { val l = d.readUTF(); Template(l, BinImage(32, 32, BooleanArray(1024) { d.readBoolean() }), true) }
    }.getOrDefault(emptyList())
}
