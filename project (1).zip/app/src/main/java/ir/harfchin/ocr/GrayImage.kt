package ir.harfchin.ocr

import kotlin.math.max
import kotlin.math.min

/** تصویر خاکستری ۰..۲۵۵ — مستقل از Android تا روی JVM تست شود. */
class GrayImage(val width: Int, val height: Int, val px: IntArray = IntArray(width * height)) {
    operator fun get(x: Int, y: Int) = px[y * width + x]
    operator fun set(x: Int, y: Int, v: Int) { px[y * width + x] = v }

    fun crop(x0: Int, y0: Int, w: Int, h: Int): GrayImage {
        val cx = x0.coerceIn(0, width - 1); val cy = y0.coerceIn(0, height - 1)
        val cw = min(w, width - cx).coerceAtLeast(1); val ch = min(h, height - cy).coerceAtLeast(1)
        val out = GrayImage(cw, ch)
        for (y in 0 until ch) System.arraycopy(px, (cy + y) * width + cx, out.px, y * cw, cw)
        return out
    }

    /** تغییر اندازه دوخطی */
    fun resize(nw: Int, nh: Int): GrayImage {
        val out = GrayImage(nw, nh)
        val sx = width.toFloat() / nw; val sy = height.toFloat() / nh
        for (y in 0 until nh) for (x in 0 until nw) {
            val fx = (x + 0.5f) * sx - 0.5f; val fy = (y + 0.5f) * sy - 0.5f
            val x0 = fx.toInt().coerceIn(0, width - 1); val y0 = fy.toInt().coerceIn(0, height - 1)
            val x1 = min(x0 + 1, width - 1); val y1 = min(y0 + 1, height - 1)
            val ax = (fx - x0).coerceIn(0f, 1f); val ay = (fy - y0).coerceIn(0f, 1f)
            val v = (this[x0, y0] * (1 - ax) + this[x1, y0] * ax) * (1 - ay) +
                    (this[x0, y1] * (1 - ax) + this[x1, y1] * ax) * ay
            out[x, y] = v.toInt()
        }
        return out
    }

    companion object {
        /** ARGB → خاکستری (وزن‌های BT.601) */
        fun fromArgb(argb: IntArray, w: Int, h: Int) = GrayImage(w, h, IntArray(w * h) {
            val c = argb[it]
            (((c shr 16) and 255) * 299 + ((c shr 8) and 255) * 587 + (c and 255) * 114) / 1000
        })
    }
}

/** تصویر دودویی: true = جوهر (حرف) */
class BinImage(val width: Int, val height: Int, val px: BooleanArray = BooleanArray(width * height)) {
    operator fun get(x: Int, y: Int) = px[y * width + x]
    operator fun set(x: Int, y: Int, v: Boolean) { px[y * width + x] = v }
    val inkCount get() = px.count { it }

    fun bbox(): IntArray? {
        var x0 = width; var y0 = height; var x1 = -1; var y1 = -1
        for (y in 0 until height) for (x in 0 until width) if (this[x, y]) {
            x0 = min(x0, x); y0 = min(y0, y); x1 = max(x1, x); y1 = max(y1, y)
        }
        return if (x1 < 0) null else intArrayOf(x0, y0, x1, y1)
    }
}
