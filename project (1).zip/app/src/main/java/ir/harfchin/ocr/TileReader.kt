package ir.harfchin.ocr

import ir.harfchin.core.model.Tile
import java.io.DataInputStream
import java.io.InputStream

/**
 * خواننده کاشی کالیبرهشده برای بازی «بازم بازی» (com.bazambazi) و طرحهای مشابه
 * (کاشی چوبی روشن، حرف قهوهای تیره، عدد امتیاز در گوشه بالا-راست).
 *
 * روش (همان روشی که روی ۱۲ اسکرینشات واقعی سنجیده شد: ۱۸۱ از ۱۸۱ حرف و ۱۸۴ از ۱۸۴ عدد درست):
 *  ۱. خاکستری BT.601 و جوهر = روشنایی کمتر از ۱۱۰
 *  ۲. حذف گوشه عدد (۳۳٪ بالا × ۳۲٪ راست) و حاشیه ۶٪
 *  ۳. برش به کادر جوهر، مربع کردن، نمونهبرداری میانگین به ۳۲×۳۲ و آستانه ۰٫۳۵
 *  ۴. نزدیکترین همسایه با فاصله همینگ نسبت به نمونههای واقعی
 * اگر فاصله زیاد یا اختلاف با حرف دوم کم باشد، کاشی «نیاز به تأیید» علامت میخورد.
 */
class TileReader(
    private val letters: List<Template>,
    private val digits: List<Template>,
    private val maxDistance: Int = 110,
    private val minMargin: Int = 40
) {
    data class Reading(val tile: Tile, val glyph: BinImage?)

    fun read(tile: GrayImage, extra: List<Template> = emptyList()): Reading {
        val g = letterGlyph(tile)
        val score = digitGlyph(tile)?.let { nearest(it, digits).firstOrNull()?.first?.toIntOrNull() } ?: 1
        if (g == null) return Reading(Tile("", score, 0f, emptyList(), needsReview = true), null)
        val ranked = nearest(g, letters + extra)
        val best = ranked.getOrNull(0)
        val second = ranked.getOrNull(1)
        val dist = best?.second ?: Int.MAX_VALUE
        val margin = (second?.second ?: Int.MAX_VALUE) - dist
        val unsure = best == null || dist > maxDistance || margin < minMargin
        val conf = if (best == null) 0f else (1f - dist / 1024f * 4f).coerceIn(0f, 1f)
        return Reading(
            Tile(best?.first ?: "", score.coerceIn(1, 9), conf, ranked.take(4).map { it.first }, unsure),
            g
        )
    }

    /** فهرست (حرف، کمترین فاصله) مرتب از نزدیک به دور */
    private fun nearest(g: BinImage, set: List<Template>): List<Pair<String, Int>> {
        val best = HashMap<String, Int>()
        for (t in set) {
            var d = 0
            for (i in 0 until 1024) if (g.px[i] != t.glyph.px[i]) d++
            if (d < (best[t.letter] ?: Int.MAX_VALUE)) best[t.letter] = d
        }
        return best.entries.map { it.key to it.value }.sortedBy { it.second }
    }

    companion object {
        const val INK = 110

        fun letterGlyph(t: GrayImage): BinImage? {
            val w = t.width; val h = t.height
            val ink = BinImage(w, h)
            val cx = (w * 0.68f).toInt(); val cy = (h * 0.33f).toInt()
            val mx0 = (w * 0.06f).toInt(); val mx1 = (w * 0.94f).toInt()
            val my0 = (h * 0.06f).toInt(); val my1 = (h * 0.94f).toInt()
            for (y in my0 until my1) for (x in mx0 until mx1) {
                if (y < cy && x >= cx) continue
                if (t[x, y] < INK) ink[x, y] = true
            }
            return norm32(ink)
        }

        fun digitGlyph(t: GrayImage): BinImage? {
            val w = t.width; val h = t.height
            val x0 = (w * 0.72f).toInt(); val x1 = (w * 0.95f).toInt()
            val y0 = (h * 0.04f).toInt(); val y1 = (h * 0.30f).toInt()
            val c = BinImage(x1 - x0, y1 - y0)
            for (y in y0 until y1) for (x in x0 until x1) if (t[x, y] < 120) c[x - x0, y - y0] = true
            return norm32(c)
        }

        /** برش به جوهر، مربع، میانگین بلوکی ۳۲×۳۲، آستانه ۰٫۳۵ */
        fun norm32(ink: BinImage): BinImage? {
            if (ink.inkCount < 8) return null
            val bb = ink.bbox() ?: return null
            val cw = bb[2] - bb[0] + 1; val ch = bb[3] - bb[1] + 1
            val s = maxOf(cw, ch); val ox = (s - cw) / 2; val oy = (s - ch) / 2
            fun at(x: Int, y: Int): Boolean {
                val sx = x - ox; val sy = y - oy
                return sx in 0 until cw && sy in 0 until ch && ink[bb[0] + sx, bb[1] + sy]
            }
            val out = BinImage(32, 32)
            for (j in 0 until 32) {
                val y0 = j * s / 32; val y1 = maxOf(y0 + 1, (j + 1) * s / 32)
                for (i in 0 until 32) {
                    val x0 = i * s / 32; val x1 = maxOf(x0 + 1, (i + 1) * s / 32)
                    var on = 0; var n = 0
                    for (y in y0 until y1) for (x in x0 until x1) { n++; if (at(x, y)) on++ }
                    out[i, j] = on.toFloat() / n > 0.35f
                }
            }
            return out
        }

        /** خواندن فایل نمونهها: [int n] سپس n بار [writeUTF حرف][۱۰۲۴ بایت ۰/۱] */
        fun loadTemplates(input: InputStream, fromUser: Boolean = false): List<Template> =
            DataInputStream(input.buffered()).use { d ->
                val n = d.readInt()
                List(n) {
                    val l = d.readUTF()
                    val px = BooleanArray(1024) { d.readByte().toInt() != 0 }
                    Template(l, BinImage(32, 32, px), fromUser)
                }
            }
    }
}

/**
 * پیدا کردن ۱۶ کاشی چوبی روشن داخل تصویر رنگی (ردیفها و ستونهایی که بیش از ۳۰٪ پیکسل چوبی دارند).
 * اگر دقیقاً ۴ ردیف و ۴ ستون پیدا نشد، null برمیگرداند تا تقسیم یکنواخت استفاده شود.
 */
object WoodTileFinder {
    fun isWood(argb: Int): Boolean {
        val r = (argb shr 16) and 255; val g = (argb shr 8) and 255; val b = argb and 255
        return r > 200 && g > 170 && b < 200
    }

    fun find(argb: IntArray, w: Int, h: Int): List<GridDetector.Cell>? {
        val rows = FloatArray(h); val cols = FloatArray(w)
        for (y in 0 until h) { var c = 0; for (x in 0 until w) if (isWood(argb[y * w + x])) c++; rows[y] = c.toFloat() / w }
        val ys = best4(runs(rows, 0.3f, h / 40)) ?: return null
        val y0 = ys.first().first; val y1 = ys.last().second
        for (x in 0 until w) { var c = 0; for (y in y0 until y1) if (isWood(argb[y * w + x])) c++; cols[x] = c.toFloat() / (y1 - y0) }
        val xs = best4(runs(cols, 0.3f, w / 40)) ?: return null
        // اگر بالای کاشی بریده شده باشد (مثلاً نوار وضعیت یا پخشکننده ویدیو)، ارتفاع از روی نسبت
        // واقعی کاشی (ارتفاع ≈ ۰٫۹۰۶ × عرض) و لبه پایین بازسازی میشود
        return ys.flatMap { (a, b) -> xs.map { (c, d) ->
            val tw = d - c; val th = Math.round(tw * 0.906f)
            if (b - a < th * 0.97f) GridDetector.Cell(c, b - th, tw, th) else GridDetector.Cell(c, a, tw, b - a)
        } }
    }

    /** از بین نوارهای پیداشده، ۴ نوار پشت سر هم با اندازه و فاصله یکنواخت (سرصفحه چوبی بازی حذف میشود) */
    private fun best4(r: List<Pair<Int, Int>>): List<Pair<Int, Int>>? {
        var best: List<Pair<Int, Int>>? = null; var bestCost = Float.MAX_VALUE
        for (i in 0..r.size - 4) {
            val q = r.subList(i, i + 4)
            val hs = q.map { it.second - it.first }
            val gs = (0 until 3).map { q[it + 1].first - q[it].second }
            val mx = hs.max().toFloat()
            val cost = (hs.max() - hs.min()) / mx + (gs.max() - gs.min()) / mx
            if (cost < bestCost) { bestCost = cost; best = q }
        }
        return if (bestCost < 0.25f) best else null
    }

    private fun runs(v: FloatArray, th: Float, minLen: Int): List<Pair<Int, Int>> {
        val out = ArrayList<Pair<Int, Int>>(); var s = -1
        for (i in v.indices) {
            val on = v[i] > th
            if (on && s < 0) s = i
            if ((!on || i == v.size - 1) && s >= 0) { val e = if (on) i + 1 else i; if (e - s > minLen) out.add(s to e); s = -1 }
        }
        return out
    }
}
