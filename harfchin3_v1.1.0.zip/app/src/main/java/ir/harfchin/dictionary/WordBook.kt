package ir.harfchin.dictionary

import android.content.Context
import ir.harfchin.core.PersianNormalizer
import java.io.File

/**
 * دفتر کلمات «یادگرفته از بازی» — بدون هیچ کار اضافه وسط بازی:
 *  ✓ قبول: کلمهای که در فهرست کنار ذرهبین لمس شد (یعنی آن را زدید). از این به بعد همیشه «مطمئن».
 *  ✗ رد: کلمهای که نگه داشته شد. هرگز دوباره پیشنهاد نمیشود.
 */
class WordBook(context: Context) {
    private val okFile = File(context.filesDir, "words_accepted.txt")
    private val badFile = File(context.filesDir, "words_rejected.txt")
    private val ok = load(okFile); private val bad = load(badFile)

    private fun load(f: File) = if (f.exists()) f.readLines().mapNotNull { PersianNormalizer.normalizeWordOrNull(it) }.toHashSet() else HashSet()

    @Synchronized fun accepted(): Set<String> = ok.toSet()
    @Synchronized fun rejected(): Set<String> = bad.toSet()

    @Synchronized fun accept(w: String) { bad.remove(w); if (ok.add(w)) save() }
    @Synchronized fun reject(w: String) { ok.remove(w); if (bad.add(w)) save() }
    @Synchronized fun forget(w: String) { if (ok.remove(w) or bad.remove(w)) save() }

    private fun save() { okFile.writeText(ok.sorted().joinToString("\n")); badFile.writeText(bad.sorted().joinToString("\n")) }
}
