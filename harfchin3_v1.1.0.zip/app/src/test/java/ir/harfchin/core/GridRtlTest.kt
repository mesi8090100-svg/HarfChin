package ir.harfchin.core

import ir.harfchin.core.model.Grid
import org.junit.Assert.assertEquals
import org.junit.Test
import java.io.File

class GridRtlTest {
    @Test fun rowsAreReversed() {
        // ردیف اول بازی (از راست): ک ت ا ب  → اندیس از چپ: ب ا ت ک
        val typed = "کتابمنزلسیبدرودم"
        assertEquals(16, typed.length)
        val g = Grid.fromRtlRows(typed, IntArray(16) { it + 1 })
        assertEquals("باتک", g.tiles.take(4).joinToString("") { it.letter })
        assertEquals(listOf(4, 3, 2, 1), g.tiles.take(4).map { it.multiplier })
        assertEquals("لزنم", g.tiles.subList(4, 8).joinToString("") { it.letter })
        assertEquals("مدور", g.tiles.subList(12, 16).joinToString("") { it.letter })
    }
}
