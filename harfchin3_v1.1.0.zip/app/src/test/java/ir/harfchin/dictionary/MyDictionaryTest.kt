package ir.harfchin.dictionary

import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class MyDictionaryTest {
    private fun read(): Set<String> {
        val f = listOf("src/main/assets/dictionaries/my_fa.txt", "app/src/main/assets/dictionaries/my_fa.txt").map(::File).first { it.exists() }
        return DictionaryParser.parse(f.readText(), DictFormat.TXT)
    }

    @Test fun containsUserListAndCommon() {
        val w = read()
        listOf("آب", "یخ", "آتش", "کتاب", "باورنکردنی", "کاروانسرا", "گفتند", "بجنگد", "خوردند", "قانع", "مخلف").forEach { assertTrue(it, it in w) }
        assertTrue(w.size in 25_000..28_000)
    }
}
