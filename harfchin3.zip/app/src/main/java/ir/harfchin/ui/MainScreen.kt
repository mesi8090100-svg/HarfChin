package ir.harfchin.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import ir.harfchin.pipeline.ScanPipeline

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(pipeline: ScanPipeline, onStartOverlay: () -> Unit, overlayGranted: Boolean) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val state by pipeline.state.collectAsStateWithLifecycle()
    val snack = remember { SnackbarHostState() }
    LaunchedEffect(state.message) { state.message?.let { snack.showSnackbar(it); pipeline.clearMessage() } }

    Scaffold(
        topBar = { TopAppBar(title = { Text("حرفچین", fontWeight = androidx.compose.ui.text.font.FontWeight.ExtraBold) }, colors = TopAppBarDefaults.topAppBarColors(containerColor = Plum, titleContentColor = androidx.compose.ui.graphics.Color.White)) },
        snackbarHost = { SnackbarHost(snack) },
        bottomBar = {
            NavigationBar {
                listOf("اسکن و حل", "فرهنگ لغت", "تنظیمات").forEachIndexed { i, t ->
                    NavigationBarItem(selected = tab == i, onClick = { tab = i }, icon = {}, label = { Text(t) })
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) {
                0 -> SolveScreen(pipeline, state, onStartOverlay, overlayGranted)
                1 -> DictionaryScreen(pipeline, state)
                else -> SettingsScreen(pipeline, state)
            }
        }
    }
}
