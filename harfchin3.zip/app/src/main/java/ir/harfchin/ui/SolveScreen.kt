package ir.harfchin.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.DialogProperties
import ir.harfchin.core.PersianNormalizer
import ir.harfchin.core.model.FoundWord
import ir.harfchin.pipeline.ScanPipeline
import ir.harfchin.pipeline.UiState

/**
 * کل صفحه یک LazyColumn است: دکمهها، ورود دستی و جدول بالای فهرست کلمات اسکرول میشوند.
 * imePadding باعث میشود با باز شدن کیبورد، فیلدها زیر آن پنهان نشوند.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SolveScreen(pipeline: ScanPipeline, state: UiState, onStartOverlay: () -> Unit, overlayGranted: Boolean) {
    var editIndex by remember { mutableStateOf<Int?>(null) }
    var manual by rememberSaveable { mutableStateOf("") }
    var filter by rememberSaveable { mutableStateOf("") }
    var byLength by rememberSaveable { mutableStateOf(true) }
    var lenFilter by rememberSaveable { mutableStateOf(0) }   // 0 = همه
    val narrow = LocalConfiguration.current.screenWidthDp < 360
    val counts = remember(state.words) { state.words.groupingBy { it.word.length }.eachCount().toSortedMap(reverseOrder()) }
    val shown = remember(state.words, filter, byLength, lenFilter) {
        val f = PersianNormalizer.normalize(filter)
        state.words.filter { (f.isBlank() || it.word.contains(f)) && (lenFilter == 0 || it.word.length == lenFilter) }
            .sortedWith(
                if (byLength) compareByDescending<FoundWord> { it.word.length }.thenByDescending { it.score }.thenBy { it.word }
                else compareByDescending<FoundWord> { it.score }.thenByDescending { it.word.length }.thenBy { it.word }
            )
    }

    LazyColumn(
        Modifier.fillMaxSize().background(Cream).imePadding(),
        contentPadding = PaddingValues(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item(key = "scan") {
            Button(
                onClick = onStartOverlay,
                modifier = Modifier.fillMaxWidth().heightIn(min = 58.dp),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Plum)
            ) {
                Text(if (overlayGranted) "اسکن روی بازی" else "اسکن (اول مجوز نمایش روی برنامهها)", fontSize = 18.sp, fontWeight = FontWeight.Bold)
            }
        }
        item(key = "board") {
            Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Plum)) {
                Column(Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    GridBoard(state, state.selectedWord, onTileClick = { editIndex = it },
                        modifier = Modifier.fillMaxWidth(if (narrow) 1f else 0.82f))
                    state.selectedWord?.let { w ->
                        Spacer(Modifier.height(8.dp))
                        Text("${w.word}  ·  ${w.score} امتیاز", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
        item(key = "actions") {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Button(onClick = pipeline::solve, enabled = !state.busy, modifier = Modifier.weight(1f).height(50.dp),
                    shape = RoundedCornerShape(12.dp), colors = ButtonDefaults.buttonColors(containerColor = PathColor)) {
                    Text(if (state.busy) "در حال پیدا کردن…" else "پیدا کردن کلمهها", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                }
            }
            val unsure = state.grid.tiles.count { it.needsReview }
            if (unsure > 0) Text("$unsure خانه زرد است؛ رویش بزنید و حرف درست را انتخاب کنید.",
                color = Color(0xFF8D6E00), fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
        }
        item(key = "manual") {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(manual, { manual = it }, Modifier.weight(1f), singleLine = true,
                    label = { Text("یا ۱۶ حرف را تایپ کنید (ردیف به ردیف)") })
                OutlinedButton(onClick = { pipeline.setGridText(manual) }) { Text("ثبت") }
            }
        }
        if (state.words.isNotEmpty()) {
            item(key = "summary") {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("${state.words.size} کلمه پیدا شد", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Ink)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        FilterChip(lenFilter == 0, { lenFilter = 0 }, { Text("همه") })
                        counts.forEach { (len, n) ->
                            FilterChip(lenFilter == len, { lenFilter = if (lenFilter == len) 0 else len }, { Text("$len حرفی ($n)") })
                        }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        FilterChip(byLength, { byLength = true }, { Text("بلندترین اول") })
                        FilterChip(!byLength, { byLength = false }, { Text("بیشترین امتیاز") })
                        OutlinedTextField(filter, { filter = it }, Modifier.weight(1f), singleLine = true,
                            placeholder = { Text("جستوجو") })
                    }
                }
            }
        }
        items(shown, key = { "w_" + it.word }) { w -> WordRow(w, w == state.selectedWord) { pipeline.select(w) } }
    }

    editIndex?.let { i ->
        TileEditDialog(state, i, onDismiss = { editIndex = null }) { letter, mul ->
            pipeline.setTile(i, letter, mul); editIndex = null
        }
    }
}

/** جدول ۴×۴ — همیشه چیدمان چپبهراست تا با تصویر بازی یکی باشد؛ مسیر کلمه انتخابی با خط رسم میشود. */
@Composable
fun GridBoard(state: UiState, selected: FoundWord?, onTileClick: (Int) -> Unit, modifier: Modifier = Modifier) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Box(modifier.aspectRatio(1f)) {
            Column(Modifier.fillMaxSize()) {
                for (r in 0 until 4) Row(Modifier.weight(1f)) {
                    for (c in 0 until 4) {
                        val i = r * 4 + c
                        val t = state.grid.tiles[i]
                        val order = selected?.path?.indexOf(i) ?: -1
                        val bg = when { order == 0 -> Color(0xFF2E7D32); order > 0 -> PathColor; t.needsReview -> Unsure; else -> TileColor }
                        Box(
                            Modifier.weight(1f).fillMaxHeight().padding(4.dp)
                                .background(WoodDark, RoundedCornerShape(12.dp))
                                .padding(bottom = 4.dp)
                                .background(bg, RoundedCornerShape(12.dp))
                                .clickable { onTileClick(i) },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(t.letter.ifEmpty { "؟" }, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, color = if (order >= 0) Color.White else Ink)
                            if (t.multiplier > 1) Text("${t.multiplier}", fontSize = 11.sp,
                                modifier = Modifier.align(Alignment.TopEnd).padding(4.dp), color = if (order >= 0) Color.White else Ink)
                            if (order >= 0) Text("${order + 1}", fontSize = 10.sp,
                                modifier = Modifier.align(Alignment.BottomStart).padding(3.dp), color = Color.White)
                        }
                    }
                }
            }
            selected?.let { w ->
                Canvas(Modifier.fillMaxSize()) {
                    val cell = size.width / 4
                    fun center(i: Int) = Offset((i % 4 + 0.5f) * cell, (i / 4 + 0.5f) * cell)
                    w.path.zipWithNext().forEach { (a, b) ->
                        drawLine(Color(0xCC1B5E20), center(a), center(b), strokeWidth = 14f, cap = StrokeCap.Round)
                    }
                }
            }
        }
    }
}

@Composable
private fun WordRow(w: FoundWord, selected: Boolean, onClick: () -> Unit) {
    Card(
        onClick = onClick,
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = if (selected) Color(0xFFDCEDC8) else Color.White),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(Modifier.padding(horizontal = 14.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(w.word, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Ink, modifier = Modifier.weight(1f))
            if (w.usesUncertainTile) Text("⚠", modifier = Modifier.padding(horizontal = 4.dp))
            Text("${w.word.length} حرف", fontSize = 13.sp, color = Color.Gray, modifier = Modifier.padding(horizontal = 10.dp))
            Box(Modifier.background(Plum, RoundedCornerShape(8.dp)).padding(horizontal = 10.dp, vertical = 4.dp)) {
                Text("${w.score}", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White)
            }
        }
    }
}

/** دیالوگ اصلاح خانه — محتوا اسکرول میشود و ارتفاعش به ۷۵٪ صفحه محدود است تا روی گوشی کوچک جا شود. */
@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun TileEditDialog(state: UiState, index: Int, onDismiss: () -> Unit, onPick: (String, Int) -> Unit) {
    val t = state.grid.tiles[index]
    var mul by remember { mutableIntStateOf(t.multiplier) }
    val maxH = (LocalConfiguration.current.screenHeightDp * 0.75f).dp
    AlertDialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false),
        modifier = Modifier.fillMaxWidth(0.94f).heightIn(max = maxH),
        confirmButton = { TextButton(onClick = { onPick(t.letter, mul) }, enabled = t.letter.isNotEmpty()) { Text("فقط امتیاز") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } },
        title = { Text("خانه ${index + 1}" + if (t.confidence < 1f) "  (اطمینان ${(t.confidence * 100).toInt()}٪)" else "") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                if (t.alternatives.isNotEmpty()) {
                    Text("پیشنهاد OCR:", fontSize = 13.sp)
                    FlowRow { t.alternatives.forEach { l -> FilledTonalButton(onClick = { onPick(l, mul) }, Modifier.padding(2.dp)) { Text(l, fontSize = 18.sp) } } }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("امتیاز: ")
                    listOf(1, 2, 3).forEach { m -> FilterChip(mul == m, { mul = m }, { Text("$m") }, Modifier.padding(2.dp)) }
                }
                FlowRow {
                    PersianNormalizer.TILE_LETTERS.forEach { l ->
                        OutlinedButton(onClick = { onPick(l, mul) }, Modifier.padding(1.dp).size(44.dp),
                            contentPadding = PaddingValues(0.dp)) { Text(l, fontSize = 17.sp) }
                    }
                }
            }
        }
    )
}
