package ir.harfchin.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Wood = Color(0xFF8D5A2B)
val TileColor = Color(0xFFF6E2B3)
val WoodDark = Color(0xFFD9A55B)
val Plum = Color(0xFF4A3466)
val Cream = Color(0xFFF7F2EA)
val Ink = Color(0xFF3B2414)
val Unsure = Color(0xFFFFD54F)
val PathColor = Color(0xFF7CB342)

@Composable
fun HarfChinTheme(content: @Composable () -> Unit) = MaterialTheme(
    colorScheme = lightColorScheme(primary = Plum, secondary = Color(0xFF5D4037), background = Color(0xFFFAF6EE)),
    content = content
)
