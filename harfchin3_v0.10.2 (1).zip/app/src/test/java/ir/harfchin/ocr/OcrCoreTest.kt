package ir.harfchin.ocr

import org.junit.Assert.*
import org.junit.Test

/** تست‌های بخش‌های مستقل از Android موتور OCR با تصاویر مصنوعی */
class OcrCoreTest {
    private fun blob(img: BinImage, x0: Int, y0: Int, w: Int, h: Int) {
        for (y in y0 until y0 + h) for (x in x0 until x0 + w) img[x, y] = true
    }

    @Test fun otsuSeparates() {
        val g = GrayImage(20, 20, IntArray(400) { if (it % 20 < 10) 40 else 210 })
        val t = Preprocessor.otsu(g)
        assertTrue(t in 40..209)
    }

    @Test fun binarizeDetectsPolarity() {
        // حرف روشن روی زمینه تیره و برعکس → هر دو باید جوهر کم داشته باشند
        val dark = GrayImage(40, 40, IntArray(1600) { 30 }).also { for (y in 10..30) for (x in 18..22) it[x, y] = 230 }
        val light = GrayImage(40, 40, IntArray(1600) { 220 }).also { for (y in 10..30) for (x in 18..22) it[x, y] = 20 }
        val a = Preprocessor.binarize(dark); val b = Preprocessor.binarize(light)
        assertTrue(a.inkCount in 60..200); assertTrue(b.inkCount in 60..200)
    }

    @Test fun dotFeatures() {
        // بدنه افقی + یک نقطه زیر → امضای «ب»
        val b = BinImage(60, 60); blob(b, 8, 28, 44, 8); blob(b, 27, 44, 6, 6)
        val f = GlyphFeatures.extract(b)!!
        assertEquals(0, f.dotsAbove); assertEquals(1, f.dotsBelow)
        assertTrue(GlyphFeatures.compatibility(f, "ب") > GlyphFeatures.compatibility(f, "ت"))
        assertTrue(GlyphFeatures.compatibility(f, "ب") > GlyphFeatures.compatibility(f, "پ"))
        // دو نقطه بالا → «ت»
        val t = BinImage(60, 60); blob(t, 8, 30, 44, 8); blob(t, 20, 14, 6, 6); blob(t, 32, 14, 6, 6)
        val ft = GlyphFeatures.extract(t)!!
        assertEquals(2, ft.dotsAbove)
        assertTrue(GlyphFeatures.compatibility(ft, "ت") > GlyphFeatures.compatibility(ft, "ب"))
    }

    @Test fun templateMatchesItself() {
        val a = BinImage(32, 32); blob(a, 14, 4, 4, 24)          // شبیه «ا»
        val r = BinImage(32, 32); blob(r, 4, 14, 24, 4)          // افقی
        val clf = TemplateClassifier({ listOf(Template("ا", a, false), Template("ـ", r, false)) })
        val test = BinImage(48, 48); blob(test, 22, 6, 5, 36)
        assertEquals("ا", clf.classify(test).first().letter)
    }

    @Test fun uniformGridFallback() {
        val cells = GridDetector.detect(GrayImage(200, 200, IntArray(40000) { 128 }))
        assertEquals(16, cells.size)
        assertTrue(cells[5].x in 50..60)
    }

    @Test fun detectsGapsBetweenTiles() {
        // کاشی‌های روشن با شکاف تیره ۸ پیکسلی در مختصات غیر یکنواخت کمی
        val w = 400
        val img = GrayImage(w, w, IntArray(w * w) { 200 })
        val cuts = intArrayOf(96, 202, 300)
        for (c in cuts) for (i in 0 until w) for (d in -4..4) { img[c + d, i] = 40; img[i, c + d] = 40 }
        val cells = GridDetector.detect(img)
        assertTrue(kotlin.math.abs(cells[1].x - 96) < 14)
        assertTrue(kotlin.math.abs(cells[4].y - 202) < 14)
    }
}
