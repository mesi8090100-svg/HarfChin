package ir.harfchin.ocr

import ir.harfchin.core.model.Tile
import org.junit.Assert.*
import org.junit.Test
import java.io.File

/**
 * تستهای TileReader با کاشیهای مصنوعی ۱۰۰×۱۰۰ (زمینه روشن ۲۲۰، جوهر ۳۰) و قالبهای واقعی assets.
 * اعداد فاصله همینگ با پیادهسازی پایتونی همین الگوریتم سنجیده شدند (ت↔ث: ۲۳۷، ۳↔۱: ۵۷۶).
 */
class TileReaderTest {
    private fun tile(vararg r: IntArray): GrayImage {
        val g = GrayImage(100, 100, IntArray(10000) { 220 })
        for ((x, y, w, h) in r.map { listOf(it[0], it[1], it[2], it[3]) }) for (yy in y until y + h) for (xx in x until x + w) g[xx, yy] = 30
        return g
    }
    private fun rect(x: Int, y: Int, w: Int, h: Int) = intArrayOf(x, y, w, h)
    private val body = rect(12, 60, 52, 12)
    private val teh = tile(body, rect(24, 42, 8, 8), rect(42, 42, 8, 8))                       // ت: دو نقطه بالا
    private val theh = tile(body, rect(20, 44, 8, 8), rect(34, 44, 8, 8), rect(27, 34, 8, 8))   // ث: سه نقطه بالا
    private val one = tile(body, rect(82, 6, 4, 20))
    private val three = tile(body, rect(75, 6, 18, 3), rect(75, 14, 18, 3), rect(75, 22, 18, 3), rect(90, 6, 3, 19))

    private fun t(letter: String, img: GrayImage) = Template(letter, TileReader.letterGlyph(img)!!, false)
    private fun d(v: String, img: GrayImage) = Template(v, TileReader.digitGlyph(img)!!, false)
    private val digits = listOf(d("1", one), d("1", one))

    @Test fun unknownLetterFallsBackAndStaysYellow() {
        // فقط «ت» قالب دارد؛ «ث» از همه دور است → فالبک صدا زده میشود و نتیجهاش با زرد ثبت میشود
        val reader = TileReader(listOf(t("ت", teh), t("ت", teh)), digits)
        var called = false
        val r = reader.read(theh) { called = true; TileReader.Reading(Tile("ث", 1, 0.5f, listOf("ث")), null) }
        assertTrue(called)
        assertEquals("ث", r.tile.letter)
        assertTrue(r.tile.needsReview)
        assertTrue("ت" in r.tile.alternatives)
    }

    @Test fun knownLetterDoesNotCallFallback() {
        val reader = TileReader(listOf(t("ت", teh), t("ت", teh)), digits)
        var called = false
        val r = reader.read(teh) { called = true; null }
        assertFalse(called); assertEquals("ت", r.tile.letter)
    }

    @Test fun digitLeaveOneOut() {
        val d = TileReader.loadTemplates(assets("bazambazi_digits.bin").inputStream())
        var silent = 0
        d.forEachIndexed { i, s ->
            val r = d.filterIndexed { j, _ -> j != i }.groupBy { it.letter }
                .mapValues { (_, v) -> v.minOf { t -> (0 until 1024).count { k -> t.glyph.px[k] != s.glyph.px[k] } } }.entries.sortedBy { it.value }
            if (r[0].key != s.letter && r[0].value <= TileReader.MAX_DIGIT_DISTANCE && r[1].value - r[0].value >= 40) silent++
        }
        assertEquals(0, silent)
    }

    @Test fun digitThreeFromFallback() {
        // bazambazi_digits فقط ۱ و ۲ دارد؛ «۳» باید از فالبک (TemplateStore.digits) بیاید و زرد شود
        val reader = TileReader(listOf(t("ت", teh), t("ت", teh)), digits)
        val img = tile(body, rect(24, 42, 8, 8), rect(42, 42, 8, 8), rect(75, 6, 18, 3), rect(75, 14, 18, 3), rect(75, 22, 18, 3), rect(90, 6, 3, 19))
        val r = reader.read(img) { TileReader.Reading(Tile("ت", 3), null) }
        assertEquals(3, r.tile.multiplier)
        assertTrue(r.tile.needsReview)
    }

    @Test fun singleSampleLetterNeedsReview() {
        val reader = TileReader(listOf(t("ت", teh)), digits)
        assertTrue(reader.read(teh).tile.needsReview)
    }

    @Test fun dotConflictFlagsLookalikePair() {
        // قالب «ت» ولی تصویر سه نقطه دارد → نباید بیصدا «ت» ثبت شود
        assertEquals("ث", TileReader.dotConflict("ت", TileReader.letterGlyph(theh)!!))
        assertNull(TileReader.dotConflict("ت", TileReader.letterGlyph(teh)!!))
        assertNull(TileReader.dotConflict("ل", TileReader.letterGlyph(theh)!!))   // حرف بدون جفت
        assertEquals(12, TileReader.DOT_PAIRS.size)
    }

    private fun assets(name: String) = listOf("src/main/assets/ocr/$name", "app/src/main/assets/ocr/$name").map(::File).first { it.exists() }

    @Test fun bundledTemplatesInventory() {
        val letters = TileReader.loadTemplates(assets("bazambazi_letters.bin").inputStream())
        val digitsB = TileReader.loadTemplates(assets("bazambazi_digits.bin").inputStream())
        assertEquals(296, letters.size); assertEquals(296, digitsB.size)
        // هنوز نمونه واقعی ندارند → فالبک فونتی + زرد. اگر نمونه اضافه شد، این فهرست را بهروز کنید.
        val missing = "آثحذژظ".map { it.toString() }.filter { it != "ح" }
        assertTrue(missing.none { m -> letters.any { it.letter == m } })
        listOf("ح", "ص", "ض", "ط", "غ", "چ").forEach { l -> assertTrue("$l باید نمونه داشته باشد", letters.any { it.letter == l }) }
        assertEquals(setOf("1", "2", "3"), digitsB.map { it.letter }.toSet())
    }

    @Test fun noFalseDotAlarmsOnRealSamples() {
        // روی ۱۸۴ نمونه واقعی، بررسی نقطه نباید هیچ هشدار کاذبی بدهد
        val letters = TileReader.loadTemplates(assets("bazambazi_letters.bin").inputStream())
        assertEquals(0, letters.count { TileReader.dotConflict(it.letter, it.glyph) != null })
    }

    @Test fun leaveOneOutAccuracy() {
        val letters = TileReader.loadTemplates(assets("bazambazi_letters.bin").inputStream())
        var wrongSilently = 0
        letters.forEachIndexed { i, s ->
            val rest = letters.filterIndexed { j, _ -> j != i }
            val best = rest.groupBy { it.letter }.mapValues { (_, v) -> v.minOf { t -> (0 until 1024).count { k -> t.glyph.px[k] != s.glyph.px[k] } } }
                .minByOrNull { it.value }!!
            val ranked = rest.groupBy { it.letter }.mapValues { (_, v) -> v.minOf { t -> (0 until 1024).count { k -> t.glyph.px[k] != s.glyph.px[k] } } }
                .entries.sortedBy { it.value }
            val m = ranked[1].value - ranked[0].value
            val sure = ranked[0].value <= 60 && m >= (if (ranked[0].value <= TileReader.CLOSE_MATCH) 20 else 40)
            if (best.key != s.letter && sure) wrongSilently++
        }
        assertEquals(0, wrongSilently)
    }
}
