package ir.harfchin.pipeline

import org.junit.Assert.*
import org.junit.Test

class BundledInstallerTest {
    @Test fun flagOnlyOnSuccess() {
        var flag = false; var logged = 0
        val ok = BundledInstaller.run(false, { error("disk full") }, { flag = true }, { _, _ -> logged++ })
        assertFalse(ok); assertFalse(flag); assertEquals(1, logged)
        assertTrue(BundledInstaller.run(false, { }, { flag = true }, { _, _ -> logged++ }))
        assertTrue(flag); assertEquals(1, logged)
    }

    @Test fun skipsWhenInstalled() {
        var calls = 0
        assertTrue(BundledInstaller.run(true, { calls++ }, { calls++ }, { _, _ -> calls++ }))
        assertEquals(0, calls)
    }
}
