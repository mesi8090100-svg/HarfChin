package ir.harfchin.solver

import ir.harfchin.core.model.Grid
import ir.harfchin.core.model.MultiplierMode
import org.junit.Assert.*
import org.junit.Test

class WordSolverTest {
    @Test fun neighborsAreCorrect() {
        assertEquals(3, WordSolver.NEIGHBORS[0].size)
        assertEquals(8, WordSolver.NEIGHBORS[5].size)
        assertEquals(5, WordSolver.NEIGHBORS[4].size)
    }

    @Test fun findsOnlyDictionaryWordsOnAdjacentPaths() {
        val g = Grid.of("کارگ" + "ندار" + "بستم" + "هوزی")
        val trie = Trie.of(listOf("کار", "کارگر", "کارگردان", "گرد", "دار", "بست", "سبز", "نان"))
        val res = WordSolver(trie).solve(g, WordSolver.Config(minLength = 3))
        val words = res.map { it.word }.toSet()
        assertTrue("کار" in words)
        assertTrue("دار" in words)
        assertTrue("بست" in words)
        assertFalse("نان" in words)          // فقط یک ن در جدول؛ تکرار خانه ممنوع
        for (w in res) {
            assertEquals(w.path.size, w.path.toSet().size)  // هر خانه یک بار
            w.path.zipWithNext().forEach { (a, b) -> assertTrue(b in WordSolver.NEIGHBORS[a]) }
            assertEquals(w.word, w.path.joinToString("") { g.tiles[it].letter })
        }
        assertEquals(words.size, res.size)    // بدون تکرار
    }

    @Test fun cellNotReused() {
        val g = Grid.of("ابxxxxxxxxxxxxxx".replace('x', 'ژ'))
        val res = WordSolver(Trie.of(listOf("ابا", "اب"))).solve(g, WordSolver.Config(minLength = 2))
        assertEquals(listOf("اب"), res.map { it.word })
    }

    @Test fun multipliersLetterAndWord() {
        val m = IntArray(16) { 1 }.also { it[0] = 3; it[1] = 2 }
        val g = Grid.of("کارژژژژژژژژژژژژژ", m)
        val trie = Trie.of(listOf("کار"))
        val letter = WordSolver(trie).solve(g, WordSolver.Config(minLength = 3)).single()
        assertEquals(3 + 2 + 1, letter.score)
        val word = WordSolver(trie).solve(g, WordSolver.Config(minLength = 3, multiplierMode = MultiplierMode.WORD)).single()
        assertEquals(3 * 6, word.score)
    }

    @Test fun letterValuesParsed() {
        assertEquals(mapOf('ا' to 1, 'ژ' to 5), Scoring.parseLetterValues("ا=1، ژ=5"))
    }

    @Test fun fullBoardIsFast() {
        val words = (1..30000).map { i -> buildString { var x = i; repeat(5) { append("ابپتجدرزسکگلمنوهی"[x % 17]); x /= 7 } } }
        val trie = Trie.of(words)
        val g = Grid.of("ابپتجدرزسکگلمنوه")
        val t0 = System.nanoTime(); WordSolver(trie).solve(g); val ms = (System.nanoTime() - t0) / 1e6
        assertTrue("took $ms ms", ms < 500)
    }
}
