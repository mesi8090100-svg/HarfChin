package ir.harfchin.solver

import ir.harfchin.core.model.Grid
import ir.harfchin.core.model.Tile
import org.junit.Assert.assertEquals
import org.junit.Test
import java.io.File
import kotlin.random.Random

/**
 * اثبات درستی: حلکننده (Trie + DFS) با یک جستجوی کاملاً مستقل (برای هر کلمه فرهنگ لغت، همه مسیرها)
 * روی ۳۰ جدول تصادفی مقایسه میشود. باید هم مجموعه کلمات و هم بیشترین امتیاز هر کلمه دقیقاً یکی باشد.
 */
class SolverBruteForceTest {
    private val words: List<String> by lazy {
        listOf("src/main/assets/dictionaries/common_fa.txt", "app/src/main/assets/dictionaries/common_fa.txt")
            .map(::File).first { it.exists() }.readLines().map { it.trim() }.filter { it.length in 2..16 }
    }

    private fun brute(g: Grid, minLen: Int): Map<String, Int> {
        val out = HashMap<String, Int>()
        val letters = g.tiles.map { it.letter }
        for (w in words) {
            if (w.length < minLen) continue
            var best = -1
            fun f(k: Int, c: Int, used: Int, v: Int) {
                if (letters[c] != w[k].toString()) return
                val u = used or (1 shl c); val nv = v + g.tiles[c].multiplier
                if (k == w.length - 1) { if (nv > best) best = nv; return }
                for (n in WordSolver.NEIGHBORS[c]) if (u and (1 shl n) == 0) f(k + 1, n, u, nv)
            }
            for (c in 0 until 16) f(0, c, 0, 0)
            if (best >= 0) out[w] = best
        }
        return out
    }

    @Test fun matchesBruteForce() {
        val trie = Trie.of(words)
        val freq = words.joinToString("").groupingBy { it }.eachCount().toList()
        val total = freq.sumOf { it.second }
        val rnd = Random(7)
        fun pick(): Char { var r = rnd.nextInt(total); for ((c, n) in freq) { r -= n; if (r < 0) return c }; return freq[0].first }
        repeat(30) {
            val g = Grid(List(16) { Tile(pick().toString(), listOf(1, 1, 1, 2, 3)[rnd.nextInt(5)]) })
            val got = WordSolver(trie).solve(g, WordSolver.Config(minLength = 3)).associate { it.word to it.score }
            assertEquals(brute(g, 3), got)
        }
    }
}
