package ir.harfchin.solver

import ir.harfchin.core.model.FoundWord
import org.junit.Assert.assertEquals
import org.junit.Test

class TopWordsTest {
    private fun w(s: String, sc: Int, rare: Boolean = false) = FoundWord(s, emptyList(), sc, rare = rare)

    @Test fun commonBeforeRareAtSameScore() {
        val r = TopWords.pick(listOf(w("رضاعه", 8, true), w("عارضه", 8), w("عرضه", 7)), emptySet())
        assertEquals(listOf("عارضه", "رضاعه", "عرضه"), r.map { it.word })
    }

    @Test fun rareNeedsThreeMorePointsToGoFirst() {
        // +۲ کافی نیست (عارضه ۸ قبل از حتحته ۱۰)، +۳ کافی است
        assertEquals(listOf("عارضه", "حتحته"), TopWords.pick(listOf(w("حتحته", 10, true), w("عارضه", 8)), emptySet()).map { it.word })
        assertEquals(listOf("حتحته", "عارضه"), TopWords.pick(listOf(w("حتحته", 11, true), w("عارضه", 8)), emptySet()).map { it.word })
    }

    @Test fun usedWordsMoveDownAndNextComesUp() {
        val all = (1..10).map { w("ک$it", 20 - it) }
        val r = TopWords.pick(all, setOf("ک1", "ک2"))
        assertEquals(listOf("ک3", "ک4", "ک5", "ک6", "ک7", "ک8", "ک1", "ک2"), r.map { it.word })
    }
}
