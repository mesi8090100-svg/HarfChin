package ir.harfchin.dictionary

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class OnlineDictionariesTest {
    @Test fun dehkhodaDropsPhrases() {
        val src = OnlineDictionaries.SOURCES.first { it.id == "dehkhoda" }
        val txt = OnlineDictionaries.prepare(src, """["آب","آب آسیا","نان","مخلف"]""")
        assertEquals(setOf("آب", "نان", "مخلف"), DictionaryParser.parse(txt, DictFormat.TXT))
    }

    @Test fun sourcesHaveFallbackUrls() {
        OnlineDictionaries.SOURCES.forEach { assertTrue(it.urls.size >= 2 && it.urls.all { u -> u.startsWith("https://") }) }
    }
}
