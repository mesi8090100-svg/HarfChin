package ir.harfchin.dictionary

import org.junit.Assert.assertEquals
import org.junit.Test

class TextDecodingTest {
    @Test fun utf8() {
        val r = TextDecoding.decode("کتاب\nپدر".toByteArray(Charsets.UTF_8))
        assertEquals(TextDecoding.Detected.UTF8, r.encoding)
        assertEquals("کتاب\nپدر", r.text)
    }

    @Test fun utf8Bom() {
        val r = TextDecoding.decode(byteArrayOf(0xEF.toByte(), 0xBB.toByte(), 0xBF.toByte()) + "آب".toByteArray())
        assertEquals(TextDecoding.Detected.UTF8_BOM, r.encoding)
        assertEquals("آب", r.text)
    }

    @Test fun windows1256() {
        // «ي» عربی در 1256 وجود دارد؛ نرمالساز بعداً آن را به «ی» تبدیل میکند
        val src = "پدر\nگل\nكتاب\nميز"
        val r = TextDecoding.decode(src.toByteArray(TextDecoding.WINDOWS_1256))
        assertEquals(TextDecoding.Detected.WINDOWS_1256, r.encoding)
        assertEquals(src, r.text)
        assertEquals(setOf("پدر", "گل", "کتاب", "میز"), DictionaryParser.parse(r.text, DictFormat.TXT))
    }

    @Test fun utf16le() {
        val r = TextDecoding.decode(byteArrayOf(0xFF.toByte(), 0xFE.toByte()) + "نان".toByteArray(Charsets.UTF_16LE))
        assertEquals("نان", r.text)
    }
}
