package ir.harfchin.dictionary

import ir.harfchin.core.PersianNormalizer
import org.junit.Assert.*
import org.junit.Test

class DictionaryParserTest {
    @Test fun normalizesArabicLetters() {
        assertEquals("کتاب", PersianNormalizer.normalize("كتاب"))
        assertEquals("میز", PersianNormalizer.normalize("ميز"))
        assertEquals("میخواهم", PersianNormalizer.normalize("می\u200Cخواهم"))
        assertEquals("کتاب", PersianNormalizer.normalize("کِتابْ"))
    }

    @Test fun txt() {
        val w = DictionaryParser.parse("\uFEFFکار\nكارگردان 120\n# comment\nabc\n\nکار\n", DictFormat.TXT)
        assertEquals(setOf("کار", "کارگردان"), w)
    }

    @Test fun csvWithHeader() {
        val w = DictionaryParser.parse("id,word,freq\n1,\"کتاب\",5\n2,دفتر,3\n", DictFormat.CSV)
        assertEquals(setOf("کتاب", "دفتر"), w)
    }

    @Test fun csvNoHeader() = assertEquals(setOf("آب", "نان"), DictionaryParser.parse("آب,1\nنان,2", DictFormat.CSV))

    @Test fun jsonShapes() {
        assertEquals(setOf("آب", "نان"), DictionaryParser.parse("""["آب","نان"]""", DictFormat.JSON))
        assertEquals(setOf("آب"), DictionaryParser.parse("""[{"word":"آب","mean":"water"}]""", DictFormat.JSON))
        assertEquals(setOf("آب"), DictionaryParser.parse("""{"words":["آب"]}""", DictFormat.JSON))
        assertEquals(setOf("آب", "نان"), DictionaryParser.parse("""{"آب":"water","نان":"bread"}""", DictFormat.JSON))
    }

    @Test fun detect() {
        assertEquals(DictFormat.CSV, DictionaryParser.detect("a.CSV"))
        assertEquals(DictFormat.JSON, DictionaryParser.detect("a.json"))
        assertEquals(DictFormat.TXT, DictionaryParser.detect("a"))
    }
}
