package ir.harfchin.dictionary

import org.junit.Assert.*
import org.junit.Test
import java.nio.file.Files

class DictionaryRepositoryTest {
    @Test fun importToggleDeleteAndTrie() {
        val repo = DictionaryRepository(Files.createTempDirectory("hc").toFile())
        val a = repo.importText("A", "a.txt", "کار\nدار")
        val b = repo.importText("B", "b.json", """["نان"]""")
        assertEquals(2, repo.list().size)
        assertEquals(2, a.wordCount)
        assertTrue(repo.activeTrie().contains("نان"))
        repo.setEnabled(b.id, false)
        assertFalse(repo.activeTrie().contains("نان"))
        assertTrue(repo.activeTrie().contains("کار"))
        repo.delete(a.id)
        assertEquals(listOf("B"), repo.list().map { it.name })
    }

    @Test(expected = IllegalArgumentException::class)
    fun rejectsEmpty() { DictionaryRepository(Files.createTempDirectory("hc").toFile()).importText("x", "x.txt", "hello\n123") }
}
