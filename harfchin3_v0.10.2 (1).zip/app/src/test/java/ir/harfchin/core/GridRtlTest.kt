package ir.harfchin.core

import ir.harfchin.core.model.Grid
import org.junit.Assert.assertEquals
import org.junit.Test
import java.io.File

class GridRtlTest {
    @Test fun rowsAreReversed() {
        // ردیف اول بازی (از راست): ک ت ا ب  → اندیس از چپ: ب ا ت ک
        val typed = "کتابمنزلسیبدرودم"
        assertEquals(16, typed.length)
        val g = Grid.fromRtlRows(typed, IntArray(16) { it + 1 })
        assertEquals("باتک", g.tiles.take(4).joinToString("") { it.letter })
        assertEquals(listOf(4, 3, 2, 1), g.tiles.take(4).map { it.multiplier })
        assertEquals("لزنم", g.tiles.subList(4, 8).joinToString("") { it.letter })
        assertEquals("مدور", g.tiles.subList(12, 16).joinToString("") { it.letter })
    }

    @Test fun bundledDictionaryCount() {
        // ۱۰٬۵۹۶ خط بدون newline آخر؛ `wc -l` عدد ۱۰٬۵۹۵ نشان میدهد چون خط آخر را نمیشمارد
        val f = listOf("src/main/assets/dictionaries/common_fa.txt", "app/src/main/assets/dictionaries/common_fa.txt").map(::File).first { it.exists() }
        val words = ir.harfchin.dictionary.DictionaryParser.parse(f.readText(), ir.harfchin.dictionary.DictFormat.TXT)
        assertEquals(10_596, words.size)
    }
}
