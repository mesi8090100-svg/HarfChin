package ir.harfchin.pipeline

/**
 * نصب یکباره فرهنگ پیشفرض. فلگ «نصب شد» فقط بعد از نصب موفق ثبت میشود؛
 * اگر خطا رخ دهد، لاگ میشود و در اجرای بعدی دوباره تلاش میشود.
 * مستقل از Android تا تست واحد داشته باشد.
 */
object BundledInstaller {
    fun run(
        alreadyInstalled: Boolean,
        install: () -> Unit,
        markInstalled: () -> Unit,
        log: (String, Throwable) -> Unit
    ): Boolean {
        if (alreadyInstalled) return true
        return try {
            install(); markInstalled(); true
        } catch (e: Exception) {
            log("نصب فرهنگ پیشفرض ناموفق بود؛ در اجرای بعد دوباره تلاش میشود", e); false
        }
    }
}
