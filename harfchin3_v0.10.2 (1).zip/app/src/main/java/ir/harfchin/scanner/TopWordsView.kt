package ir.harfchin.scanner

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import ir.harfchin.core.model.FoundWord
import ir.harfchin.pipeline.ScanPipeline
import ir.harfchin.scanner.OverlayStyle as St
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

/**
 * ۶ کلمه پرامتیاز همیشه کنار ذرهبین می‌ماند تا لازم نباشد برای یادآوری دوباره پنل را باز کنید.
 * لمس یک کلمه = علامت «زده شد». «⚠ حرف مردد» و «📋 همه کلمهها» پنل کامل (جدول قابل اصلاح + همه کلمات) را باز میکنند.
 */
@SuppressLint("ViewConstructor")
class TopWordsView(
    ctx: Context,
    private val pipeline: ScanPipeline,
    private val openFull: () -> Unit,
    private val onCollapse: () -> Unit = {}
) : LinearLayout(ctx) {
    /** جمعشده: تا اسکن بعدی چیزی کنار ذرهبین نمایش داده نمیشود */
    private var collapsed = false

    fun collapse() { collapsed = true; removeAllViews(); visibility = View.GONE }

    private var job: Job? = null
    private val used = HashSet<String>()
    private var lastGrid: Any? = null
    private var right = false
    private fun dp(v: Int) = St.dp(context, v.toFloat()).toInt()

    init {
        orientation = VERTICAL
        layoutDirection = View.LAYOUT_DIRECTION_RTL
        visibility = View.GONE
    }

    fun alignRight(r: Boolean) { if (r != right) { right = r; gravity = if (r) Gravity.END else Gravity.START } }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        job = CoroutineScope(Dispatchers.Main).launch {
            pipeline.state.map { it.grid to it.words }.distinctUntilChanged().collect { (g, w) ->
                if (g != lastGrid) { used.clear(); lastGrid = g; collapsed = false }
                render(w)
            }
        }
    }

    override fun onDetachedFromWindow() { job?.cancel(); super.onDetachedFromWindow() }

    private fun render(words: List<FoundWord>) {
        removeAllViews()
        if (collapsed) { visibility = View.GONE; return }
        val grid = pipeline.state.value.grid
        val unsure = grid.tiles.count { it.needsReview }
        if (words.isEmpty() && unsure == 0) { visibility = View.GONE; return }
        visibility = View.VISIBLE
        // خانههای مردد: دکمه زرد بالای فهرست؛ لمس = پنل اصلاح
        if (unsure > 0) addView(St.pill(context, "⚠ $unsure حرف مردد · اصلاح", St.rounded(context, St.UNSURE, 14f),
            textColor = St.INK, sizeSp = 12f) { openFull() }.apply { setPadding(dp(10), dp(5), dp(10), dp(5)) },
            LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(4) })
        val top = ir.harfchin.solver.TopWords.pick(words, used)
        top.forEach { w ->
            val done = w.word in used
            val lc = St.lengthColor(w.word.length)
            val chip = LinearLayout(context).apply {
                orientation = HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                background = St.pressable(context, St.rounded(context, if (done) 0xCC6B6375.toInt() else 0xF2221D2A.toInt(), 14f), 14f)
                setPadding(dp(10), dp(5), dp(6), dp(5)); elevation = dp(4).toFloat(); isClickable = true
                setOnClickListener {
                    if (done) used.remove(w.word) else used.add(w.word)
                    pipeline.select(w); render(pipeline.state.value.words)
                }
            }
            chip.addView(View(context).apply { background = St.rounded(context, lc, 3f) }, LayoutParams(dp(4), dp(18)))
            chip.addView(St.text(context, w.word, 16f, if (done) 0xFFBDB5C6.toInt() else Color.WHITE, true).apply {
                setPadding(dp(6), 0, dp(6), 0)
                if (done) paintFlags = paintFlags or android.graphics.Paint.STRIKE_THRU_TEXT_FLAG
            })
            if (w.usesUncertainTile) chip.addView(St.text(context, "⚠", 12f, St.UNSURE, true).apply { setPadding(0, 0, dp(4), 0) })
            if (w.rare) chip.addView(St.text(context, "🎲", 11f, Color.WHITE).apply { setPadding(0, 0, dp(4), 0) })
            chip.addView(St.text(context, "${w.score}", 12f, Color.WHITE, true).apply {
                gravity = Gravity.CENTER; background = St.rounded(context, if (done) 0x55FFFFFF else St.CORAL, 9f)
                setPadding(dp(7), dp(1), dp(7), dp(1))
            })
            addView(chip, LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(4) })
        }
        if (words.size > top.size) addView(St.pill(context, "📋 همه ${words.size} کلمه ›",
            St.gradient(context, intArrayOf(St.PLUM, St.GRAPE), 14f), sizeSp = 13f) { openFull() }
            .apply { setPadding(dp(12), dp(6), dp(12), dp(6)) })
        // جمع کردن همه پنجرهها؛ فقط ذرهبین میماند
        addView(St.pill(context, "⌄ جمع کردن", St.rounded(context, 0xCC221D2A.toInt(), 14f), sizeSp = 12f) { onCollapse() }
            .apply { setPadding(dp(12), dp(5), dp(12), dp(5)) },
            LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT).apply { topMargin = dp(4) })
    }
}
