package ir.harfchin.scanner

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.view.Gravity
import android.view.View
import android.widget.TextView
import androidx.core.content.res.ResourcesCompat
import ir.harfchin.R

/** ظاهر مشترک پنجرههای شناور — همان رنگها و فونت صفحه اصلی */
object OverlayStyle {
    const val PLUM = 0xFF4A3466.toInt()
    const val GRAPE = 0xFF8E44AD.toInt()
    const val BERRY = 0xFFE85D9A.toInt()
    const val CORAL = 0xFFFF7A59.toInt()
    const val SUN = 0xFFFFC23D.toInt()
    const val MINT = 0xFF2EC4A6.toInt()
    const val SKY = 0xFF4D9DE0.toInt()
    const val CREAM = 0xFFFAF6EE.toInt()
    const val TILE = 0xFFF6E2B3.toInt()
    const val TILE_EDGE = 0xFFD9A55B.toInt()
    const val INK = 0xFF3B2414.toInt()
    const val PATH = 0xFF7CB342.toInt()
    const val PATH_START = 0xFF2E7D32.toInt()
    const val UNSURE = 0xFFFFD54F.toInt()

    fun lengthColor(len: Int) = when { len <= 3 -> SKY; len == 4 -> MINT; len == 5 -> SUN; len == 6 -> CORAL; else -> BERRY }

    private var regular: Typeface? = null
    private var bold: Typeface? = null
    fun font(ctx: Context, isBold: Boolean = false): Typeface {
        if (isBold) bold?.let { return it } else regular?.let { return it }
        val tf = runCatching { ResourcesCompat.getFont(ctx, if (isBold) R.font.vazirmatn_bold else R.font.vazirmatn_regular) }
            .getOrNull() ?: if (isBold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        if (isBold) bold = tf else regular = tf
        return tf
    }

    fun dp(ctx: Context, v: Float) = (v * ctx.resources.displayMetrics.density)

    fun rounded(ctx: Context, color: Int, radiusDp: Float, strokeColor: Int? = null): GradientDrawable =
        GradientDrawable().apply {
            setColor(color); cornerRadius = dp(ctx, radiusDp)
            strokeColor?.let { setStroke(dp(ctx, 1.5f).toInt(), it) }
        }

    fun gradient(ctx: Context, colors: IntArray, radiusDp: Float, orientation: GradientDrawable.Orientation = GradientDrawable.Orientation.LEFT_RIGHT) =
        GradientDrawable(orientation, colors).apply { cornerRadius = dp(ctx, radiusDp) }

    /** پسزمینه با افکت لمس (ripple) */
    fun pressable(ctx: Context, bg: Drawable, radiusDp: Float): Drawable =
        RippleDrawable(ColorStateList.valueOf(0x33FFFFFF), bg, rounded(ctx, Color.WHITE, radiusDp))

    /** دکمه گرد رنگی با متن سفید (یا متن تیره روی رنگ روشن) */
    fun pill(ctx: Context, text: String, bg: Drawable, textColor: Int = Color.WHITE, sizeSp: Float = 15f, onClick: (() -> Unit)?): TextView =
        TextView(ctx).apply {
            this.text = text; textSize = sizeSp; gravity = Gravity.CENTER; maxLines = 1
            typeface = font(ctx, true); setTextColor(textColor)
            val h = dp(ctx, 16f).toInt(); val v = dp(ctx, 10f).toInt()
            setPadding(h, v, h, v)
            background = if (onClick != null) pressable(ctx, bg, 14f) else bg
            if (onClick != null) { isClickable = true; setOnClickListener { onClick() } }
            elevation = dp(ctx, 3f)
        }

    fun text(ctx: Context, s: String, sizeSp: Float, color: Int, isBold: Boolean = false) = TextView(ctx).apply {
        text = s; textSize = sizeSp; setTextColor(color); typeface = font(ctx, isBold)
    }

    fun shadow(v: View, ctx: Context, dpv: Float = 8f) { v.elevation = dp(ctx, dpv) }
}
