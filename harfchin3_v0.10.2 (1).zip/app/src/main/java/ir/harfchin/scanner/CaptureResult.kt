package ir.harfchin.scanner

import android.graphics.Bitmap

/** نتیجه گرفتن تصویر از صفحه */
sealed interface CaptureResult {
    data class Success(val bitmap: Bitmap) : CaptureResult
    /** فریم کاملاً سیاه بود؛ معمولاً یعنی بازی FLAG_SECURE دارد و اجازه ضبط نمیدهد */
    data object Blocked : CaptureResult
    data class Failed(val reason: String) : CaptureResult
}
