package ir.harfchin.scanner

import android.content.Context
import kotlinx.serialization.Serializable
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

/** موقعیت و اندازه کادر انتخاب جدول، بر حسب پیکسل صفحه */
@Serializable
data class FrameRect(val x: Int, val y: Int, val width: Int, val height: Int)

/** ذخیره کادر برای هر پروفایل (نام بازی/چیدمان + اندازه و جهت صفحه) */
class FrameProfileStore(context: Context) {
    private val prefs = context.getSharedPreferences("frame_profiles", Context.MODE_PRIVATE)
    private val json = Json

    fun key(profile: String, screenW: Int, screenH: Int) = "$profile|${screenW}x$screenH"

    fun load(profile: String, w: Int, h: Int): FrameRect? =
        prefs.getString(key(profile, w, h), null)?.let { runCatching { json.decodeFromString<FrameRect>(it) }.getOrNull() }

    fun save(profile: String, w: Int, h: Int, r: FrameRect) =
        prefs.edit().putString(key(profile, w, h), json.encodeToString(r)).putString("last_profile", profile).apply()

    fun profiles(): List<String> = (prefs.all.keys.filter { it.contains('|') }.map { it.substringBefore('|') } +
            listOf("default")).distinct()

    var lastProfile: String
        get() = prefs.getString("last_profile", "default") ?: "default"
        set(v) = prefs.edit().putString("last_profile", v).apply()

    fun default(w: Int, h: Int): FrameRect {
        val side = (minOf(w, h) * 0.86f).toInt()
        return FrameRect((w - side) / 2, (h * 0.45f).toInt() - side / 2, side, side)
    }
}
