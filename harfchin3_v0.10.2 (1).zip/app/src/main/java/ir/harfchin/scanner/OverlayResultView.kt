package ir.harfchin.scanner

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import ir.harfchin.core.PersianNormalizer
import ir.harfchin.pipeline.ScanPipeline
import ir.harfchin.scanner.OverlayStyle as St
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

/** پنل نتیجه داخل پنجره شناور: جدول (لمس = اصلاح)، دکمه حل، فهرست کلمات (لمس = نمایش مسیر) */
@SuppressLint("ViewConstructor")
class OverlayResultView(ctx: Context, private val pipeline: ScanPipeline, onClose: () -> Unit) : LinearLayout(ctx) {
    private val gridView = GridLayout(ctx).apply { columnCount = 4; layoutDirection = View.LAYOUT_DIRECTION_LTR }
    private val list = LinearLayout(ctx).apply { orientation = VERTICAL }
    private val scroll = ScrollView(ctx).apply { addView(list); isVerticalScrollBarEnabled = false }
    private val status = St.text(ctx, "", 13f, Color.WHITE).apply { maxLines = 2; alpha = 0.9f }
    private val selWord = St.text(ctx, "", 18f, Color.WHITE, true).apply { gravity = Gravity.CENTER }
    private var job: Job? = null
    private var picking = -1
    /** دکمه «جمع کردن» سرصفحه: بستن پنل + کلمات کنار ذرهبین */
    var onCollapseAll: (() -> Unit)? = null
    private fun dp(v: Int) = St.dp(context, v.toFloat()).toInt()

    init {
        orientation = VERTICAL
        layoutDirection = View.LAYOUT_DIRECTION_RTL
        background = GradientDrawable().apply {
            setColor(St.CREAM)
            val r = St.dp(ctx, 26f); cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f)
        }
        clipToOutline = true
        St.shadow(this, ctx, 16f)

        // سرصفحه گرادیان
        val head = LinearLayout(ctx).apply {
            orientation = HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(St.PLUM, St.GRAPE, St.BERRY))
            setPadding(dp(14), dp(8), dp(14), dp(10))
        }
        val handle = View(ctx).apply { background = St.rounded(ctx, 0x66FFFFFF, 3f) }
        val headWrap = LinearLayout(ctx).apply { orientation = VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
        headWrap.background = head.background
        headWrap.addView(handle, LayoutParams(dp(40), dp(5)).apply { topMargin = dp(6) })
        head.background = null
        val titleCol = LinearLayout(ctx).apply { orientation = VERTICAL }
        titleCol.addView(St.text(ctx, "حرفچین", 18f, Color.WHITE, true))
        titleCol.addView(status)
        head.addView(titleCol, LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f))
        head.addView(St.pill(ctx, "حل", St.gradient(ctx, intArrayOf(St.MINT, 0xFF26A69A.toInt()), 14f)) { picking = -1; pipeline.solve() })
        head.addView(St.pill(ctx, "⏻", St.rounded(ctx, 0x55E53935, 14f)) { ScreenCaptureService.instance?.stopSelf() },
            LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT).apply { marginStart = dp(8) })
        head.addView(St.pill(ctx, "⌄", St.rounded(ctx, 0x33FFFFFF, 14f)) { onCollapseAll?.invoke() ?: onClose() },
            LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT).apply { marginStart = dp(8) })
        headWrap.addView(head, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT))
        addView(headWrap)

        val body = LinearLayout(ctx).apply { orientation = HORIZONTAL; setPadding(dp(10), dp(10), dp(10), dp(6)) }
        val boardCol = LinearLayout(ctx).apply {
            orientation = VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            background = St.rounded(ctx, St.PLUM, 20f); setPadding(dp(6), dp(6), dp(6), dp(8))
        }
        boardCol.addView(gridView)
        boardCol.addView(selWord, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT).apply { topMargin = dp(4) })
        body.addView(boardCol, LayoutParams(dp(188), LayoutParams.WRAP_CONTENT))
        body.addView(scroll, LayoutParams(0, LayoutParams.MATCH_PARENT, 1f).apply { marginStart = dp(10) })
        addView(body, LayoutParams(LayoutParams.MATCH_PARENT, 0, 1f))
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        job = CoroutineScope(Dispatchers.Main).launch {
            pipeline.state.map { Triple(it.grid, it.words, it.selectedWord) to (it.busy to it.message) }
                .distinctUntilChanged().collect { render() }
        }
    }

    override fun onDetachedFromWindow() { job?.cancel(); super.onDetachedFromWindow() }

    private fun render() {
        val s = pipeline.state.value
        status.text = if (s.busy) "در حال پردازش…" else s.message ?: if (s.words.isNotEmpty()) "${s.words.size} کلمه پیدا شد" else "روی خانه بزنید تا اصلاح شود"
        val sel = s.selectedWord?.path.orEmpty()
        selWord.text = s.selectedWord?.let { "${it.word} · ${it.score}" } ?: ""
        selWord.visibility = if (s.selectedWord != null) View.VISIBLE else View.GONE
        gridView.removeAllViews()
        s.grid.tiles.forEachIndexed { i, t ->
            val order = sel.indexOf(i)
            val bg = when { order == 0 -> St.PATH_START; order > 0 -> St.PATH; t.needsReview -> St.UNSURE; i == picking -> St.SKY; else -> St.TILE }
            val cell = FrameLayout(context).apply {
                background = St.pressable(context, android.graphics.drawable.LayerDrawable(arrayOf(
                    St.rounded(context, St.TILE_EDGE, 10f), St.rounded(context, bg, 10f)
                )).apply { setLayerInset(1, 0, 0, 0, dp(3)) }, 10f)
                isClickable = true; setOnClickListener { pick(i) }
            }
            cell.addView(St.text(context, t.letter.ifEmpty { "؟" }, 20f, if (order >= 0 || i == picking) Color.WHITE else St.INK, true)
                .apply { gravity = Gravity.CENTER }, FrameLayout.LayoutParams(-1, -1))
            if (t.multiplier > 1) cell.addView(St.text(context, "${t.multiplier}", 9f, Color.WHITE, true).apply {
                gravity = Gravity.CENTER; background = St.rounded(context, if (t.multiplier >= 3) St.BERRY else St.CORAL, 8f)
            }, FrameLayout.LayoutParams(dp(14), dp(14), Gravity.TOP or Gravity.END).apply { setMargins(0, dp(2), dp(2), 0) })
            gridView.addView(cell, GridLayout.LayoutParams().apply { width = dp(40); height = dp(40); setMargins(dp(2), dp(2), dp(2), dp(2)) })
        }
        if (picking >= 0) return
        list.removeAllViews()
        if (s.words.isEmpty()) {
            list.addView(St.text(context, if (s.busy) "…" else "برای دیدن کلمهها «حل» را بزنید", 14f, 0xFF7A6E80.toInt()).apply {
                gravity = Gravity.CENTER; setPadding(0, dp(24), 0, 0)
            })
            return
        }
        s.words.take(200).forEach { w ->
            val lc = St.lengthColor(w.word.length)
            val selected = w == s.selectedWord
            val row = LinearLayout(context).apply {
                orientation = HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(12), dp(8), dp(8), dp(8))
                background = St.pressable(context,
                    St.rounded(context, if (selected) (lc and 0x00FFFFFF) or 0x33000000 else Color.WHITE, 12f, if (selected) lc else null), 12f)
                isClickable = true; setOnClickListener { pipeline.select(if (selected) null else w) }
            }
            row.addView(View(context).apply { background = St.rounded(context, lc, 3f) }, LayoutParams(dp(5), dp(26)))
            row.addView(St.text(context, w.word + (if (w.rare) " 🎲" else "") + (if (w.usesUncertainTile) " ⚠" else ""), 18f, St.INK, true).apply { setPadding(dp(8), 0, 0, 0) }, LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f))
            row.addView(St.text(context, "${w.score}", 13f, Color.WHITE, true).apply {
                gravity = Gravity.CENTER; background = St.rounded(context, St.PLUM, 10f); setPadding(dp(10), dp(2), dp(10), dp(2))
            })
            list.addView(row, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(6) })
        }
    }

    /** چند خانه ۴۶dp در عرض واقعی فهرست جا میشود (حداقل ۳) */
    private fun letterColumns(): Int {
        val w = scroll.width.takeIf { it > 0 } ?: (resources.displayMetrics.widthPixels - dp(220))
        return (w / dp(46)).coerceIn(3, 8)
    }

    /** انتخاب حرف: ابتدا گزینههای پیشنهادی OCR (رنگی)، بعد امتیاز، بعد کل الفبا */
    private fun pick(i: Int) {
        picking = i
        val t = pipeline.state.value.grid.tiles[i]
        render()
        list.removeAllViews()
        list.addView(St.text(context, "حرف خانه ${i + 1}", 15f, St.INK, true))
        fun grid(cols: Int) = GridLayout(context).apply { columnCount = cols }
        fun cellLp() = GridLayout.LayoutParams().apply { width = dp(42); height = dp(42); setMargins(dp(2), dp(2), dp(2), dp(2)) }
        // اگر انتخاب، state را عوض نکند (همان حرف دوباره)، collect صدا زده نمیشود؛ پس خودمان render میکنیم
        fun done(l: String, m: Int?) { picking = -1; pipeline.setTile(i, l, m); render() }
        if (t.alternatives.isNotEmpty()) {
            val g = grid(letterColumns())
            t.alternatives.forEachIndexed { k, l ->
                val col = intArrayOf(St.MINT, St.SKY, St.GRAPE, St.BERRY)[k % 4]
                g.addView(St.pill(context, l, St.rounded(context, col, 12f), sizeSp = 19f) { done(l, null) }.apply { setPadding(0, 0, 0, 0) }, cellLp())
            }
            list.addView(g)
        }
        val mg = grid(4)
        mg.addView(St.text(context, "امتیاز:", 13f, 0xFF7A6E80.toInt()).apply { gravity = Gravity.CENTER }, cellLp())
        listOf(1 to St.SKY, 2 to St.CORAL, 3 to St.BERRY).forEach { (m, col) ->
            val on = t.multiplier == m
            mg.addView(St.pill(context, "$m", St.rounded(context, if (on) col else Color.WHITE, 12f, col),
                textColor = if (on) Color.WHITE else col) { if (t.letter.isNotEmpty()) done(t.letter, m) }.apply { setPadding(0, 0, 0, 0) }, cellLp())
        }
        list.addView(mg)
        // تعداد ستون از عرض واقعی پنل حساب میشود؛ قبلاً ۶ ستون ثابت بود و ستونهای ۵ و ۶ (ث ج ذ ر ص ض ف ق م ن) بیرون پنل بریده میشدند
        val g = grid(letterColumns())
        PersianNormalizer.TILE_LETTERS.forEach { l ->
            g.addView(St.pill(context, l, St.rounded(context, St.TILE, 12f, St.TILE_EDGE), textColor = St.INK, sizeSp = 17f) { done(l, null) }
                .apply { setPadding(0, 0, 0, 0); elevation = 0f }, cellLp())
        }
        list.addView(g)
        list.addView(St.pill(context, "انصراف", St.rounded(context, 0x1A4A3466, 12f), textColor = St.PLUM) { picking = -1; render() },
            LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT).apply { topMargin = dp(6) })
        scroll.scrollTo(0, 0)
    }
}
