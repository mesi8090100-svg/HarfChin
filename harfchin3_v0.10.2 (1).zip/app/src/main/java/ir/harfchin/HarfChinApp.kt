package ir.harfchin

import android.app.Application
import ir.harfchin.pipeline.ScanPipeline

class HarfChinApp : Application() {
    lateinit var pipeline: ScanPipeline
        private set

    override fun onCreate() {
        super.onCreate()
        pipeline = ScanPipeline(this)
        pipeline.installBundledDictionaryOnce()
    }
}
