package ir.harfchin.core

/** نرمال‌سازی متن فارسی: یکسان‌سازی حروف عربی/فارسی، حذف اعراب، نیم‌فاصله و کشیده. */
object PersianNormalizer {
    /** حروفی که در کلمات معتبر مجازند */
    const val ALPHABET = "آابپتثجچحخدذرزژسشصضطظعغفقکگلمنوهیئ"

    /** حروفی که روی کاشی‌های بازی ظاهر می‌شوند (۳۲ حرف + آ) */
    val TILE_LETTERS: List<String> = "آابپتثجچحخدذرزژسشصضطظعغفقکگلمنوهی".map { it.toString() }

    private val allowed = ALPHABET.toSet()
    private val map = mapOf(
        'ي' to 'ی', 'ى' to 'ی', 'ك' to 'ک', 'ة' to 'ه', 'ۀ' to 'ه',
        'أ' to 'ا', 'إ' to 'ا', 'ٱ' to 'ا', 'ؤ' to 'و',
        '۰' to '0', '۱' to '1', '۲' to '2', '۳' to '3', '۴' to '4',
        '۵' to '5', '۶' to '6', '۷' to '7', '۸' to '8', '۹' to '9'
    )

    fun normalize(raw: String): String {
        val sb = StringBuilder(raw.length)
        for (c in raw.trim().removePrefix("\uFEFF")) {
            if (c in '\u064B'..'\u065F' || c == '\u0670' || c == '\u200C' || c == '\u200D' ||
                c == 'ـ' || c.isWhitespace()
            ) continue
            sb.append(map[c] ?: c)
        }
        return sb.toString()
    }

    fun isValidWord(w: String, min: Int = 2, max: Int = 16): Boolean =
        w.length in min..max && w.all { it in allowed }

    fun normalizeWordOrNull(raw: String): String? = normalize(raw).takeIf { isValidWord(it) }
}
