package ir.harfchin.solver

class Trie {
    class Node {
        val children = HashMap<Char, Node>(4)
        var isWord = false
    }

    val root = Node()
    var size = 0
        private set

    fun insert(word: String) {
        if (word.isEmpty()) return
        var n = root
        for (c in word) n = n.children.getOrPut(c) { Node() }
        if (!n.isWord) { n.isWord = true; size++ }
    }

    fun contains(word: String): Boolean = step(root, word)?.isWord == true

    fun hasPrefix(prefix: String): Boolean = step(root, prefix) != null

    /** حرکت از گره n با رشته s (کاشی ممکن است چندحرفی باشد) */
    fun step(n: Node, s: String): Node? {
        var x = n
        for (c in s) x = x.children[c] ?: return null
        return x
    }

    companion object {
        fun of(words: Iterable<String>) = Trie().apply { words.forEach { insert(it) } }
    }
}
