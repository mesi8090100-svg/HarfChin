package ir.harfchin.solver

import ir.harfchin.core.PersianNormalizer
import ir.harfchin.core.model.FoundWord
import ir.harfchin.core.model.Grid
import ir.harfchin.core.model.MultiplierMode

/**
 * پیدا کردن همه کلمات معتبر جدول ۴×۴ با DFS روی ۸ همسایه و هرس با Trie.
 * هر خانه در یک کلمه فقط یک بار استفاده می‌شود. فقط کلمات موجود در Trie پذیرفته می‌شوند.
 */
class WordSolver(private val trie: Trie) {

    data class Config(
        val minLength: Int = 2,
        val multiplierMode: MultiplierMode = MultiplierMode.LETTER,
        val letterValues: Map<Char, Int> = emptyMap(),
        val defaultLetterValue: Int = 1
    )

    fun solve(grid: Grid, config: Config = Config()): List<FoundWord> {
        val best = HashMap<String, FoundWord>()
        val used = BooleanArray(16)
        val path = IntArray(16)
        val sb = StringBuilder()

        fun dfs(cell: Int, node: Trie.Node, depth: Int) {
            val letter = grid.tiles[cell].letter
            if (letter.isEmpty()) return
            val next = trie.step(node, letter) ?: return   // هرس: پیشوند در فرهنگ لغت نیست
            used[cell] = true
            path[depth] = cell
            val len = sb.length
            sb.append(letter)
            if (next.isWord && sb.length >= config.minLength) {
                val p = path.copyOf(depth + 1).toList()
                val w = sb.toString()
                val fw = FoundWord(w, p, Scoring.score(grid, p, config), p.any { grid.tiles[it].needsReview })
                val old = best[w]
                if (old == null || isBetter(fw, old)) best[w] = fw
            }
            if (next.children.isNotEmpty()) {
                for (nb in NEIGHBORS[cell]) if (!used[nb]) dfs(nb, next, depth + 1)
            }
            sb.setLength(len)
            used[cell] = false
        }

        for (c in 0 until 16) dfs(c, trie.root, 0)
        return best.values.sortedWith(
            compareByDescending<FoundWord> { it.score }
                .thenByDescending { it.word.length }
                .thenBy { it.word }
        )
    }

    private fun isBetter(a: FoundWord, b: FoundWord) =
        a.score > b.score || (a.score == b.score && !a.usesUncertainTile && b.usesUncertainTile)

    companion object {
        val NEIGHBORS: Array<IntArray> = Array(16) { i ->
            val r = i / 4; val c = i % 4
            val list = ArrayList<Int>(8)
            for (dr in -1..1) for (dc in -1..1) {
                if (dr == 0 && dc == 0) continue
                val nr = r + dr; val nc = c + dc
                if (nr in 0..3 && nc in 0..3) list.add(nr * 4 + nc)
            }
            list.toIntArray()
        }
    }
}

object Scoring {
    /** LETTER: ضریب روی امتیاز همان حرف. WORD: ضرایب در کل کلمه ضرب می‌شوند. */
    fun score(grid: Grid, path: List<Int>, config: WordSolver.Config): Int {
        var sum = 0
        var wordMul = 1
        for (i in path) {
            val t = grid.tiles[i]
            val base = t.letter.sumOf { config.letterValues[it] ?: config.defaultLetterValue }
            if (config.multiplierMode == MultiplierMode.LETTER) sum += base * t.multiplier
            else { sum += base; wordMul *= t.multiplier }
        }
        return sum * wordMul
    }

    /** "ا=1، ژ=5" → map */
    fun parseLetterValues(s: String): Map<Char, Int> =
        s.split(',', '،', '\n', ';').mapNotNull { part ->
            val kv = part.split('=', ':')
            if (kv.size != 2) return@mapNotNull null
            val k = PersianNormalizer.normalize(kv[0])
            val v = PersianNormalizer.normalize(kv[1]).toIntOrNull()
            if (k.length == 1 && v != null) k[0] to v else null
        }.toMap()
}
