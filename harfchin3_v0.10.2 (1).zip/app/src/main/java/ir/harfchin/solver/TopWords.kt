package ir.harfchin.solver

import ir.harfchin.core.model.FoundWord

object TopWords {
    const val COUNT = 6

    /**
     * جریمه ترتیبی کلمه کمیاب (فقط در دهخدا). امتیاز نمایشی عوض نمیشود، فقط جایگاه:
     * کلمه 🎲 فقط وقتی بالای کلمه رایج میآید که دست کم ۳ امتیاز بیشتر بدهد.
     * دلیل: در بازی آنلاین، امتحان کلمهای که رد میشود وقت میگیرد؛ بدون نیاز به تأیید دستی کاربر.
     */
    const val RARE_PENALTY = 2

    val ORDER: Comparator<FoundWord> = compareByDescending<FoundWord> { it.score - if (it.rare) RARE_PENALTY else 0 }
        .thenByDescending { it.score }.thenBy { it.rare }.thenByDescending { it.word.length }.thenBy { it.word }

    /** ۶ کلمه برتر: ابتدا زدهنشدهها به ترتیب، بعد چند کلمه زدهشده (خطخورده) برای یادآوری */
    fun pick(words: List<FoundWord>, used: Set<String>): List<FoundWord> {
        val sorted = words.sortedWith(ORDER)
        val fresh = sorted.filter { it.word !in used }.take(COUNT)
        val done = sorted.filter { it.word in used }.take((COUNT - fresh.size).coerceAtLeast(2))
        return fresh + done
    }
}
