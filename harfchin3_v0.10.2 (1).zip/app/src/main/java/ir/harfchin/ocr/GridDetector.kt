package ir.harfchin.ocr

/**
 * تشخیص مرز ۱۶ کاشی در تصویر برش‌خورده جدول.
 * روش: نیم‌رخ (projection) لبه‌ها در افق و عمود → پیدا کردن ۳ شکاف بین کاشی‌ها در هر جهت.
 * اگر شکاف‌ها پیدا نشد، تقسیم یکنواخت ۴×۴ (fallback).
 */
object GridDetector {

    data class Cell(val x: Int, val y: Int, val w: Int, val h: Int)

    fun detect(img: GrayImage): List<Cell> {
        val xs = findCuts(columnProfile(img), img.width) ?: uniform(img.width)
        val ys = findCuts(rowProfile(img), img.height) ?: uniform(img.height)
        val cells = ArrayList<Cell>(16)
        for (r in 0 until 4) for (c in 0 until 4) {
            // جهت راست‌به‌چپ مهم نیست: اندیس‌ها همیشه ردیف*۴+ستون از چپ هستند
            val pad = ((xs[c + 1] - xs[c]) * 0.04f).toInt()
            cells.add(Cell(xs[c] + pad, ys[r] + pad, xs[c + 1] - xs[c] - 2 * pad, ys[r + 1] - ys[r] - 2 * pad))
        }
        return cells
    }

    fun uniform(len: Int) = IntArray(5) { it * len / 4 }

    /** میانگین «فاصله از رنگ پس‌زمینه بین کاشی‌ها» برای هر ستون */
    private fun columnProfile(img: GrayImage): FloatArray {
        val p = FloatArray(img.width)
        for (x in 0 until img.width) {
            var s = 0f; var sq = 0f
            for (y in 0 until img.height) { val v = img[x, y].toFloat(); s += v; sq += v * v }
            val m = s / img.height; p[x] = m * 0.5f + kotlin.math.sqrt((sq / img.height - m * m).coerceAtLeast(0f))
        }
        return p
    }

    private fun rowProfile(img: GrayImage): FloatArray {
        val p = FloatArray(img.height)
        for (y in 0 until img.height) {
            var s = 0f; var sq = 0f
            for (x in 0 until img.width) { val v = img[x, y].toFloat(); s += v; sq += v * v }
            val m = s / img.width; p[y] = m * 0.5f + kotlin.math.sqrt((sq / img.width - m * m).coerceAtLeast(0f))
        }
        return p
    }

    /** در اطراف ۱/۴، ۲/۴، ۳/۴ به دنبال کمینه نیم‌رخ (شکاف تیره‌تر/کم‌تنوع‌تر) */
    private fun findCuts(p: FloatArray, len: Int): IntArray? {
        if (len < 40) return null
        val cuts = IntArray(5); cuts[0] = 0; cuts[4] = len
        val mean = p.average().toFloat()
        val win = len / 10
        for (k in 1..3) {
            val center = k * len / 4
            var best = center; var bv = Float.MAX_VALUE
            for (i in (center - win).coerceAtLeast(1)..(center + win).coerceAtMost(len - 2)) {
                if (p[i] < bv) { bv = p[i]; best = i }
            }
            if (bv > mean * 0.92f) return null   // شکاف واضحی نیست
            cuts[k] = best
        }
        // سازگاری فاصله‌ها
        val gaps = (0 until 4).map { cuts[it + 1] - cuts[it] }
        if (gaps.max() > gaps.min() * 1.35f) return null
        return cuts
    }

    /** جدا کردن ناحیه حرف و گوشه ضریب (بالا-راست، حدود ۳۰٪ عرض و ارتفاع) */
    fun splitTile(tile: GrayImage): Pair<GrayImage, GrayImage> {
        val cw = (tile.width * 0.32f).toInt().coerceAtLeast(1)
        val ch = (tile.height * 0.32f).toInt().coerceAtLeast(1)
        val corner = tile.crop(tile.width - cw, 0, cw, ch)
        // برای حرف، گوشه را با رنگ میانه پس‌زمینه پر می‌کنیم تا عدد ضریب با حرف قاطی نشود
        val letter = GrayImage(tile.width, tile.height, tile.px.copyOf())
        val bg = tile.px.sorted()[tile.px.size / 2]
        for (y in 0 until ch) for (x in tile.width - cw until tile.width) letter[x, y] = bg
        return letter to corner
    }
}
