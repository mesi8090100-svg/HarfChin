package ir.harfchin.ocr

import ir.harfchin.core.model.Grid

/**
 * کل خط پردازش: تصویر جدول → ۱۶ کاشی → Grid.
 * اول کاشیهای چوبی با WoodTileFinder پیدا میشوند (در غیر این صورت GridDetector).
 * اگر TileReader (نمونههای کالیبرهشده بازی) موجود باشد، از آن استفاده میشود؛ وگرنه OcrEngine عمومی.
 */
class GridRecognizer(
    private val engine: OcrEngine,
    private val reader: () -> TileReader?,
    private val userSamples: () -> List<Template> = { emptyList() }
) {
    data class Result(val grid: Grid, val glyphs: List<BinImage?>, val cells: List<GridDetector.Cell>)

    fun recognize(gray: GrayImage, argb: IntArray? = null): Result {
        val cells = argb?.let { WoodTileFinder.find(it, gray.width, gray.height) } ?: GridDetector.detect(gray)
        val r = reader()
        val extra = userSamples()
        val tiles = cells.map { c ->
            val crop = gray.crop(c.x, c.y, c.w, c.h)
            if (r != null) r.read(crop, extra) { c ->
                // فالبک: قالبهای فونتی TemplateStore + اعداد TemplateStore.digits() (شامل ۳)
                runCatching { engine.recognizeTile(c) }.getOrNull()?.let { TileReader.Reading(it.tile, null) }
            }.let { it.tile to it.glyph }
            else engine.recognizeTile(crop).let { it.tile to it.glyph }
        }
        return Result(Grid(tiles.map { it.first }), tiles.map { it.second }, cells)
    }
}
