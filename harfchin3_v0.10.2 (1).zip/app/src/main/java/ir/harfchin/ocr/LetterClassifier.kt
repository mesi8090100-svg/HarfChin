package ir.harfchin.ocr

/** یک پیشنهاد برای حرف با امتیاز ۰..۱ */
data class Candidate(val letter: String, val score: Float)

/** هر روش تشخیص این رابط را پیاده می‌کند تا بتوان روش‌های جدید (مثلاً مدل TFLite) اضافه کرد. */
interface LetterClassifier {
    val name: String
    val weight: Float
    fun classify(glyph: BinImage): List<Candidate>
}

/** نمونه مرجع: تصویر نرمال‌شده ۳۲×۳۲ یک حرف (از فونت یا تأیید کاربر) */
class Template(val letter: String, val glyph: BinImage, val fromUser: Boolean)

/**
 * تطبیق الگو با فاصله Chamfer دوطرفه — نسبت به ضخامت و تغییرات کوچک فونت مقاوم‌تر از مقایسه پیکسلی است.
 */
class TemplateClassifier(
    private val templates: () -> List<Template>,
    override val name: String = "template",
    override val weight: Float = 1.0f
) : LetterClassifier {

    override fun classify(glyph: BinImage): List<Candidate> {
        val g = Preprocessor.normalizeGlyph(glyph)
        val dg = distanceMap(g)
        val best = HashMap<String, Float>()
        for (t in templates()) {
            val d = chamfer(g, dg, t.glyph, distanceMap(t.glyph))
            // نمونه‌های تأییدشده کاربر از همان بازی ارزش بیشتری دارند
            val sim = (1f / (1f + d)) * if (t.fromUser) 1.15f else 1f
            if (sim > (best[t.letter] ?: 0f)) best[t.letter] = sim
        }
        return best.map { Candidate(it.key, it.value.coerceAtMost(1f)) }.sortedByDescending { it.score }
    }

    private fun chamfer(a: BinImage, da: FloatArray, b: BinImage, db: FloatArray): Float {
        var sa = 0f; var na = 0; var sb = 0f; var nb = 0
        for (i in a.px.indices) {
            if (a.px[i]) { sa += db[i]; na++ }
            if (b.px[i]) { sb += da[i]; nb++ }
        }
        if (na == 0 || nb == 0) return 99f
        return (sa / na + sb / nb) / 2f
    }

    companion object {
        /** نقشه فاصله تقریبی (دو گذره، متریک ۳-۴) */
        fun distanceMap(b: BinImage): FloatArray {
            val w = b.width; val h = b.height; val inf = 1e6f
            val d = FloatArray(w * h) { if (b.px[it]) 0f else inf }
            for (y in 0 until h) for (x in 0 until w) {
                val i = y * w + x; var v = d[i]
                if (x > 0) v = minOf(v, d[i - 1] + 1f)
                if (y > 0) v = minOf(v, d[i - w] + 1f)
                if (x > 0 && y > 0) v = minOf(v, d[i - w - 1] + 1.4f)
                if (x < w - 1 && y > 0) v = minOf(v, d[i - w + 1] + 1.4f)
                d[i] = v
            }
            for (y in h - 1 downTo 0) for (x in w - 1 downTo 0) {
                val i = y * w + x; var v = d[i]
                if (x < w - 1) v = minOf(v, d[i + 1] + 1f)
                if (y < h - 1) v = minOf(v, d[i + w] + 1f)
                if (x < w - 1 && y < h - 1) v = minOf(v, d[i + w + 1] + 1.4f)
                if (x > 0 && y < h - 1) v = minOf(v, d[i + w - 1] + 1.4f)
                d[i] = v
            }
            return d
        }
    }
}

/** روش دوم: شکل کلی با شبکه ۸×۸ چگالی + نسبت ابعاد (سریع و مستقل از جزئیات لبه) */
class ZoningClassifier(
    private val templates: () -> List<Template>,
    override val name: String = "zoning",
    override val weight: Float = 0.6f
) : LetterClassifier {
    override fun classify(glyph: BinImage): List<Candidate> {
        val f = zones(Preprocessor.normalizeGlyph(glyph))
        val best = HashMap<String, Float>()
        for (t in templates()) {
            val g = zones(t.glyph)
            var dot = 0f; var na = 0f; var nb = 0f
            for (i in f.indices) { dot += f[i] * g[i]; na += f[i] * f[i]; nb += g[i] * g[i] }
            val cos = if (na == 0f || nb == 0f) 0f else dot / kotlin.math.sqrt(na * nb)
            if (cos > (best[t.letter] ?: 0f)) best[t.letter] = cos
        }
        return best.map { Candidate(it.key, it.value) }.sortedByDescending { it.score }
    }

    private fun zones(b: BinImage): FloatArray {
        val z = FloatArray(64); val cw = b.width / 8; val ch = b.height / 8
        for (y in 0 until b.height) for (x in 0 until b.width) if (b[x, y]) {
            z[minOf(y / ch, 7) * 8 + minOf(x / cw, 7)] += 1f
        }
        return z
    }
}
