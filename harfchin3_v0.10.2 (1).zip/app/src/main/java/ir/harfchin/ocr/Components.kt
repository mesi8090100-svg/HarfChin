package ir.harfchin.ocr

/** برچسب‌گذاری مؤلفه‌های همبند (۸-همسایگی) */
object Components {
    class Comp(val pixels: IntArray, val minX: Int, val minY: Int, val maxX: Int, val maxY: Int) {
        val area get() = pixels.size
        val cx get() = (minX + maxX) / 2f
        val cy get() = (minY + maxY) / 2f
        val w get() = maxX - minX + 1
        val h get() = maxY - minY + 1
    }

    fun find(b: BinImage): List<Comp> {
        val seen = BooleanArray(b.px.size)
        val out = ArrayList<Comp>()
        val stack = IntArray(b.px.size)
        for (start in b.px.indices) {
            if (!b.px[start] || seen[start]) continue
            var sp = 0; stack[sp++] = start; seen[start] = true
            val pix = ArrayList<Int>()
            var x0 = Int.MAX_VALUE; var y0 = Int.MAX_VALUE; var x1 = -1; var y1 = -1
            while (sp > 0) {
                val p = stack[--sp]; pix.add(p)
                val x = p % b.width; val y = p / b.width
                if (x < x0) x0 = x; if (x > x1) x1 = x; if (y < y0) y0 = y; if (y > y1) y1 = y
                for (dy in -1..1) for (dx in -1..1) {
                    val nx = x + dx; val ny = y + dy
                    if (nx < 0 || ny < 0 || nx >= b.width || ny >= b.height) continue
                    val q = ny * b.width + nx
                    if (b.px[q] && !seen[q]) { seen[q] = true; stack[sp++] = q }
                }
            }
            out.add(Comp(pix.toIntArray(), x0, y0, x1, y1))
        }
        return out
    }
}
