package ir.harfchin.ocr

import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/** پیش‌پردازش: کشش کنتراست، شارپ، آستانه Otsu، تشخیص قطبیت، حذف نویز. */
object Preprocessor {

    data class Settings(
        val contrast: Float = 1.0f,     // 0.5..2.5
        val sharpen: Float = 0.0f,      // 0..1.5
        val thresholdBias: Int = 0      // -40..40
    )

    fun enhance(img: GrayImage, s: Settings): GrayImage {
        // کشش کنتراست با صدک ۲ و ۹۸
        val hist = IntArray(256); img.px.forEach { hist[it.coerceIn(0, 255)]++ }
        val n = img.px.size
        var lo = 0; var acc = 0
        while (lo < 255 && acc + hist[lo] < n * 0.02) { acc += hist[lo]; lo++ }
        var hi = 255; acc = 0
        while (hi > 0 && acc + hist[hi] < n * 0.02) { acc += hist[hi]; hi-- }
        val range = max(1, hi - lo)
        var out = GrayImage(img.width, img.height, IntArray(n) {
            val v = (img.px[it] - lo) * 255f / range
            (((v - 128) * s.contrast) + 128).roundToInt().coerceIn(0, 255)
        })
        if (s.sharpen > 0f) out = sharpen(out, s.sharpen)
        return out
    }

    private fun sharpen(img: GrayImage, amount: Float): GrayImage {
        val o = GrayImage(img.width, img.height)
        for (y in 0 until img.height) for (x in 0 until img.width) {
            var sum = 0; var cnt = 0
            for (dy in -1..1) for (dx in -1..1) {
                val xx = x + dx; val yy = y + dy
                if (xx in 0 until img.width && yy in 0 until img.height) { sum += img[xx, yy]; cnt++ }
            }
            val blur = sum / cnt
            o[x, y] = (img[x, y] + amount * (img[x, y] - blur)).roundToInt().coerceIn(0, 255)
        }
        return o
    }

    fun otsu(img: GrayImage): Int {
        val hist = IntArray(256); img.px.forEach { hist[it]++ }
        val total = img.px.size
        var sum = 0.0; for (i in 0..255) sum += i * hist[i].toDouble()
        var sumB = 0.0; var wB = 0; var best = 0.0; var th = 128
        for (t in 0..255) {
            wB += hist[t]; if (wB == 0) continue
            val wF = total - wB; if (wF == 0) break
            sumB += t * hist[t].toDouble()
            val mB = sumB / wB; val mF = (sum - sumB) / wF
            val between = wB.toDouble() * wF * (mB - mF) * (mB - mF)
            if (between > best) { best = between; th = t }
        }
        return th
    }

    /**
     * دودویی‌سازی با تشخیص خودکار قطبیت: حرف معمولاً کمتر از ۴۰٪ سطح کاشی را می‌گیرد،
     * پس طرفی که کمتر است جوهر فرض می‌شود (کار برای حرف تیره روی چوب روشن و برعکس).
     */
    fun binarize(img: GrayImage, s: Settings = Settings()): BinImage {
        val e = enhance(img, s)
        val th = (otsu(e) + s.thresholdBias).coerceIn(1, 254)
        var dark = 0; e.px.forEach { if (it < th) dark++ }
        val inkIsDark = dark <= e.px.size / 2
        val b = BinImage(e.width, e.height, BooleanArray(e.px.size) { if (inkIsDark) e.px[it] < th else e.px[it] >= th })
        return clearBorder(removeSpecks(b, max(2, b.width * b.height / 4000)))
    }

    /** حذف لکه‌های بسیار کوچک (نویز بافت چوب) — نقطه‌های حروف بزرگ‌تر از این حد هستند. */
    fun removeSpecks(b: BinImage, minArea: Int): BinImage {
        val comps = Components.find(b)
        val out = BinImage(b.width, b.height)
        comps.filter { it.area >= minArea }.forEach { c -> c.pixels.forEach { out.px[it] = true } }
        return out
    }

    /** حذف مؤلفه‌هایی که به لبه چسبیده‌اند (لبه/سایه کاشی) مگر خیلی بزرگ باشند. */
    fun clearBorder(b: BinImage): BinImage {
        val comps = Components.find(b)
        val out = BinImage(b.width, b.height)
        val total = b.width * b.height
        for (c in comps) {
            val touches = c.minX == 0 || c.minY == 0 || c.maxX == b.width - 1 || c.maxY == b.height - 1
            val longEdge = (c.maxX - c.minX) > b.width * 0.9 || (c.maxY - c.minY) > b.height * 0.9
            if (touches && (longEdge || c.area < total * 0.02)) continue
            c.pixels.forEach { out.px[it] = true }
        }
        return out
    }

    /** برش به کادر جوهر و قرار دادن در مربع size×size با حفظ نسبت */
    fun normalizeGlyph(b: BinImage, size: Int = 32): BinImage {
        val bb = b.bbox() ?: return BinImage(size, size)
        val w = bb[2] - bb[0] + 1; val h = bb[3] - bb[1] + 1
        val scale = (size - 4).toFloat() / max(w, h)
        val nw = max(1, (w * scale).roundToInt()); val nh = max(1, (h * scale).roundToInt())
        val ox = (size - nw) / 2; val oy = (size - nh) / 2
        val out = BinImage(size, size)
        for (y in 0 until nh) for (x in 0 until nw) {
            val sx = min(bb[0] + (x / scale).toInt(), bb[2]); val sy = min(bb[1] + (y / scale).toInt(), bb[3])
            if (b[sx, sy]) out[ox + x, oy + y] = true
        }
        return out
    }
}
