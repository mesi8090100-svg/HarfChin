package ir.harfchin.ocr

import ir.harfchin.core.model.Tile

/**
 * موتور OCR چندروشی:
 *  ۱. تطبیق الگو (Chamfer)  ۲. ناحیه‌بندی (Zoning)  ۳. ویژگی‌های ساختاری نقطه‌ها
 * نتیجه با رأی‌گیری وزن‌دار ترکیب می‌شود. اگر اطمینان پایین باشد یا دو حرف اول نزدیک باشند،
 * کاشی برای تأیید کاربر علامت‌گذاری می‌شود — حرف با اطمینان کاذب ثبت نمی‌شود.
 */
class OcrEngine(
    private val classifiers: List<LetterClassifier>,
    private val multiplierReader: MultiplierReader,
    var settings: Settings = Settings()
) {
    data class Settings(
        val minConfidence: Float = 0.72f,
        val minMargin: Float = 0.08f,
        val preprocess: Preprocessor.Settings = Preprocessor.Settings(),
        val featureWeight: Float = 0.8f
    )

    data class TileResult(val tile: Tile, val glyph: BinImage?)

    fun recognizeTile(tileImg: GrayImage): TileResult {
        val (letterArea, cornerArea) = GridDetector.splitTile(tileImg)
        val bin = Preprocessor.binarize(letterArea, settings.preprocess)
        val multiplier = multiplierReader.read(cornerArea, settings.preprocess)
        if (bin.inkCount < bin.px.size * 0.01) {
            return TileResult(Tile("", multiplier, 0f, emptyList(), needsReview = true), null)
        }
        val ranked = combine(bin)
        val top = ranked.getOrNull(0); val second = ranked.getOrNull(1)
        val conf = top?.score ?: 0f
        val margin = conf - (second?.score ?: 0f)
        val unsure = top == null || conf < settings.minConfidence || margin < settings.minMargin
        return TileResult(
            Tile(
                letter = if (unsure && conf < settings.minConfidence * 0.6f) "" else top?.letter ?: "",
                multiplier = multiplier,
                confidence = conf,
                alternatives = ranked.take(4).map { it.letter },
                needsReview = unsure
            ),
            Preprocessor.normalizeGlyph(bin)
        )
    }

    /** رأی‌گیری وزن‌دار + ضرب در سازگاری نقطه‌ها */
    fun combine(bin: BinImage): List<Candidate> {
        val scores = HashMap<String, Float>()
        var wsum = 0f
        for (c in classifiers) {
            val res = c.classify(bin)
            if (res.isEmpty()) continue
            wsum += c.weight
            val max = res.first().score.coerceAtLeast(1e-6f)
            res.forEach { scores[it.letter] = (scores[it.letter] ?: 0f) + c.weight * (it.score / max) * it.score.coerceAtMost(1f) / 1f }
        }
        if (wsum == 0f) return emptyList()
        val feats = GlyphFeatures.extract(bin)
        return scores.map { (l, s) ->
            val base = s / wsum
            val comp = feats?.let { GlyphFeatures.compatibility(it, l) } ?: 1f
            Candidate(l, base * ((1 - settings.featureWeight) + settings.featureWeight * comp))
        }.sortedByDescending { it.score }
    }
}

/** خواندن عدد ضریب گوشه بالا-راست (۱/۲/۳). اگر چیزی نبود ۱ برمی‌گرداند. */
class MultiplierReader(private val digitTemplates: () -> List<Template>) {
    private val clf = TemplateClassifier(digitTemplates, "digits")
    fun read(corner: GrayImage, s: Preprocessor.Settings): Int {
        val bin = Preprocessor.binarize(corner, s)
        if (bin.inkCount < bin.px.size * 0.03) return 1
        val best = clf.classify(bin).firstOrNull() ?: return 1
        if (best.score < 0.25f) return 1
        return best.letter.toIntOrNull()?.coerceIn(1, 3) ?: 1
    }
}
