package ir.harfchin.ocr

import ir.harfchin.core.PersianNormalizer
import ir.harfchin.core.model.Tile
import java.io.DataInputStream
import java.io.InputStream

/**
 * خواننده کاشی کالیبرهشده برای بازی «بازم بازی» (com.bazambazi) و طرحهای مشابه
 * (کاشی چوبی روشن، حرف قهوهای تیره، عدد امتیاز در گوشه بالا-راست).
 *
 * قالبها: ۲۹۶ نمونه حرف (۲۶ حرف) و ۲۹۶ نمونه عدد (۱، ۲، ۳) از ۱۹ اسکرینشات واقعی.
 * سنجش leave-one-screenshot-out روی ۷ اسکرینشات جدید (۱۱۲ کاشی): ۱۰۶ خودکار درست، ۶ زرد، ۰ اشتباه بیصدا.
 *  ۱. خاکستری BT.601 و جوهر = روشنایی کمتر از ۱۱۰
 *  ۲. حذف گوشه عدد (۳۳٪ بالا × ۳۲٪ راست) و حاشیه ۶٪
 *  ۳. برش به کادر جوهر، مربع کردن، نمونهبرداری میانگین به ۳۲×۳۲ و آستانه ۰٫۳۵
 *  ۴. نزدیکترین همسایه با فاصله همینگ نسبت به نمونههای واقعی
 * اگر فاصله زیاد یا اختلاف با حرف دوم کم باشد، کاشی «نیاز به تأیید» علامت میخورد.
 */
class TileReader(
    private val letters: List<Template>,
    private val digits: List<Template>,
    /** سنجیده شد: با ۱۱۰، ۹ حرفِ دیدهنشده بیصدا اشتباه ثبت میشد؛ با ۶۰ صفر (حرف درست حداکثر ۳۲ فاصله دارد) */
    private val maxDistance: Int = 60,
    private val minMargin: Int = 40
) {
    data class Reading(val tile: Tile, val glyph: BinImage?)

    /**
     * @param fallback خواننده عمومی (OcrEngine با قالبهای فونتی TemplateStore و MultiplierReader با TemplateStore.digits()).
     *  فقط وقتی صدا زده میشود که نمونههای واقعی جواب ندهند: حرف خیلی دور از همه قالبهاست (مثلاً آ ث چ ح ذ ژ ص ض ط ظ غ
     *  که نمونه ندارند) یا عدد گوشه شناخته نشد (مثلاً «۳» که در bazambazi_digits.bin نیست).
     *  هر خانهای که با فالبک خوانده شود همیشه «نیاز به تأیید» میماند، چون قالب فونتی با فونت بازی کالیبره نشده است.
     */
    fun read(tile: GrayImage, extra: List<Template> = emptyList(), fallback: ((GrayImage) -> Reading?)? = null): Reading {
        val g = letterGlyph(tile)
        // عدد گوشه هم مثل حرف سنجیده میشود؛ عدد مشکوک = کاشی زرد (امتیاز اشتباه یعنی انتخاب اشتباه کلمه)
        var digitUnsure = false
        var score = 1
        digitGlyph(tile)?.let { d ->
            val rd = nearest(d, digits)
            val v = PersianNormalizer.normalize(rd.firstOrNull()?.first ?: "").toIntOrNull()
            val dd = rd.firstOrNull()?.second ?: Int.MAX_VALUE
            val dm = (rd.getOrNull(1)?.second ?: Int.MAX_VALUE) - dd
            // سنجیده روی ۲۹۶ نمونه عدد (شامل ۱۴ «۳» واقعی): فاصله عدد در اسکرینشاتِ ضبط ویدیو تا ۱۸۲ میرسد
            // ولی فاصله با عدد دوم همیشه زیاد است؛ پس معیار اصلی فاصله با عدد دوم است. ۰ اشتباه بیصدا.
            if (v == null || dd > MAX_DIGIT_DISTANCE || dm < minMargin) digitUnsure = true
            if (v != null) score = v
        }
        val pool = letters + extra
        val ranked = if (g != null) nearest(g, pool) else emptyList()
        val best = ranked.getOrNull(0)
        val dist = best?.second ?: Int.MAX_VALUE
        val margin = (ranked.getOrNull(1)?.second ?: Int.MAX_VALUE) - dist
        val letterUnknown = g != null && (best == null || dist > maxDistance)

        var letter = best?.first ?: ""
        var alts = ranked.take(4).map { it.first }
        // وقتی تطابق تقریباً کامل است (≤۱۲)، فاصله کمتر با حرف دوم هم کافی است (ح/ج: ۰ در برابر ۳۴)
        val needMargin = if (dist <= CLOSE_MATCH) minMargin / 2 else minMargin
        var unsure = g == null || letterUnknown || margin < needMargin || digitUnsure
        // حرفی که فقط ۱ نمونه دارد (ز ش ه) هنوز قابل اعتماد نیست تا کاربر یک بار تأییدش کند
        if (best != null && pool.count { it.letter == best.first } < MIN_SUPPORT) unsure = true

        var usedFallback = false
        if ((letterUnknown || digitUnsure) && fallback != null) {
            fallback(tile)?.let { fb ->
                usedFallback = true
                if (letterUnknown && fb.tile.letter.isNotEmpty()) {
                    letter = fb.tile.letter
                    alts = (fb.tile.alternatives + alts).distinct().take(6)
                }
                if (digitUnsure) score = fb.tile.multiplier
            }
        }
        // سنجش دوباره جفتهای همشکل با شمارش نقطه؛ تعارض = زرد + جفت دیگر در پیشنهادها
        if (g != null && letter.isNotEmpty()) dotConflict(letter, g)?.let { other ->
            unsure = true
            alts = (listOf(letter, other) + alts).distinct().take(6)
        }
        val conf = when {
            g == null -> 0f
            usedFallback && letterUnknown -> 0.3f
            else -> (1f - dist / 1024f * 4f).coerceIn(0f, 1f)
        }
        return Reading(Tile(letter, score.coerceIn(1, 9), conf, alts, unsure || usedFallback), g)
    }

    /** فهرست (حرف، کمترین فاصله) مرتب از نزدیک به دور */
    private fun nearest(g: BinImage, set: List<Template>): List<Pair<String, Int>> {
        val best = HashMap<String, Int>()
        for (t in set) {
            var d = 0
            if (t.glyph.px.size != 1024) continue
            for (i in 0 until 1024) if (g.px[i] != t.glyph.px[i]) d++
            if (d < (best[t.letter] ?: Int.MAX_VALUE)) best[t.letter] = d
        }
        return best.entries.map { it.key to it.value }.sortedBy { it.second }
    }

    companion object {
        const val INK = 110
        /** کمترین تعداد نمونه (واقعی + کاربر) برای اینکه حرفی بدون تأیید ثبت شود */
        const val MIN_SUPPORT = 2
        const val CLOSE_MATCH = 12
        const val MAX_DIGIT_DISTANCE = 190

        /** جفتهایی که فقط در تعداد نقطه فرق دارند */
        val DOT_PAIRS: Map<String, String> = listOf("ت" to "ث", "ط" to "ظ", "ع" to "غ", "ص" to "ض", "ج" to "چ", "د" to "ذ")
            .flatMap { (a, b) -> listOf(a to b, b to a) }.toMap()

        /**
         * اگر نقطههای شمردهشده دقیقاً با جفتِ حرف بخواند و با خود حرف نخواند، آن جفت را برمیگرداند.
         * عمداً محافظهکار است: روی ۱۸۴ نمونه واقعی، شمارنده نقطه گاهی نقطه را گم میکند (مثلاً «ت» → ۰ نقطه)،
         * پس هرگز حرف را عوض نمیکنیم؛ فقط کاشی را برای تأیید زرد میکنیم. روی نمونههای واقعی صفر هشدار کاذب.
         */
        fun dotConflict(letter: String, glyph: BinImage): String? {
            val other = DOT_PAIRS[letter] ?: return null
            val f = GlyphFeatures.extract(glyph) ?: return null
            val obs = f.dotsAbove to f.dotsBelow
            return if (obs == GlyphFeatures.EXPECTED[other] && obs != GlyphFeatures.EXPECTED[letter]) other else null
        }

        fun letterGlyph(t: GrayImage): BinImage? {
            val w = t.width; val h = t.height
            val ink = BinImage(w, h)
            val cx = (w * 0.68f).toInt(); val cy = (h * 0.33f).toInt()
            val mx0 = (w * 0.06f).toInt(); val mx1 = (w * 0.94f).toInt()
            val my0 = (h * 0.06f).toInt(); val my1 = (h * 0.94f).toInt()
            for (y in my0 until my1) for (x in mx0 until mx1) {
                if (y < cy && x >= cx) continue
                if (t[x, y] < INK) ink[x, y] = true
            }
            return norm32(ink)
        }

        fun digitGlyph(t: GrayImage): BinImage? {
            val w = t.width; val h = t.height
            val x0 = (w * 0.72f).toInt(); val x1 = (w * 0.95f).toInt()
            val y0 = (h * 0.04f).toInt(); val y1 = (h * 0.30f).toInt()
            val c = BinImage(x1 - x0, y1 - y0)
            for (y in y0 until y1) for (x in x0 until x1) if (t[x, y] < 120) c[x - x0, y - y0] = true
            return norm32(c)
        }

        /** برش به جوهر، مربع، میانگین بلوکی ۳۲×۳۲، آستانه ۰٫۳۵ */
        fun norm32(ink: BinImage): BinImage? {
            if (ink.inkCount < 8) return null
            val bb = ink.bbox() ?: return null
            val cw = bb[2] - bb[0] + 1; val ch = bb[3] - bb[1] + 1
            val s = maxOf(cw, ch); val ox = (s - cw) / 2; val oy = (s - ch) / 2
            fun at(x: Int, y: Int): Boolean {
                val sx = x - ox; val sy = y - oy
                return sx in 0 until cw && sy in 0 until ch && ink[bb[0] + sx, bb[1] + sy]
            }
            val out = BinImage(32, 32)
            for (j in 0 until 32) {
                val y0 = j * s / 32; val y1 = maxOf(y0 + 1, (j + 1) * s / 32)
                for (i in 0 until 32) {
                    val x0 = i * s / 32; val x1 = maxOf(x0 + 1, (i + 1) * s / 32)
                    var on = 0; var n = 0
                    for (y in y0 until y1) for (x in x0 until x1) { n++; if (at(x, y)) on++ }
                    out[i, j] = on.toFloat() / n > 0.35f
                }
            }
            return out
        }

        /** خواندن فایل نمونهها: [int n] سپس n بار [writeUTF حرف][۱۰۲۴ بایت ۰/۱] */
        fun loadTemplates(input: InputStream, fromUser: Boolean = false): List<Template> =
            DataInputStream(input.buffered()).use { d ->
                val n = d.readInt()
                List(n) {
                    val l = d.readUTF()
                    val px = BooleanArray(1024) { d.readByte().toInt() != 0 }
                    Template(l, BinImage(32, 32, px), fromUser)
                }
            }
    }
}

/**
 * پیدا کردن ۱۶ کاشی چوبی روشن داخل تصویر رنگی (ردیفها و ستونهایی که بیش از ۳۰٪ پیکسل چوبی دارند).
 * اگر دقیقاً ۴ ردیف و ۴ ستون پیدا نشد، null برمیگرداند تا تقسیم یکنواخت استفاده شود.
 */
object WoodTileFinder {
    fun isWood(argb: Int): Boolean {
        val r = (argb shr 16) and 255; val g = (argb shr 8) and 255; val b = argb and 255
        return r > 200 && g > 170 && b < 200
    }

    fun find(argb: IntArray, w: Int, h: Int): List<GridDetector.Cell>? {
        val rows = FloatArray(h); val cols = FloatArray(w)
        for (y in 0 until h) { var c = 0; for (x in 0 until w) if (isWood(argb[y * w + x])) c++; rows[y] = c.toFloat() / w }
        val ys = best4(runs(rows, 0.3f, h / 40)) ?: return null
        val y0 = ys.first().first; val y1 = ys.last().second
        for (x in 0 until w) { var c = 0; for (y in y0 until y1) if (isWood(argb[y * w + x])) c++; cols[x] = c.toFloat() / (y1 - y0) }
        val xs = best4(runs(cols, 0.3f, w / 40)) ?: return null
        // اگر بالای کاشی بریده شده باشد (مثلاً نوار وضعیت یا پخشکننده ویدیو)، ارتفاع از روی نسبت
        // واقعی کاشی (ارتفاع ≈ ۰٫۹۰۶ × عرض) و لبه پایین بازسازی میشود
        return ys.flatMap { (a, b) -> xs.map { (c, d) ->
            val tw = d - c; val th = Math.round(tw * 0.906f)
            if (b - a < th * 0.97f) GridDetector.Cell(c, b - th, tw, th) else GridDetector.Cell(c, a, tw, b - a)
        } }
    }

    /** از بین نوارهای پیداشده، ۴ نوار پشت سر هم با اندازه و فاصله یکنواخت (سرصفحه چوبی بازی حذف میشود) */
    private fun best4(r: List<Pair<Int, Int>>): List<Pair<Int, Int>>? {
        var best: List<Pair<Int, Int>>? = null; var bestCost = Float.MAX_VALUE
        for (i in 0..r.size - 4) {
            val q = r.subList(i, i + 4)
            val hs = q.map { it.second - it.first }
            val gs = (0 until 3).map { q[it + 1].first - q[it].second }
            val mx = hs.max().toFloat()
            val cost = (hs.max() - hs.min()) / mx + (gs.max() - gs.min()) / mx
            if (cost < bestCost) { bestCost = cost; best = q }
        }
        return if (bestCost < 0.25f) best else null
    }

    private fun runs(v: FloatArray, th: Float, minLen: Int): List<Pair<Int, Int>> {
        val out = ArrayList<Pair<Int, Int>>(); var s = -1
        for (i in v.indices) {
            val on = v[i] > th
            if (on && s < 0) s = i
            if ((!on || i == v.size - 1) && s >= 0) { val e = if (on) i + 1 else i; if (e - s > minLen) out.add(s to e); s = -1 }
        }
        return out
    }
}
