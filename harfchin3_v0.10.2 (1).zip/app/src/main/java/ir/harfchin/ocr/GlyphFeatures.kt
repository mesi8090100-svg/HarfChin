package ir.harfchin.ocr

/**
 * ویژگی‌های ساختاری حرف فارسی: بدنه اصلی، تعداد نقطه‌ها و جای آن‌ها (بالا/پایین)، سرکش، هَمزه.
 * این ویژگی‌ها برای جدا کردن ب/پ/ت/ث، ج/چ/ح/خ، د/ذ، ر/ز/ژ، س/ش، ص/ض، ط/ظ، ع/غ، ف/ق، ک/گ حیاتی‌اند.
 */
data class GlyphFeatures(
    val dotsAbove: Int,
    val dotsBelow: Int,
    val hasExtraStroke: Boolean,   // سرکش اضافه گ یا مَد آ یا هَمزه
    val aspect: Float,             // عرض/ارتفاع بدنه
    val bodyFill: Float
) {
    val totalDots get() = dotsAbove + dotsBelow

    companion object {
        fun extract(b: BinImage): GlyphFeatures? {
            val comps = Components.find(b).sortedByDescending { it.area }
            if (comps.isEmpty()) return null
            val body = comps[0]
            var above = 0; var below = 0; var extra = false
            for (c in comps.drop(1)) {
                if (c.area < body.area * 0.015f) continue
                val ratio = c.area.toFloat() / body.area
                val elongated = c.w > c.h * 2.2f || c.h > c.w * 2.2f
                // دو نقطه چسبیده (تشدید‌مانند) تقریباً دو برابر عرض یک نقطه‌اند
                val dotsInComp = if (!elongated && c.w > c.h * 1.6f) 2 else 1
                val isDot = ratio < 0.25f && !elongated
                if (isDot) {
                    if (c.cy < body.cy) above += dotsInComp else below += dotsInComp
                } else if (ratio < 0.5f) {
                    extra = true
                }
            }
            val fill = body.area.toFloat() / (body.w * body.h)
            return GlyphFeatures(above.coerceAtMost(3), below.coerceAtMost(3), extra, body.w.toFloat() / body.h, fill)
        }

        /** امضای نقطه‌ای مورد انتظار هر حرف: (بالا، پایین) */
        val EXPECTED: Map<String, Pair<Int, Int>> = mapOf(
            "ا" to (0 to 0), "آ" to (0 to 0), "ب" to (0 to 1), "پ" to (0 to 3), "ت" to (2 to 0), "ث" to (3 to 0),
            "ج" to (0 to 1), "چ" to (0 to 3), "ح" to (0 to 0), "خ" to (1 to 0), "د" to (0 to 0), "ذ" to (1 to 0),
            "ر" to (0 to 0), "ز" to (1 to 0), "ژ" to (3 to 0), "س" to (0 to 0), "ش" to (3 to 0), "ص" to (0 to 0),
            "ض" to (1 to 0), "ط" to (0 to 0), "ظ" to (1 to 0), "ع" to (0 to 0), "غ" to (1 to 0), "ف" to (1 to 0),
            "ق" to (2 to 0), "ک" to (0 to 0), "گ" to (0 to 0), "ل" to (0 to 0), "م" to (0 to 0), "ن" to (1 to 0),
            "و" to (0 to 0), "ه" to (0 to 0), "ی" to (0 to 0)
        )

        /** ۰..۱: میزان سازگاری ویژگی‌ها با یک حرف */
        fun compatibility(f: GlyphFeatures, letter: String): Float {
            val (ea, eb) = EXPECTED[letter] ?: return 0.5f
            var s = 1f
            // در فونت‌های فانتزی سه نقطه گاهی دو مؤلفه می‌شود؛ پس اختلاف ۱ را کمتر جریمه می‌کنیم
            s -= 0.35f * kotlin.math.abs(f.dotsAbove - ea)
            s -= 0.35f * kotlin.math.abs(f.dotsBelow - eb)
            if (letter == "گ" || letter == "آ") s -= if (f.hasExtraStroke) 0f else 0.25f
            if (letter == "ک" || letter == "ا") s -= if (f.hasExtraStroke) 0.25f else 0f
            return s.coerceIn(0f, 1f)
        }
    }
}
