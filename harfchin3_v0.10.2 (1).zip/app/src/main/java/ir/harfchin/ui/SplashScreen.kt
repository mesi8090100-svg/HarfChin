package ir.harfchin.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

/** امضای سازنده */
const val CREATOR = "me.kinG.si"

private data class Spark(val x: Float, val y: Float, val r: Float, val speed: Float, val phase: Float, val color: Color)
private data class Confetti(val angle: Float, val dist: Float, val size: Float, val spin: Float, val color: Color, val square: Boolean)

/**
 * صفحه شروع (حدود ۴ ثانیه، با لمس رد میشود):
 *  ۱. پسزمینه گرادیان که آرام میچرخد + ذرات درخشان شناور
 *  ۲. چهار کاشی لوگو از چهار گوشه پرواز میکنند و جفت میشوند؛ حلقه نور پشتشان میتپد
 *  ۳. «ساخته شده توسط» محو و بالا میآید
 *  ۴. هر حرف «me.kinG.si» روی یک کاشی رنگی مثل کاشیهای بازی، یکییکی ورق میخورد (چرخش سهبعدی)
 *  ۵. نوار برق از روی اسم رد میشود و انفجار کاغذرنگی از وسط
 */
@Composable
fun SplashScreen(onDone: () -> Unit) {
    var finished by remember { mutableStateOf(false) }
    fun finish() { if (!finished) { finished = true; onDone() } }

    val palette = listOf(Coral, Sun, Mint, Sky, Berry, Grape)
    val sparks = remember { List(46) { Spark(Random.nextFloat(), Random.nextFloat(), 1.5f + Random.nextFloat() * 3.5f,
        0.3f + Random.nextFloat(), Random.nextFloat() * 6.28f, palette[it % palette.size]) } }
    val confetti = remember { List(70) { Confetti(Random.nextFloat() * 6.28f, 0.5f + Random.nextFloat() * 0.6f,
        5f + Random.nextFloat() * 9f, (Random.nextFloat() - 0.5f) * 1440f, palette[it % palette.size], it % 3 != 0) } }

    val logo = remember { Animatable(0f) }
    val intro = remember { Animatable(0f) }
    val flips = remember { CREATOR.map { Animatable(0f) } }
    val shimmer = remember { Animatable(-0.3f) }
    val boom = remember { Animatable(0f) }
    val exit = remember { Animatable(1f) }

    val loop = rememberInfiniteTransition(label = "loop")
    val time by loop.animateFloat(0f, 1f, infiniteRepeatable(tween(6000, easing = LinearEasing)), label = "t")
    val pulse by loop.animateFloat(0.85f, 1.15f, infiniteRepeatable(tween(800, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "p")

    LaunchedEffect(Unit) {
        logo.animateTo(1f, spring(dampingRatio = 0.5f, stiffness = 120f))
        intro.animateTo(1f, tween(450, easing = FastOutSlowInEasing))
        flips.forEachIndexed { i, a -> launch { delay(i * 90L); a.animateTo(1f, spring(dampingRatio = 0.55f, stiffness = 170f)) } }
        delay(CREATOR.length * 90L + 350)
        launch { boom.animateTo(1f, tween(1300, easing = LinearOutSlowInEasing)) }
        shimmer.animateTo(1.3f, tween(750, easing = FastOutSlowInEasing))
        delay(900)
        exit.animateTo(0f, tween(400))
        finish()
    }

    Box(
        Modifier.fillMaxSize()
            .graphicsLayer { alpha = exit.value; scaleX = 1f + (1f - exit.value) * 0.08f; scaleY = scaleX }
            .clickable(remember { MutableInteractionSource() }, indication = null) { finish() },
        contentAlignment = Alignment.Center
    ) {
        // ۱. پسزمینه متحرک + ذرات
        Canvas(Modifier.fillMaxSize()) {
            val a = time * 2f * PI.toFloat()
            drawRect(Brush.linearGradient(
                listOf(Color(0xFF140E22), Plum, Grape, Berry.copy(alpha = 0.9f)),
                start = Offset(size.width * (0.5f + 0.5f * cos(a)), 0f),
                end = Offset(size.width * (0.5f - 0.5f * cos(a)), size.height)
            ))
            sparks.forEach { s ->
                val y = ((s.y - time * s.speed) % 1f + 1f) % 1f
                val tw = 0.35f + 0.65f * ((sin(a * 3 + s.phase) + 1f) / 2f)
                val c = Offset(s.x * size.width + 18f * sin(a + s.phase), y * size.height)
                drawCircle(s.color.copy(alpha = 0.18f * tw), s.r * 4f, c)
                drawCircle(Color.White.copy(alpha = 0.85f * tw), s.r, c)
            }
        }

        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            // ۲. لوگو: کاشیها از گوشهها میآیند + حلقه نور
            Box(Modifier.size(150.dp), contentAlignment = Alignment.Center) {
                Canvas(Modifier.fillMaxSize()) {
                    val r = size.minDimension / 2f * logo.value
                    drawCircle(Brush.radialGradient(listOf(Sun.copy(alpha = 0.45f), Berry.copy(alpha = 0.15f), Color.Transparent),
                        radius = (r * pulse).coerceAtLeast(1f)), r * pulse)
                    rotate(time * 360f) {
                        for (k in 0 until 12) {
                            val ang = k * 30f * PI.toFloat() / 180f
                            drawCircle(palette[k % palette.size].copy(alpha = 0.8f * logo.value), 3.5f,
                                Offset(center.x + cos(ang) * r * 0.95f, center.y + sin(ang) * r * 0.95f))
                        }
                    }
                }
                val corners = listOf(-1f to -1f, 1f to -1f, -1f to 1f, 1f to 1f)
                val cols = listOf(Coral, Sun, Mint, Sky)
                corners.forEachIndexed { i, (dx, dy) ->
                    val p = logo.value
                    Box(
                        Modifier.size(34.dp).graphicsLayer {
                            translationX = dx * (21.dp.toPx() + (1f - p) * 420f)
                            translationY = dy * (21.dp.toPx() + (1f - p) * 620f)
                            rotationZ = (1f - p) * 270f * dx
                        }.clip(RoundedCornerShape(10.dp)).background(cols[i])
                            .border(2.dp, Color.White.copy(alpha = 0.35f), RoundedCornerShape(10.dp))
                    )
                }
            }
            Spacer(Modifier.height(26.dp))

            // ۳. ساخته شده توسط
            Text(
                "ساخته شده توسط", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold, fontFamily = Vazir,
                style = TextStyle(shadow = Shadow(Berry, blurRadius = 18f)),
                modifier = Modifier.graphicsLayer { alpha = intro.value; translationY = (1f - intro.value) * 40f }
            )
            Spacer(Modifier.height(14.dp))

            // ۴. اسم روی کاشیها با ورق خوردن + ۵. نوار برق
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    modifier = Modifier.drawWithContent {
                        drawContent()
                        val x = shimmer.value * size.width
                        drawRect(Brush.linearGradient(
                            listOf(Color.Transparent, Color.White.copy(alpha = 0.75f), Color.Transparent),
                            start = Offset(x - 60f, 0f), end = Offset(x + 60f, size.height)
                        ))
                    }
                ) {
                    CREATOR.forEachIndexed { i, ch ->
                        val p = flips[i].value
                        val dot = ch == '.'
                        val col = palette[i % palette.size]
                        Box(
                            Modifier.width(if (dot) 12.dp else 30.dp).height(42.dp)
                                .graphicsLayer {
                                    rotationY = (1f - p) * 180f
                                    cameraDistance = 12f * density
                                    alpha = if (p < 0.02f) 0f else 1f
                                    translationY = (1f - p) * -60f
                                    scaleX = 0.7f + 0.3f * p; scaleY = scaleX
                                }
                                .then(if (dot) Modifier else Modifier
                                    .clip(RoundedCornerShape(9.dp))
                                    .background(Brush.verticalGradient(listOf(col, col.copy(alpha = 0.75f))))
                                    .border(1.5.dp, Color.White.copy(alpha = 0.45f), RoundedCornerShape(9.dp))),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                ch.toString(), color = Color.White,
                                fontSize = if (ch == 'G') 27.sp else 23.sp, fontWeight = FontWeight.ExtraBold,
                                style = TextStyle(shadow = Shadow(Color(0x66000000), Offset(0f, 2f), 4f))
                            )
                        }
                    }
                }
            }
            if (flips.last().value > 0.9f) Text("👑", fontSize = 22.sp,
                modifier = Modifier.padding(top = 8.dp).graphicsLayer { scaleX = pulse; scaleY = pulse })
            else Spacer(Modifier.height(38.dp))
        }

        // انفجار کاغذرنگی
        if (boom.value > 0f && boom.value < 1f) Canvas(Modifier.fillMaxSize()) {
            val b = boom.value
            val reach = size.minDimension * 0.75f
            confetti.forEach { c ->
                val d = c.dist * reach * (1f - (1f - b) * (1f - b))
                val pos = Offset(center.x + cos(c.angle) * d, center.y + sin(c.angle) * d + b * b * 260f)
                val al = (1f - b).coerceIn(0f, 1f)
                rotate(c.spin * b, pos) {
                    if (c.square) drawRect(c.color.copy(alpha = al), Offset(pos.x - c.size / 2, pos.y - c.size / 4),
                        androidx.compose.ui.geometry.Size(c.size, c.size / 2))
                    else drawCircle(c.color.copy(alpha = al), c.size / 2.5f, pos)
                }
            }
        }
    }
}
