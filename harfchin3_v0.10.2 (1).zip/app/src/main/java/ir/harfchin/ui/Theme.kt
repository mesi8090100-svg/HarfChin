package ir.harfchin.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import ir.harfchin.R

/** فونت وزیرمتن (مجوز OFL) — داخل res/font */
val Vazir = FontFamily(
    Font(R.font.vazirmatn_regular, FontWeight.Normal),
    Font(R.font.vazirmatn_bold, FontWeight.Bold),
    Font(R.font.vazirmatn_extrabold, FontWeight.ExtraBold)
)

// رنگهای شاد مشترک (در حالت روشن و تاریک یکی هستند)
val Coral = Color(0xFFFF7A59)
val Sun = Color(0xFFFFC23D)
val Mint = Color(0xFF2EC4A6)
val Sky = Color(0xFF4D9DE0)
val Berry = Color(0xFFE85D9A)
val Grape = Color(0xFF8E44AD)
val Plum = Color(0xFF4A3466)

@Immutable
data class HcColors(
    val dark: Boolean,
    val bg: Color,
    val surface: Color,
    val ink: Color,
    val sub: Color,
    val tile: Color,
    val tileEdge: Color,
    val tileInk: Color,
    val unsure: Color,
    val path: Color,
    val pathStart: Color,
    val board: Color,
    val divider: Color
)

private val LightHc = HcColors(
    false, Color(0xFFF7F2EA), Color.White, Color(0xFF2B1F33), Color(0xFF7A6E80),
    Color(0xFFF6E2B3), Color(0xFFD9A55B), Color(0xFF3B2414), Color(0xFFFFD54F),
    Color(0xFF7CB342), Color(0xFF2E7D32), Plum, Color(0xFFEAE2D6)
)
private val DarkHc = HcColors(
    true, Color(0xFF15121A), Color(0xFF221D2A), Color(0xFFF1ECF5), Color(0xFFA79DB0),
    Color(0xFFEBD6A5), Color(0xFFB98A45), Color(0xFF3B2414), Color(0xFFFFCA28),
    Color(0xFF8BC34A), Color(0xFF43A047), Color(0xFF2C2238), Color(0xFF342E3D)
)

val LocalHc = staticCompositionLocalOf { LightHc }

/** دسترسی کوتاه: Hc.c.ink */
object Hc {
    val c: HcColors @Composable @ReadOnlyComposable get() = LocalHc.current
}

val HeaderBrush = Brush.linearGradient(listOf(Plum, Grape, Berry))
val ScanBrush = Brush.horizontalGradient(listOf(Coral, Berry))
val SolveBrush = Brush.horizontalGradient(listOf(Mint, Color(0xFF26A69A)))
val AddBrush = Brush.horizontalGradient(listOf(Sky, Grape))

/** رنگ هر طول کلمه — در فهرست کلمات و برچسبها */
fun lengthColor(len: Int): Color = when {
    len <= 3 -> Sky
    len == 4 -> Mint
    len == 5 -> Sun
    len == 6 -> Coral
    else -> Berry
}

private fun vazirTypography(): Typography {
    val t = Typography()
    fun f(s: TextStyle) = s.copy(fontFamily = Vazir)
    return t.copy(
        displayLarge = f(t.displayLarge), displayMedium = f(t.displayMedium), displaySmall = f(t.displaySmall),
        headlineLarge = f(t.headlineLarge), headlineMedium = f(t.headlineMedium), headlineSmall = f(t.headlineSmall),
        titleLarge = f(t.titleLarge), titleMedium = f(t.titleMedium), titleSmall = f(t.titleSmall),
        bodyLarge = f(t.bodyLarge), bodyMedium = f(t.bodyMedium), bodySmall = f(t.bodySmall),
        labelLarge = f(t.labelLarge), labelMedium = f(t.labelMedium), labelSmall = f(t.labelSmall)
    )
}

@Composable
fun HarfChinTheme(content: @Composable () -> Unit) {
    val dark = isSystemInDarkTheme()
    val c = if (dark) DarkHc else LightHc
    val scheme = if (dark) darkColorScheme(
        primary = Color(0xFFC6A4E8), onPrimary = Color(0xFF2B1F33), secondary = Mint,
        background = c.bg, surface = c.surface, onBackground = c.ink, onSurface = c.ink,
        surfaceVariant = Color(0xFF2E2838), onSurfaceVariant = c.sub,
        secondaryContainer = Color(0xFF3A3046), onSecondaryContainer = c.ink, outline = Color(0xFF5A5163)
    ) else lightColorScheme(
        primary = Plum, onPrimary = Color.White, secondary = Mint,
        background = c.bg, surface = c.surface, onBackground = c.ink, onSurface = c.ink,
        surfaceVariant = Color(0xFFF1EAF5), onSurfaceVariant = c.sub,
        secondaryContainer = Color(0xFFEDE3F5), onSecondaryContainer = c.ink, outline = Color(0xFFCFC4D6)
    )
    CompositionLocalProvider(LocalHc provides c) {
        MaterialTheme(colorScheme = scheme, typography = vazirTypography(), content = content)
    }
}
