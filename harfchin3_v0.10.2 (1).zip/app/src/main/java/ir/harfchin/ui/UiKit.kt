package ir.harfchin.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** آیکون داخل یک مربع گرد رنگی (پسزمینه کمرنگ از همان رنگ) */
@Composable
fun IconBadge(icon: ImageVector, tint: Color, size: Dp = 40.dp, solid: Boolean = false) {
    Box(
        Modifier.size(size).clip(RoundedCornerShape(size / 3.2f))
            .background(if (solid) tint else tint.copy(alpha = 0.16f)),
        contentAlignment = Alignment.Center
    ) { Icon(icon, null, tint = if (solid) Color.White else tint, modifier = Modifier.size(size * 0.55f)) }
}

/** دکمه بزرگ با پسزمینه گرادیان */
@Composable
fun GradientButton(
    text: String,
    brush: Brush,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
    enabled: Boolean = true,
    height: Dp = 54.dp,
    onClick: () -> Unit
) {
    Box(
        modifier.height(height).alpha(if (enabled) 1f else 0.5f)
            .shadow(if (enabled) 6.dp else 0.dp, RoundedCornerShape(16.dp))
            .clip(RoundedCornerShape(16.dp)).background(brush)
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 16.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (icon != null) Icon(icon, null, tint = Color.White, modifier = Modifier.size(22.dp))
            Text(text, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        }
    }
}

/** کارت بخشبندی با عنوان و آیکون رنگی */
@Composable
fun SectionCard(
    title: String,
    icon: ImageVector,
    tint: Color,
    modifier: Modifier = Modifier,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Hc.c.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = if (Hc.c.dark) 0.dp else 2.dp)
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                IconBadge(icon, tint, 36.dp)
                Text(title, fontSize = 17.sp, fontWeight = FontWeight.Bold, color = Hc.c.ink)
            }
            content()
        }
    }
}

/** برچسب کوچک گرد رنگی */
@Composable
fun Pill(text: String, color: Color, solid: Boolean = true) {
    Box(
        Modifier.clip(CircleShape).background(if (solid) color else color.copy(alpha = 0.16f))
            .padding(horizontal = 10.dp, vertical = 3.dp)
    ) { Text(text, color = if (solid) Color.White else color, fontSize = 13.sp, fontWeight = FontWeight.Bold) }
}

/** حالت خالی: آیکون بزرگ رنگی + توضیح */
@Composable
fun EmptyState(icon: ImageVector, tint: Color, title: String, hint: String) {
    Column(
        Modifier.fillMaxWidth().padding(vertical = 28.dp, horizontal = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        IconBadge(icon, tint, 64.dp)
        Text(title, fontSize = 17.sp, fontWeight = FontWeight.Bold, color = Hc.c.ink)
        Text(hint, fontSize = 13.sp, color = Hc.c.sub, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
    }
}
