package ir.harfchin.dictionary

import java.nio.ByteBuffer
import java.nio.charset.CharacterCodingException
import java.nio.charset.Charset
import java.nio.charset.CodingErrorAction

/**
 * تشخیص خودکار کدگذاری فایل فرهنگ لغت:
 *  ۱. BOM (UTF-8 / UTF-16 LE / UTF-16 BE)
 *  ۲. UTF-8 سختگیرانه (هر بایت نامعتبر = UTF-8 نیست)
 *  ۳. در غیر این صورت Windows-1256 (فایلهای قدیمی ویندوز فارسی/عربی)
 */
object TextDecoding {
    val WINDOWS_1256: Charset = Charset.forName("windows-1256")

    enum class Detected { UTF8_BOM, UTF16LE, UTF16BE, UTF8, WINDOWS_1256 }

    data class Result(val text: String, val encoding: Detected)

    fun decode(bytes: ByteArray): Result {
        fun b(i: Int) = bytes[i].toInt() and 0xFF
        if (bytes.size >= 3 && b(0) == 0xEF && b(1) == 0xBB && b(2) == 0xBF)
            return Result(String(bytes, 3, bytes.size - 3, Charsets.UTF_8), Detected.UTF8_BOM)
        if (bytes.size >= 2 && b(0) == 0xFF && b(1) == 0xFE)
            return Result(String(bytes, 2, bytes.size - 2, Charsets.UTF_16LE), Detected.UTF16LE)
        if (bytes.size >= 2 && b(0) == 0xFE && b(1) == 0xFF)
            return Result(String(bytes, 2, bytes.size - 2, Charsets.UTF_16BE), Detected.UTF16BE)
        return try {
            val text = Charsets.UTF_8.newDecoder()
                .onMalformedInput(CodingErrorAction.REPORT)
                .onUnmappableCharacter(CodingErrorAction.REPORT)
                .decode(ByteBuffer.wrap(bytes)).toString()
            Result(text, Detected.UTF8)
        } catch (e: CharacterCodingException) {
            Result(String(bytes, WINDOWS_1256), Detected.WINDOWS_1256)
        }
    }
}
