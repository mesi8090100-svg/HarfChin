package ir.harfchin.dictionary

import java.io.ByteArrayOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/** یک منبع آنلاین فرهنگ لغت (فقط با زدن دکمه توسط کاربر دانلود میشود) */
data class OnlineSource(
    val id: String,
    val title: String,
    val description: String,
    val approxWords: Int,
    val approxSizeMb: Float,
    val fileName: String,
    val urls: List<String>,
    /** در فهرستهای دهخدا، مدخلهای چندکلمهای (مثل «آب آسیا») کنار گذاشته میشوند تا کلمه جعلی ساخته نشود */
    val dropPhrases: Boolean = false
)

/**
 * فهرست منابع معتبر متنباز (روی GitHub). هر منبع دو آدرس دارد (raw و jsDelivr)؛
 * اگر یکی در دسترس نبود، دومی امتحان میشود.
 * تعداد کلمات بعد از نرمالسازی و فیلتر حروف فارسی با همین کد سنجیده شده است.
 */
object OnlineDictionaries {
    val SOURCES = listOf(
        OnlineSource(
            "dehkhoda", "لغتنامه دهخدا",
            "بزرگترین منبع؛ بیشترین شانس پیدا کردن کلمات کمیاب بازی",
            156_000, 3.9f, "dehkhoda.json",
            listOf(
                "https://raw.githubusercontent.com/pfndesign/an-array-of-persian-words/main/words.json",
                "https://cdn.jsdelivr.net/gh/pfndesign/an-array-of-persian-words@main/words.json"
            ),
            dropPhrases = true
        ),
        OnlineSource(
            "upc", "پیکره اوپسالا (UPC)",
            "کلمات واقعی متنهای فارسی، شامل جمع و صرف فعل",
            65_000, 1.1f, "upc_words.txt",
            listOf(
                "https://raw.githubusercontent.com/samanvp/persian-lexicon/master/data/persian-words.txt",
                "https://cdn.jsdelivr.net/gh/samanvp/persian-lexicon@master/data/persian-words.txt"
            )
        ),
        OnlineSource(
            "wordlist_fa", "کلمات پایه",
            "فهرست کوچک کلمات ساده برای بازیهای کلمه",
            7_000, 0.1f, "word_list_fa.txt",
            listOf(
                "https://raw.githubusercontent.com/mvalipour/word-list-fa/master/words.txt",
                "https://cdn.jsdelivr.net/gh/mvalipour/word-list-fa@master/words.txt"
            )
        )
    )

    private const val MAX_BYTES = 30L * 1024 * 1024

    /** دانلود با گزارش پیشرفت (۰..۱ یا -۱ اگر حجم نامعلوم باشد). روی رشته IO صدا زده شود. */
    fun download(src: OnlineSource, onProgress: (Float) -> Unit): ByteArray {
        var last: Exception? = null
        for (u in src.urls) {
            try { return fetch(u, onProgress) } catch (e: Exception) { last = e }
        }
        throw IOException("دانلود نشد (اینترنت یا VPN را بررسی کنید): ${last?.message ?: ""}".trim())
    }

    private fun fetch(url: String, onProgress: (Float) -> Unit): ByteArray {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15_000; c.readTimeout = 30_000
        c.instanceFollowRedirects = true
        c.setRequestProperty("User-Agent", "HarfChin-Android")
        try {
            if (c.responseCode !in 200..299) throw IOException("HTTP ${c.responseCode}")
            val total = c.contentLengthLong
            if (total > MAX_BYTES) throw IOException("فایل بیش از حد بزرگ است")
            val out = ByteArrayOutputStream(if (total > 0) total.toInt() else 1 shl 20)
            c.inputStream.use { inp ->
                val buf = ByteArray(64 * 1024); var n: Int; var got = 0L; var lastP = -1f
                while (inp.read(buf).also { n = it } > 0) {
                    out.write(buf, 0, n); got += n
                    if (got > MAX_BYTES) throw IOException("فایل بیش از حد بزرگ است")
                    if (Thread.currentThread().isInterrupted) throw IOException("لغو شد")
                    val p = if (total > 0) got.toFloat() / total else -1f
                    if (p < 0 || p - lastP >= 0.02f) { onProgress(p); lastP = p }
                }
            }
            return out.toByteArray()
        } finally { c.disconnect() }
    }

    /** پیشپردازش متن دانلودشده پیش از تجزیه */
    fun prepare(src: OnlineSource, text: String): String {
        if (!src.dropPhrases) return text
        // JSON آرایهای از رشتهها: مدخلهای دارای فاصله را حذف کن
        val arr = kotlinx.serialization.json.Json.parseToJsonElement(text) as? kotlinx.serialization.json.JsonArray ?: return text
        return arr.mapNotNull { (it as? kotlinx.serialization.json.JsonPrimitive)?.content?.trim() }
            .filter { it.isNotEmpty() && it.none(Char::isWhitespace) }
            .joinToString("\n")
    }
}
