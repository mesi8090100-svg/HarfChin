package ir.harfchin.dictionary

import ir.harfchin.core.PersianNormalizer
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive

enum class DictFormat { TXT, CSV, JSON }

/** تبدیل فایل‌های TXT / CSV / JSON به مجموعه کلمات نرمال‌شده و معتبر */
object DictionaryParser {

    fun detect(fileName: String): DictFormat =
        when (fileName.substringAfterLast('.', "").lowercase()) {
            "csv", "tsv" -> DictFormat.CSV
            "json" -> DictFormat.JSON
            else -> DictFormat.TXT
        }

    fun parse(text: String, format: DictFormat): Set<String> {
        val clean = text.removePrefix("\uFEFF")
        val raw: Sequence<String> = when (format) {
            DictFormat.TXT -> parseTxt(clean)
            DictFormat.CSV -> parseCsv(clean)
            DictFormat.JSON -> parseJson(clean)
        }
        return raw.mapNotNull { PersianNormalizer.normalizeWordOrNull(it) }.toCollection(LinkedHashSet())
    }

    /** هر خط یک کلمه؛ اگر خط شامل تب/ویرگول باشد، ستون اول. عدد فراوانی انتهای خط حذف می‌شود. */
    private fun parseTxt(text: String) = text.lineSequence()
        .map { it.split('\t', ',', ';', '|')[0].trim() }
        .map { it.replace(Regex("""\s+[0-9۰-۹]+$"""), "") }
        .filter { it.isNotEmpty() && !it.startsWith("#") }

    private val headerNames = setOf("word", "words", "کلمه", "واژه", "لغت", "term")

    private fun parseCsv(text: String): Sequence<String> {
        val lines = text.lineSequence().filter { it.isNotBlank() }.toList()
        if (lines.isEmpty()) return emptySequence()
        val sep = if (lines[0].count { it == '\t' } > lines[0].count { it == ',' }) '\t' else ','
        val header = splitCsv(lines[0], sep).map { it.trim().lowercase() }
        val col = header.indexOfFirst { it in headerNames }
        val start = if (col >= 0) 1 else 0
        val idx = if (col >= 0) col else 0
        return lines.asSequence().drop(start).mapNotNull { splitCsv(it, sep).getOrNull(idx) }
    }

    private fun splitCsv(line: String, sep: Char): List<String> {
        val out = ArrayList<String>()
        val sb = StringBuilder()
        var quoted = false
        var i = 0
        while (i < line.length) {
            val c = line[i]
            when {
                c == '"' && quoted && i + 1 < line.length && line[i + 1] == '"' -> { sb.append('"'); i++ }
                c == '"' -> quoted = !quoted
                c == sep && !quoted -> { out.add(sb.toString()); sb.clear() }
                else -> sb.append(c)
            }
            i++
        }
        out.add(sb.toString())
        return out
    }

    /** پشتیبانی: ["a","b"] ، [{"word":"a"}] ، {"words":[...]} ، {"a":"معنی", ...} */
    private fun parseJson(text: String): Sequence<String> {
        val root = Json.parseToJsonElement(text)
        val out = ArrayList<String>()
        collect(root, out, depth = 0)
        return out.asSequence()
    }

    private fun collect(e: JsonElement, out: MutableList<String>, depth: Int) {
        when (e) {
            is JsonPrimitive -> if (e.isString) out.add(e.content)
            is JsonArray -> e.forEach { collect(it, out, depth + 1) }
            is JsonObject -> {
                val key = e.keys.firstOrNull { it.lowercase() in headerNames }
                when {
                    key != null -> collect(e.getValue(key), out, depth + 1)
                    depth == 0 -> out.addAll(e.keys)   // دیکشنری کلمه → معنی
                    else -> e.values.firstOrNull { it is JsonPrimitive && it.isString }?.let { collect(it, out, depth + 1) }
                }
            }
        }
    }
}
