# معماری حرف‌چین

```
app/src/main/java/ir/harfchin/
├── HarfChinApp.kt          ساخت ScanPipeline و نصب یک‌باره فرهنگ پیش‌فرض
├── MainActivity.kt         مجوز Overlay و MediaProjection، شروع سرویس
├── core/
│   ├── PersianNormalizer.kt   ي→ی، ك→ک، حذف اعراب/نیم‌فاصله، الفبای مجاز
│   └── model/Models.kt        Tile, Grid, FoundWord, MultiplierMode
├── solver/
│   ├── Trie.kt                درخت پیشوندی
│   └── WordSolver.kt          DFS روی ۸ همسایه + هرس + Scoring
├── dictionary/
│   ├── DictionaryParser.kt    TXT / CSV / JSON → کلمات نرمال‌شده
│   └── DictionaryRepository.kt ذخیره در filesDir/dictionaries، index.json، کش Trie
├── ocr/
│   ├── GrayImage.kt           تصویر خاکستری/دودویی مستقل از Android
│   ├── Preprocessor.kt        کنتراست، شارپ، Otsu، قطبیت خودکار، حذف نویز چوب
│   ├── Components.kt          مؤلفه‌های همبند
│   ├── GridDetector.kt        پیدا کردن شکاف کاشی‌ها (fallback یکنواخت) + جدا کردن گوشه ضریب
│   ├── GlyphFeatures.kt       شمارش و جای نقطه‌ها، سرکش/مد
│   ├── LetterClassifier.kt    رابط روش‌ها + Template (Chamfer) + Zoning
│   ├── OcrEngine.kt           رأی‌گیری وزن‌دار، اطمینان، علامت «نیاز به تأیید»، MultiplierReader
│   ├── GridRecognizer.kt      تصویر جدول → Grid
│   └── TemplateStore.kt       ساخت نمونه از فونت‌ها + نمونه‌های تأییدشده کاربر برای هر پروفایل
├── scanner/
│   ├── ScreenCaptureService.kt سرویس پیش‌زمینه MediaProjection + ImageReader
│   ├── OverlayController.kt   دکمه شناور، FrameView (کادر قابل تنظیم)، نوار ابزار
│   ├── FrameProfileStore.kt   ذخیره کادر برای کلید پروفایل|عرض×ارتفاع صفحه
│   └── OverlayResultView.kt   پنل نتیجه روی بازی
├── pipeline/ScanPipeline.kt   وضعیت مشترک (StateFlow) و اتصال همه بخش‌ها
└── ui/                        صفحات Compose: حل، فرهنگ لغت، تنظیمات
```

## جریان داده
دکمه شناور ← کادر ← `capture()` (پنجره‌ها پیش از عکس مخفی می‌شوند) ← برش Bitmap ← `GrayImage` ← `GridDetector` ← برای هر کاشی: جدا کردن گوشه ضریب ← `binarize` ← (Template + Zoning) × سازگاری نقطه‌ها ← اطمینان ← Grid ← اگر خانه‌ای مشکوک نبود، حل خودکار ← فهرست کلمات.

## قاعده اطمینان
اگر امتیاز بهترین حرف کمتر از `minConfidence` باشد (پیش‌فرض ۷۲٪، قابل تنظیم) یا فاصله‌اش با حرف دوم کمتر از ۸٪ باشد، خانه زرد می‌شود. اگر امتیاز خیلی پایین باشد، حرف خالی می‌ماند و تا تأیید کاربر حل انجام نمی‌شود.

## حل‌کننده
مسیرها از هر ۱۶ خانه شروع می‌شوند. اگر پیشوند در Trie نباشد، شاخه فوراً هرس می‌شود. برای هر کلمه فقط مسیر با بیشترین امتیاز نگه داشته می‌شود. مرتب‌سازی: امتیاز، سپس طول، سپس الفبا.
