package ir.harfchin.dictionary

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

/** پوشش کلمات قبولشده بازی (از اسکرینشاتهای لیست کلمات) بدون تکیه بر فرهنگ «تأییدشده بازی» */
class OptimizedDictionariesTest {
    private fun read(n: String): Set<String> {
        val f = listOf("src/main/assets/dictionaries/$n", "app/src/main/assets/dictionaries/$n").map(::File).first { it.exists() }
        return DictionaryParser.parse(f.readText(), DictFormat.TXT)
    }

    @Test fun coversAcceptedWords() {
        val all = read("common_fa.txt") + read("common_plus_fa.txt") + read("verbs_fa.txt") + read("dehkhoda_rare_fa.txt")
        val accepted = "تحدید ظهیر ارسال تقویم جرگه خست کتلت پاپ سخندان ژنو خشت تصور چسبند غله اکثم مقبض کرخ کشاله صف معظم عذاب مغرق خاکریز زردک خدمه حسام پیادگی مژده تثمین بذل چپیده مجبور سراگوش جلجل گوزو عزا لگدکوبی خفه پسنگک فندک متخادم تعقل شفق سوزش لهجه شلنگ مستسعد لنگه گفتند خوردند قهقهه بگنجد بجنگد".split(" ")
        assertEquals(emptyList<String>(), accepted.filter { it !in all })
    }

    @Test fun rareHasNoLongOrTwoLetter() {
        val accepted = read("game_accepted.txt")
        assertTrue(read("dehkhoda_rare_fa.txt").filter { it !in accepted }.all { it.length in 3..7 })
    }
}
