package ir.harfchin.dictionary

import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class VerbsDictionaryTest {
    @Test fun containsConjugationsTheGameAccepts() {
        val f = listOf("src/main/assets/dictionaries/verbs_fa.txt", "app/src/main/assets/dictionaries/verbs_fa.txt").map(::File).first { it.exists() }
        val w = DictionaryParser.parse(f.readText(), DictFormat.TXT)
        listOf("گفتند", "خوردند", "بگنجد", "بجنگد", "چسبند").forEach { assertTrue(it, it in w) }
    }
}
