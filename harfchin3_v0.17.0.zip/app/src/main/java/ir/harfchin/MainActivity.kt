package ir.harfchin

import android.Manifest
import android.content.Intent
import android.media.projection.MediaProjectionConfig
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import ir.harfchin.scanner.ScreenCaptureService
import ir.harfchin.ui.HarfChinTheme
import ir.harfchin.ui.MainScreen

class MainActivity : ComponentActivity() {

    /** وضعیت مجوز «نمایش روی برنامهها» — در onResume تازه میشود (مثلاً بعد از برگشت از تنظیمات) */
    private var overlayGranted by mutableStateOf(false)

    private val projectionLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val data = r.data
        if (r.resultCode == RESULT_OK && data != null) {
            ScreenCaptureService.start(this, r.resultCode, data)
            moveTaskToBack(true)   // برگشت به بازی؛ از این به بعد دکمه شناور روی بازی است
        }
    }

    private val notifLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33 && savedInstanceState == null &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED
        ) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        overlayGranted = Settings.canDrawOverlays(this)
        val pipeline = (application as HarfChinApp).pipeline
        setContent {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                HarfChinTheme {
                    // صفحه شروع فقط یک بار در هر باز شدن برنامه (نه با چرخش صفحه)
                    // برنامه از همان اول زیر صفحه شروع آماده است؛ هنگام خروج صفحه شروع محو میشود
                    // و برنامه همزمان نرم ظاهر میشود (بدون پرش و فلش)
                    var splash by androidx.compose.runtime.saveable.rememberSaveable { mutableStateOf(savedInstanceState == null) }
                    var revealed by androidx.compose.runtime.remember { mutableStateOf(!splash) }
                    val reveal by androidx.compose.animation.core.animateFloatAsState(
                        if (revealed) 1f else 0f, androidx.compose.animation.core.tween(650), label = "reveal")
                    androidx.compose.foundation.layout.Box {
                        androidx.compose.foundation.layout.Box(androidx.compose.ui.Modifier.graphicsLayer {
                            alpha = reveal; val s = 0.97f + 0.03f * reveal; scaleX = s; scaleY = s
                        }) {
                            MainScreen(pipeline = pipeline, onStartOverlay = ::startOverlay, overlayGranted = overlayGranted, onSetupFrame = ::setupFrame)
                        }
                        if (splash) ir.harfchin.ui.SplashScreen(onExitStart = { revealed = true }, onDone = { splash = false })
                    }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        overlayGranted = Settings.canDrawOverlays(this)
    }

    /** باز کردن تنظیم کادر روی بازی (یک بار تنظیم، بعد فقط ذرهبین) */
    private fun setupFrame() {
        val svc = ScreenCaptureService.instance
        if (svc != null) { svc.openFrameSetup(); moveTaskToBack(true) }
        else { ScreenCaptureService.setupOnStart = true; startOverlay() }
    }

    private fun startOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        if (ScreenCaptureService.instance != null) { moveTaskToBack(true); return }
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        // Android 14+: فقط «کل صفحه» — اگر «یک برنامه» انتخاب شود، از بازی هیچ تصویری نمیرسد
        val intent = if (Build.VERSION.SDK_INT >= 34)
            mpm.createScreenCaptureIntent(MediaProjectionConfig.createConfigForDefaultDisplay())
        else mpm.createScreenCaptureIntent()
        projectionLauncher.launch(intent)
    }
}
