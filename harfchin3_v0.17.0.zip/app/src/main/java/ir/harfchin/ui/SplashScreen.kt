package ir.harfchin.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/** امضای سازنده */
const val CREATOR = "me.kinG.si"

/**
 * صفحه شروع آرام (حدود ۲٫۸ ثانیه، با لمس زودتر تمام میشود):
 *  همان رنگهای خود برنامه، بدون لرزش و فلش.
 *  ۱. پسزمینه از سیاه به گرادیان برنامه محو میشود
 *  ۲. چهار کاشی لوگو یکییکی نرم بالا میآیند و جا میافتند
 *  ۳. «ساخته شده توسط» محو میشود؛ حروف me.kinG.si با فاصله کوتاه نرم بالا میآیند (رنگ گرادیان)
 *  ۴. نور ملایمی آرام از روی اسم رد میشود
 *  ۵. خروج: کل صحنه آرام کمی بزرگ و محو میشود و برنامه از زیرش ظاهر میشود (onDone هنگام شروع محو شدن صدا زده میشود)
 */
@Composable
fun SplashScreen(onExitStart: () -> Unit, onDone: () -> Unit) {
    val enter = remember { Animatable(0f) }
    val tiles = remember { List(4) { Animatable(0f) } }
    val by = remember { Animatable(0f) }
    val letters = remember { CREATOR.map { Animatable(0f) } }
    val sheen = remember { Animatable(-0.3f) }
    val exit = remember { Animatable(0f) }
    var leaving by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    val soft = CubicBezierEasing(0.22f, 1f, 0.36f, 1f)   // ease-out نرم

    suspend fun leave() {
        if (leaving) return
        leaving = true
        onExitStart()
        exit.animateTo(1f, tween(650, easing = FastOutSlowInEasing))
        onDone()
    }

    val breathe = rememberInfiniteTransition(label = "b")
    val glow by breathe.animateFloat(0.85f, 1f, infiniteRepeatable(tween(1600, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "g")

    LaunchedEffect(Unit) {
        launch { enter.animateTo(1f, tween(700, easing = LinearOutSlowInEasing)) }
        delay(150)
        tiles.forEachIndexed { i, a -> launch { delay(i * 90L); a.animateTo(1f, tween(650, easing = soft)) } }
        delay(500)
        launch { by.animateTo(1f, tween(600, easing = soft)) }
        delay(150)
        letters.forEachIndexed { i, a -> launch { delay(i * 45L); a.animateTo(1f, tween(550, easing = soft)) } }
        delay(CREATOR.length * 45L + 350)
        launch { sheen.animateTo(1.3f, tween(1000, easing = FastOutSlowInEasing)) }
        delay(800)
        leave()
    }

    val bg = Brush.linearGradient(listOf(Color(0xFF241A33), Plum, Grape))
    Box(
        Modifier.fillMaxSize()
            .graphicsLayer { alpha = 1f - exit.value }
            .background(Color(0xFF120D1A))
            .clickable(remember { MutableInteractionSource() }, indication = null) { scope.launch { leave() } },
        contentAlignment = Alignment.Center
    ) {
        Box(Modifier.fillMaxSize().graphicsLayer { alpha = enter.value }.background(bg))
        // هاله ملایم پشت لوگو
        Canvas(Modifier.fillMaxSize().graphicsLayer { alpha = enter.value }) {
            drawCircle(Brush.radialGradient(listOf(Berry.copy(alpha = 0.22f * glow), Color.Transparent),
                center = Offset(center.x, center.y - size.height * 0.06f), radius = size.minDimension * 0.6f),
                size.minDimension * 0.6f, Offset(center.x, center.y - size.height * 0.06f))
        }

        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.graphicsLayer {
                val e = exit.value
                scaleX = 1f + 0.06f * e; scaleY = scaleX
                translationY = -24f * e
            }
        ) {
            // لوگو: چهار کاشی که نرم بالا میآیند
            Column(
                Modifier.size(84.dp).clip(RoundedCornerShape(24.dp))
                    .background(Color.White.copy(alpha = 0.10f * enter.value)).padding(11.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                val cols = listOf(Coral, Sun, Mint, Sky)
                for (r in 0 until 2) Row(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    for (c in 0 until 2) {
                        val k = r * 2 + c; val p = tiles[k].value
                        Box(Modifier.weight(1f).fillMaxHeight()
                            .graphicsLayer { alpha = p; translationY = (1f - p) * 26f; scaleX = 0.8f + 0.2f * p; scaleY = scaleX }
                            .clip(RoundedCornerShape(8.dp)).background(cols[k]))
                    }
                }
            }
            Spacer(Modifier.height(30.dp))

            Text(
                "ساخته شده توسط", color = Color.White.copy(alpha = 0.7f), fontSize = 15.sp,
                fontWeight = FontWeight.Normal, fontFamily = Vazir,
                modifier = Modifier.graphicsLayer { alpha = by.value; translationY = (1f - by.value) * 10f }
            )
            Spacer(Modifier.height(4.dp))

            Box(contentAlignment = Alignment.Center) {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                    Row(verticalAlignment = Alignment.Bottom) {
                        CREATOR.forEachIndexed { i, ch ->
                            val p = letters[i].value
                            Text(
                                ch.toString(),
                                fontSize = 40.sp, fontWeight = FontWeight.ExtraBold,
                                style = TextStyle(brush = Brush.verticalGradient(
                                    if (ch == 'G') listOf(Sun, Coral) else listOf(Color.White, Color(0xFFF3D9FF)))),
                                modifier = Modifier.graphicsLayer { alpha = p; translationY = (1f - p) * 18f }
                            )
                        }
                    }
                }
                // نور ملایم روی اسم
                Canvas(Modifier.matchParentSize()) {
                    val x = sheen.value * size.width
                    drawRect(Brush.linearGradient(listOf(Color.Transparent, Color.White.copy(alpha = 0.28f), Color.Transparent),
                        start = Offset(x - 90f, 0f), end = Offset(x + 90f, size.height)))
                }
            }

            // خط نازک زیر اسم که از وسط باز میشود
            Box(Modifier.padding(top = 10.dp).height(2.dp).width(120.dp * letters.last().value)
                .clip(RoundedCornerShape(1.dp))
                .background(Brush.horizontalGradient(listOf(Color.Transparent, Sun.copy(alpha = 0.9f), Color.Transparent))))
        }
    }
}
