package ir.harfchin.ui

import android.graphics.BitmapFactory
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import ir.harfchin.core.PersianNormalizer
import ir.harfchin.pipeline.ScanPipeline
import ir.harfchin.pipeline.TileCollector

/**
 * مجموعه حروف: پوشش هر ۳۲ حرف + کاشیهایی که خودکار ذخیره شدهاند و منتظر تأییدند.
 * تأیید هر کاشی = برنامه آن حرف را از این به بعد خودکار میشناسد.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun CollectionScreen(pipeline: ScanPipeline) {
    val pending by pipeline.pending.collectAsStateWithLifecycle()
    val version by pipeline.coverageVersion.collectAsStateWithLifecycle()
    val coverage = remember(version, pending.size) { pipeline.coverage() }
    val done = coverage.count { it.value >= TileCollector.ENOUGH }
    var pickFor by remember { mutableStateOf<TileCollector.Pending?>(null) }
    var confirmClear by remember { mutableStateOf(false) }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            SectionCard("پوشش حروف", Icons.Rounded.Star, Sun) {
                Text("$done از ${coverage.size} حرف کامل", fontWeight = FontWeight.Bold, color = Hc.c.ink)
                LinearProgressIndicator(progress = { done.toFloat() / coverage.size },
                    modifier = Modifier.fillMaxWidth().clip(CircleShape), color = Mint, trackColor = Mint.copy(alpha = 0.18f))
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    coverage.forEach { (l, n) ->
                        val c = when { n >= TileCollector.ENOUGH -> Mint; n > 0 -> Sun; else -> Hc.c.sub }
                        Column(
                            Modifier.width(44.dp).clip(RoundedCornerShape(12.dp)).background(c.copy(alpha = 0.15f))
                                .border(1.dp, c.copy(alpha = 0.5f), RoundedCornerShape(12.dp)).padding(vertical = 4.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(l, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Hc.c.ink)
                            Text("$n", fontSize = 11.sp, color = c, fontWeight = FontWeight.Bold)
                        }
                    }
                }
                Text("سبز: کامل · زرد: کم‌نمونه · خاکستری: بی‌نمونه", fontSize = 12.sp, color = Hc.c.sub)
            }
        }
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("منتظر تأیید (${pending.size})", fontSize = 17.sp, fontWeight = FontWeight.ExtraBold, color = Hc.c.ink,
                    modifier = Modifier.weight(1f))
                if (pending.isNotEmpty()) TextButton(onClick = { confirmClear = true }) { Text("پاک کردن همه", color = Coral) }
            }
            Text("کاشی‌های جدید وسط بازی خودکار ذخیره می‌شوند. وقتی وقت داشتید، حرف درست هر کدام را بزنید.",
                fontSize = 12.sp, color = Hc.c.sub)
        }
        if (pending.isEmpty()) item {
            EmptyState(Icons.Rounded.Check, Mint, "چیزی منتظر تأیید نیست", "با هر اسکن، کاشی‌های جدید اینجا می‌آیند")
        }
        items(pending, key = { it.file.name }) { p -> PendingRow(p, onPick = { l -> pipeline.confirmSample(p, l) },
            onMore = { pickFor = p }, onDelete = { pipeline.deleteSample(p) }) }
    }

    pickFor?.let { p ->
        AlertDialog(
            onDismissRequest = { pickFor = null },
            shape = RoundedCornerShape(24.dp),
            title = { Text("این کاشی چه حرفی است؟") },
            text = {
                FlowRow {
                    PersianNormalizer.TILE_LETTERS.forEach { l ->
                        Box(Modifier.padding(2.dp).size(44.dp).clip(RoundedCornerShape(12.dp)).background(Hc.c.tile)
                            .border(1.dp, Hc.c.tileEdge, RoundedCornerShape(12.dp))
                            .clickable { pipeline.confirmSample(p, l); pickFor = null },
                            contentAlignment = Alignment.Center) { Text(l, fontSize = 19.sp, fontWeight = FontWeight.Bold, color = Hc.c.tileInk) }
                    }
                }
            },
            confirmButton = {}, dismissButton = { TextButton(onClick = { pickFor = null }) { Text("انصراف") } }
        )
    }
    if (confirmClear) AlertDialog(
        onDismissRequest = { confirmClear = false },
        title = { Text("پاک کردن همه کاشی‌ها") },
        text = { Text("کاشی‌های منتظر تأیید پاک می‌شوند. حروفی که قبلاً تأیید کرده‌اید می‌مانند.") },
        confirmButton = { Button(onClick = { pipeline.clearSamples(); confirmClear = false },
            colors = ButtonDefaults.buttonColors(containerColor = Coral)) { Text("پاک کن") } },
        dismissButton = { TextButton(onClick = { confirmClear = false }) { Text("انصراف") } }
    )
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun PendingRow(p: TileCollector.Pending, onPick: (String) -> Unit, onMore: () -> Unit, onDelete: () -> Unit) {
    val img = remember(p.file.name) { BitmapFactory.decodeFile(p.file.path)?.asImageBitmap() }
    Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Hc.c.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = if (Hc.c.dark) 0.dp else 1.dp)) {
        Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            if (img != null) Image(img, null, Modifier.size(64.dp).clip(RoundedCornerShape(12.dp)), contentScale = ContentScale.Crop)
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(if (p.guess.isNotEmpty()) "حدس برنامه: ${p.guess}" else "برنامه نشناخت", fontSize = 12.sp, color = Hc.c.sub)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    p.alternatives.forEachIndexed { k, l ->
                        val c = listOf(Mint, Sky, Grape, Berry, Coral)[k % 5]
                        Box(Modifier.size(40.dp).clip(RoundedCornerShape(11.dp)).background(c).clickable { onPick(l) },
                            contentAlignment = Alignment.Center) { Text(l, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color.White) }
                    }
                    Box(Modifier.height(40.dp).clip(RoundedCornerShape(11.dp)).background(Hc.c.tile).clickable { onMore() }
                        .padding(horizontal = 12.dp), contentAlignment = Alignment.Center) {
                        Text("حرف دیگر", fontSize = 13.sp, color = Hc.c.tileInk, fontWeight = FontWeight.Bold)
                    }
                }
            }
            IconButton(onClick = onDelete) { Icon(Icons.Rounded.Delete, "حذف", tint = Coral) }
        }
    }
}
