package ir.harfchin.pipeline

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import ir.harfchin.ocr.BinImage
import ir.harfchin.ocr.GrayImage
import ir.harfchin.ocr.TileReader
import java.io.File

/**
 * جمعآوری خودکار عکس کاشیها (فقط خود کاشی، نه کل صفحه) در حافظه داخلی برنامه.
 * فقط کاشیهای جدید ذخیره میشوند: حرف مردد یا حرفی که هنوز کمتر از ۳ نمونه دارد،
 * و اگر شکلی تقریباً یکسان قبلاً در صف باشد، تکراری ذخیره نمیشود.
 * کاربر بعداً (نه وسط بازی) در بخش «مجموعه حروف» حرف درست هر کاشی را تأیید میکند.
 */
class TileCollector(context: Context) {
    private val dir = File(context.filesDir, "tile_samples").apply { mkdirs() }
    private val glyphCache = HashMap<String, BinImage?>()

    /** نام فایل: زمان_حدس_پیشنهادها.png */
    data class Pending(val file: File, val guess: String, val alternatives: List<String>)

    @Synchronized
    fun list(): List<Pending> = (dir.listFiles { f -> f.name.endsWith(".png") } ?: emptyArray())
        .sortedByDescending { it.lastModified() }
        .map { f ->
            val parts = f.nameWithoutExtension.split('_')
            val guess = parts.getOrNull(1)?.takeIf { it != "-" } ?: ""
            val alts = parts.getOrNull(2)?.map { it.toString() }.orEmpty()
            Pending(f, guess, (listOf(guess) + alts).filter { it.isNotEmpty() }.distinct())
        }

    /** true یعنی ذخیره شد (جدید بود) */
    @Synchronized
    fun save(crop: GrayImage, guess: String, alternatives: List<String>): File? {
        val g = TileReader.letterGlyph(crop) ?: return null
        val existing = list()
        if (existing.size >= MAX) return null
        for (p in existing) {
            val og = glyphCache.getOrPut(p.file.name) { load(p.file)?.let { TileReader.letterGlyph(it) } } ?: continue
            var d = 0
            for (i in 0 until 1024) if (g.px[i] != og.px[i]) d++
            if (d <= DUPLICATE) return null
        }
        val alts = alternatives.filter { it.length == 1 }.take(4).joinToString("")
        val f = File(dir, "${System.currentTimeMillis()}_${guess.ifEmpty { "-" }}_$alts.png")
        val bmp = Bitmap.createBitmap(crop.width, crop.height, Bitmap.Config.ARGB_8888)
        bmp.setPixels(IntArray(crop.px.size) { val v = crop.px[it].coerceIn(0, 255); (0xFF shl 24) or (v shl 16) or (v shl 8) or v },
            0, crop.width, 0, 0, crop.width, crop.height)
        f.outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        bmp.recycle()
        glyphCache[f.name] = g
        return f
    }

    /** خواندن کاشی ذخیرهشده به صورت خاکستری (همان ورودی TileReader) */
    fun load(f: File): GrayImage? {
        val b = BitmapFactory.decodeFile(f.path) ?: return null
        val px = IntArray(b.width * b.height); b.getPixels(px, 0, b.width, 0, 0, b.width, b.height)
        return GrayImage.fromArgb(px, b.width, b.height).also { b.recycle() }
    }

    @Synchronized
    fun delete(f: File) { glyphCache.remove(f.name); f.delete() }

    @Synchronized
    fun clear() { list().forEach { delete(it.file) } }

    companion object {
        const val MAX = 300
        const val DUPLICATE = 40
        /** حرفی که کمتر از این تعداد نمونه دارد «جدید» حساب میشود */
        const val ENOUGH = 3
    }
}
