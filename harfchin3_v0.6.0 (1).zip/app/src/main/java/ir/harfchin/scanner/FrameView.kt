package ir.harfchin.scanner

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs

/** نمای کادر: جابه‌جایی با کشیدن داخل کادر، تغییر اندازه با ۴ دستگیره گوشه، نمایش خطوط ۴×۴ */
@SuppressLint("ViewConstructor")
class FrameView(ctx: Context, var rect: FrameRect, private val handle: Int) : View(ctx) {
    private val border = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#FF2EC4A6"); style = Paint.Style.STROKE; strokeWidth = 6f }
    private val grid = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#AA2EC4A6"); strokeWidth = 2.5f; pathEffect = android.graphics.DashPathEffect(floatArrayOf(14f, 10f), 0f) }
    private val dim = Paint().apply { color = Color.parseColor("#77000000") }
    private val knob = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#FFFF7A59") }
    private val knobRing = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; style = Paint.Style.STROKE; strokeWidth = 4f }
    private var mode = 0  // 0 هیچ، 1 جابه‌جایی، 2..5 گوشه‌ها
    private var lx = 0f; private var ly = 0f
    private val minSide = handle * 3

    override fun onDraw(c: Canvas) {
        val r = RectF(rect.x.toFloat(), rect.y.toFloat(), (rect.x + rect.width).toFloat(), (rect.y + rect.height).toFloat())
        c.drawRect(0f, 0f, width.toFloat(), r.top, dim); c.drawRect(0f, r.bottom, width.toFloat(), height.toFloat(), dim)
        c.drawRect(0f, r.top, r.left, r.bottom, dim); c.drawRect(r.right, r.top, width.toFloat(), r.bottom, dim)
        c.drawRoundRect(r, 18f, 18f, border)
        for (i in 1..3) {
            val x = r.left + r.width() * i / 4; val y = r.top + r.height() * i / 4
            c.drawLine(x, r.top, x, r.bottom, grid); c.drawLine(r.left, y, r.right, y, grid)
        }
        listOf(r.left to r.top, r.right to r.top, r.left to r.bottom, r.right to r.bottom)
            .forEach { (x, y) -> c.drawCircle(x, y, handle / 1.6f, knob); c.drawCircle(x, y, handle / 1.6f, knobRing) }
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(e: MotionEvent): Boolean {
        val l = rect.x; val t = rect.y; val r = rect.x + rect.width; val b = rect.y + rect.height
        when (e.action) {
            MotionEvent.ACTION_DOWN -> {
                lx = e.x; ly = e.y
                fun near(x: Int, y: Int) = abs(e.x - x) < handle * 1.4f && abs(e.y - y) < handle * 1.4f
                mode = when {
                    near(l, t) -> 2; near(r, t) -> 3; near(l, b) -> 4; near(r, b) -> 5
                    e.x in l.toFloat()..r.toFloat() && e.y in t.toFloat()..b.toFloat() -> 1
                    else -> 0
                }
                return mode != 0
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = (e.x - lx).toInt(); val dy = (e.y - ly).toInt(); lx = e.x; ly = e.y
                var nl = l; var nt = t; var nr = r; var nb = b
                when (mode) {
                    1 -> { nl += dx; nr += dx; nt += dy; nb += dy }
                    2 -> { nl += dx; nt += dy }; 3 -> { nr += dx; nt += dy }
                    4 -> { nl += dx; nb += dy }; 5 -> { nr += dx; nb += dy }
                }
                if (mode == 1 && width > 0 && height > 0) {   // کادر از صفحه بیرون نرود
                    val sx = when { nl < 0 -> -nl; nr > width -> width - nr; else -> 0 }
                    val sy = when { nt < 0 -> -nt; nb > height -> height - nb; else -> 0 }
                    nl += sx; nr += sx; nt += sy; nb += sy
                }
                if (nr - nl >= minSide && nb - nt >= minSide) { rect = FrameRect(nl, nt, nr - nl, nb - nt); invalidate() }
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { mode = 0; return true }
        }
        return false
    }
}
