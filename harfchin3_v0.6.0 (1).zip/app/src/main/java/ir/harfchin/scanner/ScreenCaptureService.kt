package ir.harfchin.scanner

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.graphics.Point
import android.graphics.drawable.Icon
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.util.Log
import android.view.Display
import android.view.WindowManager
import android.widget.Toast

/**
 * سرویس پیشزمینه: نگهداشتن MediaProjection، نمایش پنجره شناور و گرفتن فریم صفحه.
 * مجوز ضبط یک بار در هر جلسه گرفته میشود؛ کاربر بعد از آن بدون خروج از بازی اسکن میکند.
 *
 * مدیریت فریم: listener هر فریم جدید را با acquireLatestImage میگیرد، فریم کششده قبلی را میبندد
 * و فقط آخرین فریم را نگه میدارد. به این ترتیب صف ImageReader هیچوقت پر نمیشود و جریان فریم
 * در دستگاههایی که با صف پر متوقف میشوند قطع نمیشود.
 */
class ScreenCaptureService : Service() {

    private var projection: MediaProjection? = null
    @Volatile private var reader: ImageReader? = null
    private var display: VirtualDisplay? = null
    private lateinit var workerThread: HandlerThread
    private lateinit var worker: Handler
    private val main = Handler(Looper.getMainLooper())
    private var overlay: OverlayController? = null
    private var displayListener: DisplayManager.DisplayListener? = null

    /** آخرین فریم کششده (متعلق به reader فعلی). دسترسی فقط با قفل frameLock. */
    private val frameLock = Any()
    private var latestImage: Image? = null
    private var latestReader: ImageReader? = null
    private var latestAt = 0L

    var screenW = 0; private set
    var screenH = 0; private set

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        workerThread = HandlerThread("capture").apply { start() }
        worker = Handler(workerThread.looper)
        instance = this
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { stopSelf(); return START_NOT_STICKY }
        // startForeground باید قبل از getMediaProjection صدا زده شود (الزام Android 14)
        startForegroundCompat()
        val code = intent?.getIntExtra(EXTRA_CODE, Activity.RESULT_CANCELED) ?: Activity.RESULT_CANCELED
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33) intent?.getParcelableExtra(EXTRA_DATA, Intent::class.java)
            else @Suppress("DEPRECATION") intent?.getParcelableExtra(EXTRA_DATA)

        if (projection == null) {
            if (code != Activity.RESULT_OK || data == null) { stopSelf(); return START_NOT_STICKY }
            val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = mpm.getMediaProjection(code, data).also { p ->
                p.registerCallback(object : MediaProjection.Callback() {
                    override fun onStop() { main.post { stopSelf() } }
                }, main)
            }
            setupDisplay()
            registerDisplayListener()
        }

        if (overlay == null) {
            try {
                overlay = OverlayController(this).also { it.showBubble() }
            } catch (e: WindowManager.BadTokenException) {
                failOverlay(e)
                return START_NOT_STICKY
            } catch (e: SecurityException) {
                failOverlay(e)
                return START_NOT_STICKY
            } catch (e: IllegalStateException) {
                failOverlay(e)
                return START_NOT_STICKY
            }
        }
        // توکن MediaProjection بعد از کشته شدن سرویس قابل استفاده مجدد نیست؛ پس STICKY نیست
        return START_NOT_STICKY
    }

    /** مجوز «نمایش روی برنامهها» لغو شده یا پنجره قابل افزودن نیست */
    private fun failOverlay(e: Exception) {
        Log.w(TAG, "overlay failed", e)
        overlay = null
        Toast.makeText(
            applicationContext,
            "مجوز «نمایش روی برنامهها» در دسترس نیست. آن را در تنظیمات فعال کنید و دوباره اسکن را بزنید.",
            Toast.LENGTH_LONG
        ).show()
        stopSelf()
    }

    // ---------------- اندازه صفحه ----------------

    private fun defaultDisplay(): Display? =
        (getSystemService(DISPLAY_SERVICE) as DisplayManager).getDisplay(Display.DEFAULT_DISPLAY)

    /**
     * اندازه واقعی و فعلی صفحه از WindowManager متعلق به Display واقعی.
     * در API 30+ هر بار یک window context تازه برای همان Display ساخته میشود تا مقدار کششده قدیمی برنگردد.
     */
    private fun readScreenSize(): Pair<Int, Int> {
        val d = defaultDisplay()
        if (Build.VERSION.SDK_INT >= 31 && d != null) {
            val wctx = createWindowContext(d, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, null)
            val b = wctx.getSystemService(WindowManager::class.java).maximumWindowMetrics.bounds
            if (b.width() > 0 && b.height() > 0) return b.width() to b.height()
        }
        if (Build.VERSION.SDK_INT >= 30) {
            val b = (getSystemService(WINDOW_SERVICE) as WindowManager).maximumWindowMetrics.bounds
            if (b.width() > 0 && b.height() > 0) return b.width() to b.height()
        }
        val p = Point()
        @Suppress("DEPRECATION")
        val disp: Display = d ?: (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay
        @Suppress("DEPRECATION")
        disp.getRealSize(p)
        return p.x to p.y
    }

    /** با تغییر Display (چرخش، تغییر رزولوشن) نمایشگر مجازی اندازه جدید میگیرد */
    private fun registerDisplayListener() {
        val dm = getSystemService(DISPLAY_SERVICE) as DisplayManager
        val l = object : DisplayManager.DisplayListener {
            override fun onDisplayAdded(id: Int) {}
            override fun onDisplayRemoved(id: Int) {}
            override fun onDisplayChanged(id: Int) {
                if (id != Display.DEFAULT_DISPLAY || projection == null) return
                val (w, h) = readScreenSize()
                if (w != screenW || h != screenH) setupDisplay()
            }
        }
        dm.registerDisplayListener(l, main)
        displayListener = l
    }

    // ---------------- نمایشگر مجازی ----------------

    private fun setupDisplay() {
        val (w, h) = readScreenSize()
        screenW = w; screenH = h
        val dpi = resources.displayMetrics.densityDpi
        val old = reader
        val fresh = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 3)
        fresh.setOnImageAvailableListener({ r -> onFrame(r) }, worker)

        val d = display
        if (d == null) {
            display = projection?.createVirtualDisplay(
                "harfchin", w, h, dpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, fresh.surface, null, worker
            )
        } else {
            // از Android 14 ساخت VirtualDisplay دوم با همان توکن مجاز نیست؛ پس همان را تغییر میدهیم.
            // ترتیب مهم است: اول surface جدید، بعد بستن reader قدیمی.
            d.resize(w, h, dpi)
            d.surface = fresh.surface
        }
        reader = fresh
        if (old != null) {
            synchronized(frameLock) {
                if (latestReader === old) { latestImage?.close(); latestImage = null; latestReader = null }
            }
            old.setOnImageAvailableListener(null, null)
            old.close()
        }
    }

    /** روی رشته worker: گرفتن آخرین فریم، بستن فریم قبلی، نگهداشتن فقط یکی */
    private fun onFrame(r: ImageReader) {
        val img = try { r.acquireLatestImage() } catch (e: IllegalStateException) { null } ?: return
        synchronized(frameLock) {
            if (r !== reader) { img.close(); return }
            latestImage?.close()
            latestImage = img
            latestReader = r
            latestAt = SystemClock.uptimeMillis()
            frameCount++
        }
    }

    /** تعداد فریمهای دریافتی از ابتدای ضبط؛ برای پیام خطای دقیقتر */
    @Volatile private var frameCount = 0L

    /**
     * کپی آخرین فریم به Bitmap بدون مصرف آن: صفحه ثابت (بازی منتظر حرکت) فریم جدید نمیسازد،
     * پس فریم قبلی باید برای اسکنهای بعدی هم بماند.
     */
    private fun copyLatest(): Bitmap? = synchronized(frameLock) {
        val img = latestImage ?: return@synchronized null
        val plane = img.planes[0]
        val rowPad = plane.rowStride - plane.pixelStride * img.width
        val full = Bitmap.createBitmap(img.width + rowPad / plane.pixelStride, img.height, Bitmap.Config.ARGB_8888)
        plane.buffer.rewind()
        full.copyPixelsFromBuffer(plane.buffer)
        if (rowPad == 0) full else Bitmap.createBitmap(full, 0, 0, img.width, img.height).also { full.recycle() }
    }

    // ---------------- گرفتن تصویر ----------------

    /**
     * گرفتن فریم و برش ناحیه کادر. فراخواننده پنجرههای شناور را قبل از صدا زدن مخفی میکند؛
     * اینجا صبر میکنیم تا فریمی برسد که بعد از این لحظه تولید شده (حداکثر حدود ۶۸۰ میلیثانیه).
     * onResult همیشه روی Main Thread صدا زده میشود.
     */
    fun capture(rect: FrameRect, onResult: (CaptureResult) -> Unit) {
        val requestedAt = SystemClock.uptimeMillis()
        fun deliver(r: CaptureResult) = main.post { onResult(r) }

        fun attempt(tries: Int) {
            // تا ۷۰۰ میلیثانیه منتظر فریم تازه (بعد از مخفی شدن پنجرهها) میمانیم؛ بعد از آن آخرین فریم موجود
            val fresh = synchronized(frameLock) { latestImage != null && latestAt > requestedAt + 30 }
            if (!fresh && tries < 12) { worker.postDelayed({ attempt(tries + 1) }, 60); return }
            val full = try { copyLatest() } catch (e: Exception) { Log.w(TAG, "copy failed", e); null }
            if (full == null) {
                deliver(CaptureResult.Failed(
                    if (frameCount == 0L) "تصویری از صفحه نمیرسد. حرفچین را از اعلان «توقف» ببندید، دوباره «اسکن روی بازی» را بزنید و در پنجره اجازه، «کل صفحه» را انتخاب کنید."
                    else "فریم صفحه آماده نبود؛ دوباره «گرفتن» را بزنید."
                ))
                return
            }
            try {
                val x = rect.x.coerceIn(0, full.width - 1); val y = rect.y.coerceIn(0, full.height - 1)
                val w = rect.width.coerceIn(1, full.width - x); val h = rect.height.coerceIn(1, full.height - y)
                if (isBlack(full, 0, 0, full.width, full.height) || isBlack(full, x, y, w, h)) {
                    full.recycle(); deliver(CaptureResult.Blocked); return
                }
                val crop = Bitmap.createBitmap(full, x, y, w, h)
                if (crop !== full) full.recycle()
                deliver(CaptureResult.Success(crop))
            } catch (e: Exception) {
                Log.w(TAG, "capture failed", e)
                deliver(CaptureResult.Failed(e.message ?: "خطای ناشناخته"))
            }
        }
        // کمی صبر تا سیستم پنجرههای مخفیشده را از صفحه بردارد
        worker.postDelayed({ attempt(0) }, 100)
    }

    /**
     * «کاملاً سیاه» = روی شبکهای از حدود ۴۰۰ نقطه نمونه، روشنترین نقطه کمتر از ۱۲ از ۲۵۵ باشد.
     * محتوای FLAG_SECURE در MediaProjection یکدست سیاه برمیگردد؛ جدول واقعی بازی هرگز این شکلی نیست.
     */
    private fun isBlack(b: Bitmap, x0: Int, y0: Int, w: Int, h: Int): Boolean {
        val steps = 20
        for (j in 0 until steps) for (i in 0 until steps) {
            val px = b.getPixel(x0 + (w - 1) * i / (steps - 1), y0 + (h - 1) * j / (steps - 1))
            val r = (px shr 16) and 0xFF; val g = (px shr 8) and 0xFF; val bl = px and 0xFF
            if (maxOf(r, g, bl) >= 12) return false
        }
        return true
    }

    // ---------------- اعلان ----------------

    private fun startForegroundCompat() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "اسکن حرفچین", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(
            this, 1, Intent(this, ScreenCaptureService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val stopIcon = Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel)
        val n: Notification = Notification.Builder(this, CH)
            .setContentTitle("حرفچین فعال است")
            .setContentText("برای اسکن روی دکمه شناور بزنید")
            .setSmallIcon(ir.harfchin.R.drawable.ic_notif)
            .setOngoing(true)
            .setColor(0xFF8E44AD.toInt())
            .addAction(Notification.Action.Builder(stopIcon, "توقف", stop).build())
            .build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(ID, n)
    }

    override fun onDestroy() {
        instance = null
        displayListener?.let { (getSystemService(DISPLAY_SERVICE) as DisplayManager).unregisterDisplayListener(it) }
        displayListener = null
        runCatching { overlay?.dismissAll() }; overlay = null
        runCatching { display?.release() }; display = null
        synchronized(frameLock) { latestImage?.close(); latestImage = null; latestReader = null }
        runCatching { reader?.setOnImageAvailableListener(null, null); reader?.close() }; reader = null
        runCatching { projection?.stop() }; projection = null
        workerThread.quitSafely()
        super.onDestroy()
    }

    companion object {
        private const val TAG = "HarfChinCapture"
        const val EXTRA_CODE = "code"; const val EXTRA_DATA = "data"; const val ACTION_STOP = "stop"
        private const val CH = "scan"; private const val ID = 7
        @Volatile var instance: ScreenCaptureService? = null; private set

        fun start(ctx: Context, code: Int, data: Intent) {
            ctx.startForegroundService(Intent(ctx, ScreenCaptureService::class.java)
                .putExtra(EXTRA_CODE, code).putExtra(EXTRA_DATA, data))
        }
    }
}
