package ir.harfchin.scanner

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.text.InputType
import ir.harfchin.HarfChinApp
import kotlin.math.abs
import kotlin.math.max

/**
 * پنجره‌های شناور روی بازی:
 *  ۱. حباب کوچک «اسکن» (قابل جابه‌جایی)
 *  ۲. کادر ۴×۴ قابل جابه‌جایی و تغییر اندازه از ۴ گوشه + ورود عددی ابعاد + ذخیره برای پروفایل
 *  ۳. پنل نتیجه (جدول و کلمات) — بدون خروج از بازی
 */
class OverlayController(private val service: ScreenCaptureService) {
    private val ctx: Context = service
    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val store = FrameProfileStore(ctx)
    private var bubble: View? = null
    private var frame: FrameView? = null
    private var toolbar: View? = null
    private var result: View? = null
    private var sizeDialog: View? = null
    private var capturing = false
    private fun remove(v: View?) { if (v != null) runCatching { wm.removeView(v) } }
    private val type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY

    /** افزودن امن پنجره؛ اگر مجوز overlay وسط کار لغو شده باشد، سرویس متوقف میشود */
    private fun safeAdd(v: View, lp: WindowManager.LayoutParams): Boolean = try {
        wm.addView(v, lp); true
    } catch (e: WindowManager.BadTokenException) {
        stopForMissingPermission(); false
    } catch (e: SecurityException) {
        stopForMissingPermission(); false
    }

    private fun stopForMissingPermission() {
        android.widget.Toast.makeText(ctx, "مجوز «نمایش روی برنامهها» لغو شده است", android.widget.Toast.LENGTH_LONG).show()
        service.stopSelf()
    }

    private fun dp(v: Int) = (v * ctx.resources.displayMetrics.density).toInt()

    @SuppressLint("ClickableViewAccessibility")
    fun showBubble() {
        // دکمه شناور گرد گرادیان با آیکون رنگی ذرهبین
        val b = android.widget.FrameLayout(ctx).apply {
            background = android.graphics.drawable.GradientDrawable(
                android.graphics.drawable.GradientDrawable.Orientation.TL_BR,
                intArrayOf(OverlayStyle.PLUM, OverlayStyle.GRAPE, OverlayStyle.BERRY)
            ).apply { shape = android.graphics.drawable.GradientDrawable.OVAL; setStroke(dp(2), 0x66FFFFFF) }
            elevation = dp(8).toFloat()
            addView(android.widget.ImageView(ctx).apply {
                setImageResource(ir.harfchin.R.drawable.ic_bubble)
            }, android.widget.FrameLayout.LayoutParams(dp(32), dp(32), Gravity.CENTER))
            contentDescription = "اسکن"
        }
        val size = dp(58)
        val lp = WindowManager.LayoutParams(
            size, size, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = dp(8); y = dp(160) }
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
        b.setOnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; moved = false; v.animate().scaleX(0.9f).scaleY(0.9f).setDuration(90).start() }
                MotionEvent.ACTION_MOVE -> {
                    if (abs(e.rawX - sx) + abs(e.rawY - sy) > dp(6)) moved = true
                    lp.x = ox + (e.rawX - sx).toInt(); lp.y = oy + (e.rawY - sy).toInt(); wm.updateViewLayout(v, lp)
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    v.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
                    if (e.action == MotionEvent.ACTION_UP && !moved) toggleFrame()
                    else if (moved) {   // چسبیدن به نزدیکترین لبه صفحه
                        val sw = ctx.resources.displayMetrics.widthPixels
                        lp.x = if (lp.x + v.width / 2 < sw / 2) dp(6) else sw - v.width - dp(6)
                        lp.y = lp.y.coerceAtLeast(0)
                        runCatching { wm.updateViewLayout(v, lp) }
                    }
                }
            }
            true
        }
        if (safeAdd(b, lp)) bubble = b
    }

    private fun toggleFrame() { if (frame != null) hideFrame() else showFrame() }

    private fun currentProfile() = store.lastProfile

    private fun showFrame() {
        remove(result); result = null
        val w = service.screenW.takeIf { it > 0 } ?: ctx.resources.displayMetrics.widthPixels
        val h = service.screenH.takeIf { it > 0 } ?: ctx.resources.displayMetrics.heightPixels
        val rect = store.load(currentProfile(), w, h) ?: store.default(w, h)
        val fv = FrameView(ctx, rect, dp(26))
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            // بدون این، روی گوشیهای ناچدار پنجره زیر ناچ شروع نمیشود و مختصات کادر با تصویر ضبطشده (که از ۰ است) فرق میکند
            if (android.os.Build.VERSION.SDK_INT >= 30)
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
            else if (android.os.Build.VERSION.SDK_INT >= 28)
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        if (!safeAdd(fv, lp)) return; frame = fv
        showToolbar(w, h)
    }

    private fun showToolbar(sw: Int, sh: Int) {
        val bar = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            background = OverlayStyle.rounded(ctx, 0xF2221D2A.toInt(), 22f)
            elevation = dp(10).toFloat()
            setPadding(dp(8), dp(8), dp(8), dp(8)); layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        fun btn(t: String, colors: IntArray, f: () -> Unit) =
            OverlayStyle.pill(ctx, t, OverlayStyle.gradient(ctx, colors, 16f), sizeSp = 14f) { f() }
        val gap = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { marginStart = dp(6) }
        bar.addView(btn("📸 گرفتن", intArrayOf(OverlayStyle.MINT, 0xFF26A69A.toInt())) { captureNow(sw, sh) })
        bar.addView(btn("💾 ذخیره", intArrayOf(OverlayStyle.SKY, OverlayStyle.GRAPE)) { frame?.let { store.save(currentProfile(), sw, sh, it.rect); showMessage("✅ کادر ذخیره شد") } }, gap)
        bar.addView(btn("📐 ابعاد", intArrayOf(OverlayStyle.SUN, OverlayStyle.CORAL)) { showSizeDialog() }, gap)
        bar.addView(btn("✕", intArrayOf(0x55FFFFFF, 0x33FFFFFF)) { hideFrame() }, gap)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL; y = dp(24) }
        if (safeAdd(bar, lp)) toolbar = bar
    }

    /** ورود دقیق x / y / عرض / ارتفاع (پیکسل) */
    private fun showSizeDialog() {
        val fv = frame ?: return
        remove(sizeDialog); sizeDialog = null
        val box = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL; background = OverlayStyle.rounded(ctx, Color.WHITE, 22f)
            elevation = dp(12).toFloat(); setPadding(dp(16), dp(14), dp(16), dp(14))
            addView(OverlayStyle.text(ctx, "📐 ابعاد کادر (پیکسل)", 16f, OverlayStyle.PLUM, true))
        }
        fun field(hint: String, v: Int) = EditText(ctx).apply {
            this.hint = hint; setText(v.toString()); inputType = InputType.TYPE_CLASS_NUMBER
            typeface = OverlayStyle.font(ctx); textSize = 15f
        }.also { box.addView(it) }
        val r = fv.rect
        val fx = field("X", r.x); val fy = field("Y", r.y); val fw = field("عرض", r.width); val fh = field("ارتفاع", r.height)
        val lp = WindowManager.LayoutParams(
            dp(240), WindowManager.LayoutParams.WRAP_CONTENT, type,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.CENTER }
        box.addView(OverlayStyle.pill(ctx, "اعمال", OverlayStyle.gradient(ctx, intArrayOf(OverlayStyle.MINT, 0xFF26A69A.toInt()), 14f)) {
            fun v(e: EditText, d: Int) = e.text.toString().toIntOrNull() ?: d
            fv.rect = FrameRect(v(fx, r.x), v(fy, r.y), max(40, v(fw, r.width)), max(40, v(fh, r.height)))
            fv.invalidate(); remove(box); sizeDialog = null
        }, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(10) })
        if (safeAdd(box, lp)) sizeDialog = box
    }

    private fun captureNow(sw: Int, sh: Int) {
        val fv = frame ?: return
        val rect = fv.rect
        store.save(currentProfile(), sw, sh, rect)   // آخرین موقعیت همیشه به‌خاطر سپرده می‌شود
        // مخفی کردن موقت همه پنجره‌ها تا در عکس نیفتند
        if (capturing) return
        capturing = true
        listOfNotNull(fv, toolbar, bubble, sizeDialog).forEach { it.visibility = View.INVISIBLE }
        service.capture(rect) { res ->
            capturing = false
            listOfNotNull(toolbar, bubble).forEach { it.visibility = View.VISIBLE }
            hideFrame()
            when (res) {
                is CaptureResult.Success -> {
                    val app = ctx.applicationContext as HarfChinApp
                    app.pipeline.processCapture(res.bitmap, currentProfile())
                    showResult()
                }
                CaptureResult.Blocked -> showMessage("⛔ این بازی اجازهٔ ضبط صفحه نمیدهد")
                is CaptureResult.Failed -> showMessage("گرفتن تصویر ناموفق بود: ${res.reason}")
            }
        }
    }

    private fun showMessage(m: String) {
        val t = OverlayStyle.text(ctx, m, 14f, Color.WHITE, true).apply {
            background = OverlayStyle.rounded(ctx, 0xF2221D2A.toInt(), 18f); elevation = dp(8).toFloat()
            setPadding(dp(16), dp(10), dp(16), dp(10)); gravity = Gravity.CENTER
        }
        val lp = WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT).apply { gravity = Gravity.CENTER }
        if (safeAdd(t, lp)) {
            t.alpha = 0f; t.animate().alpha(1f).setDuration(150).start()
            t.postDelayed({ t.animate().alpha(0f).setDuration(200).withEndAction { runCatching { wm.removeView(t) } }.start() }, 2200)
        }
    }

    private fun showResult() {
        result?.let { runCatching { wm.removeView(it) } }
        val v = OverlayResultView(ctx, (ctx.applicationContext as HarfChinApp).pipeline) {
            result?.let { runCatching { wm.removeView(it) } }; result = null
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, (service.screenH * 0.55f).toInt().coerceAtLeast(dp(360)), type,
            // بدون این پرچم، پنل همه لمسها را میگیرد و بازی زیر آن قفل میشود
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.BOTTOM }
        if (safeAdd(v, lp)) {
            result = v
            v.translationY = dp(300).toFloat(); v.animate().translationY(0f).setDuration(220).start()
        }
    }

    private fun hideFrame() {
        remove(sizeDialog); sizeDialog = null
        remove(frame); frame = null
        remove(toolbar); toolbar = null
    }

    fun dismissAll() {
        hideFrame()
        listOfNotNull(bubble, result).forEach { runCatching { wm.removeView(it) } }
        bubble = null; result = null
    }
}

