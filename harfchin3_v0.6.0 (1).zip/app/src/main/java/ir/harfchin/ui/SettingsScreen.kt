package ir.harfchin.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Build
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Face
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ir.harfchin.core.model.MultiplierMode
import ir.harfchin.pipeline.AppSettings
import ir.harfchin.pipeline.ScanPipeline
import ir.harfchin.pipeline.UiState

@Composable
fun SettingsScreen(pipeline: ScanPipeline, state: UiState) {
    val s = state.settings
    var confirmClear by remember { mutableStateOf(false) }
    var profileText by remember(s.profile) { mutableStateOf(s.profile) }
    var values by remember(s.letterValuesText) { mutableStateOf(s.letterValuesText) }

    Column(
        Modifier.fillMaxSize().imePadding().verticalScroll(rememberScrollState()).padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        SectionCard("کلمات", Icons.Rounded.Star, Sun) {
            CommitSlider(s.minLength.toFloat(), 2f..6f, Sun, steps = 3, label = { "حداقل طول کلمه: ${it.toInt()} حرف" }) { v ->
                pipeline.updateSettings { it.copy(minLength = v.toInt()) }
            }
        }

        SectionCard("امتیاز", Icons.Rounded.Star, Coral) {
            ModeOption("جمع امتیاز کاشیها", "مثل «بازم بازی»: قانع = ۶", s.multiplierMode == MultiplierMode.LETTER, Coral) {
                pipeline.updateSettings { it.copy(multiplierMode = MultiplierMode.LETTER) }
            }
            ModeOption("ضرب در کل کلمه", "عدد گوشه کل کلمه را چند برابر میکند", s.multiplierMode == MultiplierMode.WORD, Coral) {
                pipeline.updateSettings { it.copy(multiplierMode = MultiplierMode.WORD) }
            }
            OutlinedTextField(values, { values = it }, Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp),
                label = { Text("امتیاز حروف (مثال: ا=1، ژ=5)") },
                supportingText = { Text("خالی = هر حرف ۱ امتیاز") })
            Button(onClick = { pipeline.updateSettings { it.copy(letterValuesText = values) } },
                enabled = values != s.letterValuesText, shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Coral), modifier = Modifier.fillMaxWidth()) { Text("ثبت امتیاز حروف") }
        }

        SectionCard("پروفایل بازی", Icons.Rounded.Face, Grape) {
            OutlinedTextField(profileText, { profileText = it }, Modifier.fillMaxWidth(), singleLine = true,
                shape = RoundedCornerShape(14.dp), label = { Text("نام پروفایل") },
                supportingText = { Text("فعال: ${s.profile} — نمونههای یادگرفته و کادر شناور برای هر پروفایل جدا ذخیره میشوند") })
            Button(onClick = { pipeline.applyProfile(profileText) },
                enabled = profileText.isNotBlank() && profileText.trim() != s.profile, shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Grape), modifier = Modifier.fillMaxWidth()) { Text("ثبت پروفایل") }
        }

        SectionCard("تشخیص حروف (OCR)", Icons.Rounded.Build, Sky) {
            CommitSlider(s.contrast, 0.5f..2.5f, Sky, label = { "کنتراست: ${"%.1f".format(it)}" }) { v -> pipeline.updateSettings { it.copy(contrast = v) } }
            CommitSlider(s.sharpen, 0f..1.5f, Sky, label = { "وضوح: ${"%.1f".format(it)}" }) { v -> pipeline.updateSettings { it.copy(sharpen = v) } }
            CommitSlider(s.thresholdBias.toFloat(), -40f..40f, Sky, label = { "جابهجایی آستانه: ${it.toInt()}" }) { v -> pipeline.updateSettings { it.copy(thresholdBias = v.toInt()) } }
            CommitSlider(s.minConfidence, 0.4f..0.95f, Sky, label = { "حداقل اطمینان: ${(it * 100).toInt()}٪" }) { v -> pipeline.updateSettings { it.copy(minConfidence = v) } }
            TextButton(onClick = {
                val d = AppSettings()
                pipeline.updateSettings { it.copy(contrast = d.contrast, sharpen = d.sharpen, thresholdBias = d.thresholdBias, minConfidence = d.minConfidence) }
            }) {
                Icon(Icons.Rounded.Refresh, null, tint = Sky); Spacer(Modifier.width(6.dp)); Text("بازگشت به پیشفرض", color = Sky)
            }
        }

        OutlinedButton(
            onClick = { confirmClear = true }, modifier = Modifier.fillMaxWidth().height(50.dp), shape = RoundedCornerShape(14.dp),
            border = androidx.compose.foundation.BorderStroke(1.5.dp, Coral),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = Coral)
        ) {
            Icon(Icons.Rounded.Delete, null); Spacer(Modifier.width(6.dp)); Text("پاک کردن نمونههای یادگرفته این پروفایل")
        }
        Text("حرفچین ${ir.harfchin.BuildConfig.VERSION_NAME}", fontSize = 12.sp, color = Hc.c.sub,
            modifier = Modifier.align(Alignment.CenterHorizontally).padding(8.dp))
    }

    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            shape = RoundedCornerShape(24.dp),
            icon = { IconBadge(Icons.Rounded.Delete, Coral, 48.dp) },
            title = { Text("پاک کردن نمونهها") },
            text = { Text("همه حروفی که برنامه از اصلاحات شما در پروفایل «${s.profile}» یاد گرفته پاک میشوند. این کار قابل بازگشت نیست.") },
            confirmButton = {
                Button(onClick = { pipeline.clearUserSamples(); confirmClear = false },
                    colors = ButtonDefaults.buttonColors(containerColor = Coral)) { Text("پاک کن") }
            },
            dismissButton = { TextButton(onClick = { confirmClear = false }) { Text("انصراف") } }
        )
    }
}

@Composable
private fun ModeOption(title: String, hint: String, selected: Boolean, color: Color, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
            .background(if (selected) color.copy(alpha = 0.12f) else Color.Transparent)
            .border(1.5.dp, if (selected) color else Hc.c.divider, RoundedCornerShape(14.dp))
            .clickable(onClick = onClick).padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RadioButton(selected, onClick, colors = RadioButtonDefaults.colors(selectedColor = color))
        Column {
            Text(title, fontWeight = FontWeight.Bold, color = Hc.c.ink)
            Text(hint, fontSize = 12.sp, color = Hc.c.sub)
        }
    }
}

/** اسلایدری که هنگام کشیدن فقط مقدار محلی را تغییر میدهد و در پایان ذخیره میکند. */
@Composable
private fun CommitSlider(
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    color: Color,
    steps: Int = 0,
    label: (Float) -> String,
    onCommit: (Float) -> Unit
) {
    var local by remember(value) { mutableFloatStateOf(value) }
    Column {
        Text(label(local), color = Hc.c.ink, fontSize = 14.sp)
        Slider(value = local, onValueChange = { local = it }, valueRange = range, steps = steps,
            onValueChangeFinished = { onCommit(local) },
            colors = SliderDefaults.colors(thumbColor = color, activeTrackColor = color, inactiveTrackColor = color.copy(alpha = 0.2f)))
    }
}
