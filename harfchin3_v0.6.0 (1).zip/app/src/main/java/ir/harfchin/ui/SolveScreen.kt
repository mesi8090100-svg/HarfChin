package ir.harfchin.ui

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Clear
import androidx.compose.material.icons.rounded.Create
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.DialogProperties
import ir.harfchin.core.PersianNormalizer
import ir.harfchin.core.model.FoundWord
import ir.harfchin.pipeline.ScanPipeline
import ir.harfchin.pipeline.UiState

/**
 * صفحه اسکن و حل — کل صفحه یک LazyColumn است تا روی گوشی کوچک و با کیبورد باز هم همه چیز در دسترس باشد.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SolveScreen(pipeline: ScanPipeline, state: UiState, onStartOverlay: () -> Unit, overlayGranted: Boolean) {
    var editIndex by remember { mutableStateOf<Int?>(null) }
    var manual by rememberSaveable { mutableStateOf("") }
    var filter by rememberSaveable { mutableStateOf("") }
    var byLength by rememberSaveable { mutableStateOf(true) }
    var lenFilter by rememberSaveable { mutableIntStateOf(0) }   // 0 = همه
    val focus = LocalFocusManager.current
    val narrow = LocalConfiguration.current.screenWidthDp < 360
    val counts = remember(state.words) { state.words.groupingBy { it.word.length }.eachCount().toSortedMap(reverseOrder()) }
    val shown = remember(state.words, filter, byLength, lenFilter) {
        val f = PersianNormalizer.normalize(filter)
        state.words.filter { (f.isBlank() || it.word.contains(f)) && (lenFilter == 0 || it.word.length == lenFilter) }
            .sortedWith(
                if (byLength) compareByDescending<FoundWord> { it.word.length }.thenByDescending { it.score }.thenBy { it.word }
                else compareByDescending<FoundWord> { it.score }.thenByDescending { it.word.length }.thenBy { it.word }
            )
    }
    val unsure = state.grid.tiles.count { it.needsReview }
    val manualCount = remember(manual) { PersianNormalizer.normalize(manual).count { it in PersianNormalizer.ALPHABET } }

    LazyColumn(
        Modifier.fillMaxSize().background(Hc.c.bg).imePadding(),
        contentPadding = PaddingValues(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item(key = "scan") {
            GradientButton(
                if (overlayGranted) "اسکن روی بازی" else "اسکن (اول اجازه نمایش روی برنامهها)",
                ScanBrush, Modifier.fillMaxWidth(), icon = Icons.Rounded.PlayArrow, height = 58.dp, onClick = onStartOverlay
            )
        }
        item(key = "board") {
            Card(
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = Hc.c.board),
                elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
            ) {
                Column(Modifier.fillMaxWidth().padding(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    GridBoard(state, state.selectedWord, onTileClick = { editIndex = it },
                        modifier = Modifier.fillMaxWidth(if (narrow) 1f else 0.86f))
                    Spacer(Modifier.height(10.dp))
                    val sel = state.selectedWord
                    if (sel != null) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text(sel.word, color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
                            Pill("${sel.score} امتیاز", Sun)
                            IconButton(onClick = { pipeline.select(null) }) {
                                Icon(Icons.Rounded.Clear, "لغو انتخاب", tint = Color.White.copy(alpha = 0.8f))
                            }
                        }
                    } else if (state.grid.tiles.all { it.letter.isEmpty() }) {
                        Text("اسکن کنید یا ۱۶ حرف را پایین تایپ کنید", color = Color.White.copy(alpha = 0.75f), fontSize = 13.sp)
                    } else {
                        Text("برای اصلاح، روی هر خانه بزنید", color = Color.White.copy(alpha = 0.75f), fontSize = 13.sp)
                    }
                }
            }
        }
        if (unsure > 0) item(key = "unsure") {
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Sun.copy(alpha = 0.2f)).padding(12.dp),
                verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Icon(Icons.Rounded.Warning, null, tint = Color(0xFFB7791F))
                Text("$unsure خانه زرد است؛ رویش بزنید و حرف درست را انتخاب کنید.", color = Hc.c.ink, fontSize = 14.sp)
            }
        }
        item(key = "actions") {
            GradientButton(
                if (state.busy) "در حال پیدا کردن…" else "پیدا کردن کلمهها",
                SolveBrush, Modifier.fillMaxWidth(), icon = Icons.Rounded.Search, enabled = !state.busy,
                onClick = pipeline::solve
            )
            if (state.busy) LinearProgressIndicator(
                Modifier.fillMaxWidth().padding(top = 8.dp).clip(CircleShape), color = Mint, trackColor = Mint.copy(alpha = 0.2f)
            )
        }
        item(key = "manual") {
            SectionCard("ورود دستی", Icons.Rounded.Create, Grape) {
                OutlinedTextField(
                    manual, { manual = it }, Modifier.fillMaxWidth(), singleLine = true,
                    label = { Text("۱۶ حرف، ردیف به ردیف، هر ردیف از راست به چپ") },
                    supportingText = { Text("$manualCount از ۱۶", color = if (manualCount == 16) Mint else Hc.c.sub) },
                    trailingIcon = {
                        if (manual.isNotEmpty()) IconButton(onClick = { manual = "" }) { Icon(Icons.Rounded.Clear, "پاک کردن") }
                    },
                    shape = RoundedCornerShape(14.dp),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                    keyboardActions = KeyboardActions(onDone = { focus.clearFocus(); pipeline.setGridText(manual) })
                )
                GradientButton("ثبت جدول", AddBrush, Modifier.fillMaxWidth(), icon = Icons.Rounded.Check,
                    enabled = manualCount == 16, height = 46.dp) { focus.clearFocus(); pipeline.setGridText(manual) }
            }
        }
        if (state.words.isNotEmpty()) {
            item(key = "summary") {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        IconBadge(Icons.Rounded.Star, Sun, 34.dp, solid = true)
                        Text("${state.words.size} کلمه پیدا شد", fontSize = 19.sp, fontWeight = FontWeight.ExtraBold, color = Hc.c.ink)
                    }
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        ColorChip("همه", lenFilter == 0, Plum) { lenFilter = 0 }
                        counts.forEach { (len, n) ->
                            ColorChip("$len حرفی · $n", lenFilter == len, lengthColor(len)) { lenFilter = if (lenFilter == len) 0 else len }
                        }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        ColorChip("بلندترین", byLength, Coral) { byLength = true }
                        ColorChip("پرامتیازترین", !byLength, Sun) { byLength = false }
                    }
                    OutlinedTextField(
                        filter, { filter = it }, Modifier.fillMaxWidth(), singleLine = true,
                        placeholder = { Text("جستجو در کلمهها") },
                        leadingIcon = { Icon(Icons.Rounded.Search, null, tint = Sky) },
                        trailingIcon = { if (filter.isNotEmpty()) IconButton(onClick = { filter = "" }) { Icon(Icons.Rounded.Clear, "پاک کردن") } },
                        shape = RoundedCornerShape(14.dp)
                    )
                }
            }
            if (shown.isEmpty()) item(key = "noresult") {
                EmptyState(Icons.Rounded.Search, Sky, "چیزی پیدا نشد", "فیلتر یا متن جستجو را تغییر دهید")
            }
        }
        items(shown, key = { "w_" + it.word }) { w -> WordRow(w, w == state.selectedWord) { pipeline.select(if (w == state.selectedWord) null else w) } }
    }

    editIndex?.let { i ->
        TileEditDialog(state, i, onDismiss = { editIndex = null }) { letter, mul ->
            pipeline.setTile(i, letter, mul); editIndex = null
        }
    }
}

@Composable
private fun ColorChip(text: String, selected: Boolean, color: Color, onClick: () -> Unit) {
    val bg by animateColorAsState(if (selected) color else color.copy(alpha = 0.14f), label = "chip")
    Box(
        Modifier.clip(CircleShape).background(bg).clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 8.dp)
    ) { Text(text, color = if (selected) Color.White else color, fontSize = 14.sp, fontWeight = FontWeight.Bold) }
}

/** جدول ۴×۴ — همیشه چپبهراست تا با تصویر بازی یکی باشد؛ مسیر کلمه انتخابی با خط رسم میشود. */
@Composable
fun GridBoard(state: UiState, selected: FoundWord?, onTileClick: (Int) -> Unit, modifier: Modifier = Modifier) {
    val c = Hc.c
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Box(modifier.aspectRatio(1f)) {
            Column(Modifier.fillMaxSize()) {
                for (r in 0 until 4) Row(Modifier.weight(1f)) {
                    for (col in 0 until 4) {
                        val i = r * 4 + col
                        val t = state.grid.tiles[i]
                        val order = selected?.path?.indexOf(i) ?: -1
                        val target = when { order == 0 -> c.pathStart; order > 0 -> c.path; t.needsReview -> c.unsure; else -> c.tile }
                        val bg by animateColorAsState(target, label = "tile")
                        val fg = if (order >= 0) Color.White else c.tileInk
                        Box(
                            Modifier.weight(1f).fillMaxHeight().padding(4.dp)
                                .shadow(3.dp, RoundedCornerShape(14.dp))
                                .background(c.tileEdge, RoundedCornerShape(14.dp))
                                .padding(bottom = 4.dp)
                                .background(bg, RoundedCornerShape(14.dp))
                                .clip(RoundedCornerShape(14.dp))
                                .clickable { onTileClick(i) },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(t.letter.ifEmpty { "؟" }, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold, color = fg,
                                fontFamily = Vazir)
                            if (t.multiplier > 1) Box(
                                Modifier.align(Alignment.TopEnd).padding(4.dp).size(18.dp).clip(CircleShape)
                                    .background(if (t.multiplier >= 3) Berry else Coral),
                                contentAlignment = Alignment.Center
                            ) { Text("${t.multiplier}", fontSize = 11.sp, color = Color.White, fontWeight = FontWeight.Bold) }
                            if (order >= 0) Text("${order + 1}", fontSize = 11.sp, fontWeight = FontWeight.Bold,
                                modifier = Modifier.align(Alignment.BottomStart).padding(4.dp), color = Color.White)
                        }
                    }
                }
            }
            selected?.let { w ->
                Canvas(Modifier.fillMaxSize()) {
                    val cell = size.width / 4
                    fun center(i: Int) = Offset((i % 4 + 0.5f) * cell, (i / 4 + 0.5f) * cell)
                    w.path.zipWithNext().forEach { (a, b) ->
                        drawLine(Color(0xAA1B5E20), center(a), center(b), strokeWidth = cell * 0.12f, cap = StrokeCap.Round)
                    }
                    w.path.firstOrNull()?.let { drawCircle(Color(0xFF1B5E20), cell * 0.09f, center(it)) }
                }
            }
        }
    }
}

@Composable
private fun WordRow(w: FoundWord, selected: Boolean, onClick: () -> Unit) {
    val lc = lengthColor(w.word.length)
    Card(
        onClick = onClick,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = if (selected) lc.copy(alpha = 0.18f) else Hc.c.surface),
        border = if (selected) androidx.compose.foundation.BorderStroke(2.dp, lc) else null,
        elevation = CardDefaults.cardElevation(defaultElevation = if (Hc.c.dark) 0.dp else 1.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(Modifier.height(IntrinsicSize.Min), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.width(6.dp).fillMaxHeight().background(lc))
            Row(Modifier.padding(horizontal = 14.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(w.word, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Hc.c.ink, modifier = Modifier.weight(1f))
                if (w.usesUncertainTile) Icon(Icons.Rounded.Warning, "خانه نامطمئن", tint = Color(0xFFE0A100),
                    modifier = Modifier.padding(horizontal = 4.dp).size(18.dp))
                Pill("${w.word.length} حرف", lc, solid = false)
                Spacer(Modifier.width(8.dp))
                Pill("${w.score}", Plum)
            }
        }
    }
}

/** دیالوگ اصلاح خانه — اسکرولشونده و حداکثر ۷۵٪ ارتفاع صفحه */
@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun TileEditDialog(state: UiState, index: Int, onDismiss: () -> Unit, onPick: (String, Int) -> Unit) {
    val t = state.grid.tiles[index]
    var mul by remember { mutableIntStateOf(t.multiplier) }
    val maxH = (LocalConfiguration.current.screenHeightDp * 0.75f).dp
    AlertDialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false),
        modifier = Modifier.fillMaxWidth(0.94f).heightIn(max = maxH),
        shape = RoundedCornerShape(24.dp),
        containerColor = Hc.c.surface,
        confirmButton = { TextButton(onClick = { onPick(t.letter, mul) }, enabled = t.letter.isNotEmpty()) { Text("فقط امتیاز") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } },
        title = {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                IconBadge(Icons.Rounded.Create, Grape, 36.dp)
                Column {
                    Text("خانه ${index + 1}", fontWeight = FontWeight.Bold)
                    if (t.confidence < 1f) Text("اطمینان ${(t.confidence * 100).toInt()}٪", fontSize = 12.sp, color = Hc.c.sub)
                }
            }
        },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                if (t.alternatives.isNotEmpty()) {
                    Text("پیشنهاد OCR", fontSize = 13.sp, color = Hc.c.sub)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        t.alternatives.forEachIndexed { k, l ->
                            val col = listOf(Mint, Sky, Grape, Berry)[k % 4]
                            Box(
                                Modifier.size(52.dp).clip(RoundedCornerShape(14.dp)).background(col).clickable { onPick(l, mul) },
                                contentAlignment = Alignment.Center
                            ) { Text(l, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold, color = Color.White) }
                        }
                    }
                }
                Text("امتیاز خانه", fontSize = 13.sp, color = Hc.c.sub)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(1 to Sky, 2 to Coral, 3 to Berry).forEach { (m, col) -> ColorChip("$m", mul == m, col) { mul = m } }
                }
                Text("همه حروف", fontSize = 13.sp, color = Hc.c.sub)
                FlowRow {
                    PersianNormalizer.TILE_LETTERS.forEach { l ->
                        val cur = l == t.letter
                        Box(
                            Modifier.padding(2.dp).size(44.dp).clip(RoundedCornerShape(12.dp))
                                .background(if (cur) Plum else Hc.c.tile)
                                .border(1.dp, Hc.c.tileEdge, RoundedCornerShape(12.dp))
                                .clickable { onPick(l, mul) },
                            contentAlignment = Alignment.Center
                        ) { Text(l, fontSize = 19.sp, fontWeight = FontWeight.Bold, color = if (cur) Color.White else Hc.c.tileInk) }
                    }
                }
            }
        }
    )
}
