package ir.harfchin.ui

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.List
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ir.harfchin.dictionary.DictionaryInfo
import ir.harfchin.dictionary.OnlineDictionaries
import ir.harfchin.dictionary.OnlineSource
import ir.harfchin.pipeline.ScanPipeline
import ir.harfchin.pipeline.UiState

/** مدیریت فرهنگ لغت — فقط فایلهایی که کاربر خودش انتخاب میکند وارد میشوند. */
@Composable
fun DictionaryScreen(pipeline: ScanPipeline, state: UiState) {
    val ctx = LocalContext.current
    var toDelete by remember { mutableStateOf<DictionaryInfo?>(null) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris: List<Uri> ->
        pipeline.importUris(ctx.contentResolver, uris)
    }
    val importing = state.importing
    val active = state.dictionaries.filter { it.enabled }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatCard("فرهنگ", "${state.dictionaries.size}", Sky, Modifier.weight(1f))
                StatCard("فعال", "${active.size}", Mint, Modifier.weight(1f))
                StatCard("کلمه", formatCount(active.sumOf { it.wordCount }), Coral, Modifier.weight(1f))
            }
        }
        item {
            Text("فرهنگ لغت آنلاین", fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, color = Hc.c.ink,
                modifier = Modifier.padding(top = 4.dp))
            Text("هرچه کلمه بیشتر، امتیاز بالاتر. فقط وقتی «دانلود» را بزنید به اینترنت وصل میشود.",
                fontSize = 12.sp, color = Hc.c.sub)
        }
        items(OnlineDictionaries.SOURCES, key = { "online_" + it.id }) { src ->
            val installed = state.dictionaries.firstOrNull { it.sourceId == src.id }
            OnlineCard(src, installed, enabled = importing == null) { pipeline.downloadOnline(src) }
        }
        item {
            Text("فایل خودتان", fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, color = Hc.c.ink,
                modifier = Modifier.padding(top = 8.dp))
        }
        item {
            GradientButton("افزودن فرهنگ لغت از گوشی", AddBrush, Modifier.fillMaxWidth(), icon = Icons.Rounded.Add,
                enabled = importing == null) {
                picker.launch(arrayOf("text/*", "application/json", "text/csv", "application/octet-stream"))
            }
        }
        item {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Icon(Icons.Rounded.Lock, null, tint = Mint, modifier = Modifier.size(16.dp))
                Text("TXT / CSV / JSON — چند فایل همزمان", fontSize = 12.sp, color = Hc.c.sub)
            }
        }
        if (importing != null) item {
            Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Sky.copy(alpha = 0.15f))) {
                Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (importing.total > 1) Text("در حال وارد کردن ${importing.done + 1} از ${importing.total}", fontWeight = FontWeight.Bold, color = Hc.c.ink)
                    Text(importing.current, fontSize = if (importing.total > 1) 12.sp else 15.sp,
                        fontWeight = if (importing.total > 1) FontWeight.Normal else FontWeight.Bold,
                        color = if (importing.total > 1) Hc.c.sub else Hc.c.ink, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    val mod = Modifier.fillMaxWidth().clip(CircleShape)
                    val fr = importing.fraction
                    if (fr != null) {
                        LinearProgressIndicator(progress = { fr }, modifier = mod, color = Sky, trackColor = Sky.copy(alpha = 0.2f))
                        Text("${(fr * 100).toInt()}٪", fontSize = 12.sp, color = Sky, fontWeight = FontWeight.Bold)
                    } else if (importing.total > 1) LinearProgressIndicator(progress = { importing.done.toFloat() / importing.total },
                        modifier = mod, color = Sky, trackColor = Sky.copy(alpha = 0.2f))
                    else LinearProgressIndicator(mod, color = Sky, trackColor = Sky.copy(alpha = 0.2f))
                }
            }
        }
        if (state.dictionaries.isEmpty() && importing == null) item {
            EmptyState(Icons.Rounded.List, Mint, "هنوز فرهنگ لغتی نیست", "یک فایل کلمات فارسی اضافه کنید")
        }
        items(state.dictionaries, key = { it.id }) { d ->
            val tint = if (d.builtIn) Sun else listOf(Sky, Mint, Grape, Coral, Berry)[(d.id.hashCode() and 0x7fffffff) % 5]
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = Hc.c.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = if (Hc.c.dark) 0.dp else 1.dp)
            ) {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    IconBadge(if (d.builtIn) Icons.Rounded.Star else Icons.Rounded.List, tint, 42.dp, solid = d.enabled)
                    Column(Modifier.weight(1f)) {
                        Text(d.name, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Hc.c.ink,
                            maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text("${formatCount(d.wordCount)} کلمه · ${formatSize(d.sizeBytes)}" + if (d.builtIn) " · پیشفرض" else "",
                            fontSize = 12.sp, color = Hc.c.sub)
                    }
                    Switch(d.enabled, { pipeline.toggleDictionary(d.id, it) }, enabled = importing == null,
                        colors = SwitchDefaults.colors(checkedTrackColor = Mint, checkedThumbColor = Color.White))
                    IconButton(onClick = { toDelete = d }, enabled = importing == null) {
                        Icon(Icons.Rounded.Delete, "حذف", tint = Coral)
                    }
                }
            }
        }
    }
    toDelete?.let { d ->
        AlertDialog(
            onDismissRequest = { toDelete = null },
            shape = RoundedCornerShape(24.dp),
            icon = { IconBadge(Icons.Rounded.Delete, Coral, 48.dp) },
            title = { Text("حذف فرهنگ لغت") },
            text = { Text("«${d.name}» برای همیشه حذف شود؟") },
            confirmButton = {
                Button(onClick = { pipeline.deleteDictionary(d.id); toDelete = null },
                    colors = ButtonDefaults.buttonColors(containerColor = Coral)) { Text("حذف") }
            },
            dismissButton = { TextButton(onClick = { toDelete = null }) { Text("انصراف") } }
        )
    }
}

@Composable
private fun OnlineCard(src: OnlineSource, installed: DictionaryInfo?, enabled: Boolean, onDownload: () -> Unit) {
    val tint = when (src.id) { "dehkhoda" -> Berry; "upc" -> Grape; else -> Sky }
    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = tint.copy(alpha = if (Hc.c.dark) 0.18f else 0.10f)),
        border = if (src.id == "dehkhoda" && installed == null) androidx.compose.foundation.BorderStroke(1.5.dp, tint) else null
    ) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            IconBadge(if (installed != null) Icons.Rounded.Check else Icons.Rounded.KeyboardArrowDown, tint, 42.dp, solid = true)
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(src.title, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Hc.c.ink)
                    if (src.id == "dehkhoda") Pill("پیشنهادی", tint)
                }
                Text(src.description, fontSize = 12.sp, color = Hc.c.sub)
                Text(
                    if (installed != null) "نصب شده · ${formatCount(installed.wordCount)} کلمه"
                    else "حدود ${formatCount(src.approxWords)} کلمه · ${"%.1f".format(src.approxSizeMb)} مگابایت",
                    fontSize = 12.sp, color = tint, fontWeight = FontWeight.Bold
                )
            }
            Button(
                onClick = onDownload, enabled = enabled, shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = tint),
                contentPadding = PaddingValues(horizontal = 12.dp)
            ) {
                Icon(if (installed != null) Icons.Rounded.Refresh else Icons.Rounded.KeyboardArrowDown, null, Modifier.size(18.dp))
                Spacer(Modifier.width(4.dp))
                Text(if (installed != null) "بهروزرسانی" else "دانلود")
            }
        }
    }
}

@Composable
private fun StatCard(label: String, value: String, color: Color, modifier: Modifier) {
    Card(modifier, shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = color.copy(alpha = 0.15f))) {
        Column(Modifier.fillMaxWidth().padding(vertical = 12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(value, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, color = color)
            Text(label, fontSize = 12.sp, color = Hc.c.sub)
        }
    }
}

fun formatCount(n: Int): String = "%,d".format(n).replace(',', '٬')

fun formatSize(b: Long) = when {
    b >= 1_048_576 -> "%.1f مگابایت".format(b / 1_048_576.0)
    b >= 1024 -> "${b / 1024} کیلوبایت"
    else -> "$b بایت"
}
