package ir.harfchin.dictionary

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class MyDictionaryTest {
    private fun read(): Set<String> {
        val f = listOf("src/main/assets/dictionaries/my_fa.txt", "app/src/main/assets/dictionaries/my_fa.txt").map(::File).first { it.exists() }
        return DictionaryParser.parse(f.readText(), DictFormat.TXT)
    }

    @Test fun keepsNounsAndCompounds() {
        val w = read()
        listOf("آب", "یخ", "کتاب", "باورنکردنی", "کاروانسرا", "پاکوب", "جنزده", "روزنامهها", "پزشکان", "قانع", "مخلف").forEach { assertTrue(it, it in w) }
    }

    @Test fun noVerbsComparativesOrForeignNames() {
        val w = read()
        listOf("گفتند", "خوردند", "بجنگد", "میشنوی", "نمیبخشید", "زشتترین", "راستتر", "فلوید", "لیسبون").forEach { assertFalse(it, it in w) }
    }
}
