package ir.harfchin.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

/** امضای سازنده */
const val CREATOR = "me.kinG.si"

private val Gold = Color(0xFFFFD36E)
private val GoldDeep = Color(0xFFE0A030)
private val Night = Color(0xFF07050C)

private data class Ember(val x: Float, val y: Float, val r: Float, val speed: Float, val phase: Float)
private data class Shard(val angle: Float, val dist: Float, val len: Float)

/**
 * تیتراژ سینمایی (حدود ۴٫۵ ثانیه، با لمس رد میشود):
 *  ۱. صفحه سیاه؛ نوارهای سینمایی بالا و پایین وارد میشوند
 *  ۲. یک خط نور آنامورفیک از وسط صفحه باز میشود
 *  ۳. حروف me.kinG.si یکییکی از بزرگی به جای خود «میکوبند»؛ هر ضربه صفحه را میلرزاند
 *  ۴. موج نور و ترکش طلایی از پشت اسم؛ لنزفلر از روی اسم رد میشود
 *  ۵. «ساخته شده توسط» با فاصله حروف باز که جمع میشود؛ تاج میافتد
 *  ۶. حرکت آرام دوربین به جلو، سپس فلش سفید و خروج
 */
@Composable
fun SplashScreen(onDone: () -> Unit) {
    var finished by remember { mutableStateOf(false) }
    fun finish() { if (!finished) { finished = true; onDone() } }

    val embers = remember { List(40) { Ember(Random.nextFloat(), Random.nextFloat(), 1f + Random.nextFloat() * 2.5f,
        0.15f + Random.nextFloat() * 0.35f, Random.nextFloat() * 6.28f) } }
    val shards = remember { List(28) { Shard(it * (2f * PI.toFloat() / 28f) + Random.nextFloat() * 0.15f,
        0.6f + Random.nextFloat() * 0.5f, 14f + Random.nextFloat() * 26f) } }

    val bars = remember { Animatable(0f) }
    val streak = remember { Animatable(0f) }
    val hits = remember { CREATOR.map { Animatable(0f) } }
    val shake = remember { Animatable(0f) }
    val wave = remember { Animatable(0f) }
    val flare = remember { Animatable(-0.4f) }
    val sub = remember { Animatable(0f) }
    val crown = remember { Animatable(0f) }
    val push = remember { Animatable(1f) }
    val flash = remember { Animatable(0f) }
    val out = remember { Animatable(1f) }

    val loop = rememberInfiniteTransition(label = "loop")
    val t by loop.animateFloat(0f, 1f, infiniteRepeatable(tween(7000, easing = LinearEasing)), label = "t")
    val glow by loop.animateFloat(0.55f, 1f, infiniteRepeatable(tween(1100, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "g")

    LaunchedEffect(Unit) {
        bars.animateTo(1f, tween(450, easing = FastOutSlowInEasing))
        streak.animateTo(1f, tween(550, easing = FastOutSlowInEasing))
        hits.forEachIndexed { i, a ->
            launch {
                delay(i * 70L)
                a.animateTo(1f, tween(260, easing = CubicBezierEasing(0.2f, 0f, 0f, 1f)))
                if (CREATOR[i] != '.') {      // ضربه: لرزش کوتاه دوربین
                    shake.snapTo(if (i % 2 == 0) 1f else -1f)
                    shake.animateTo(0f, spring(dampingRatio = 0.3f, stiffness = 900f))
                }
            }
        }
        delay(CREATOR.length * 70L + 260)
        launch { wave.animateTo(1f, tween(900, easing = LinearOutSlowInEasing)) }
        launch { flare.animateTo(1.4f, tween(900, easing = FastOutSlowInEasing)) }
        delay(250)
        launch { sub.animateTo(1f, tween(700, easing = FastOutSlowInEasing)) }
        delay(350)
        crown.animateTo(1f, spring(dampingRatio = 0.45f, stiffness = 220f))
        push.animateTo(1.07f, tween(1100, easing = LinearEasing))
        flash.animateTo(1f, tween(140))
        out.snapTo(0f)
        flash.animateTo(0f, tween(260))
        finish()
    }

    Box(
        Modifier.fillMaxSize()
            .clickable(remember { MutableInteractionSource() }, indication = null) { finish() },
        contentAlignment = Alignment.Center
    ) {
        // پسزمینه: سیاه با نور بنفش ملایم و ذرات خاکستر طلایی
        Canvas(Modifier.fillMaxSize()) {
            drawRect(Night)
            drawRect(Brush.radialGradient(listOf(Grape.copy(alpha = 0.35f * streak.value), Color.Transparent),
                center = center, radius = size.maxDimension * 0.7f))
            val a = t * 2f * PI.toFloat()
            embers.forEach { e ->
                val y = ((e.y - t * e.speed * 2f) % 1f + 1f) % 1f
                val tw = 0.3f + 0.7f * ((sin(a * 4 + e.phase) + 1f) / 2f)
                val c = Offset(e.x * size.width + 14f * sin(a + e.phase), y * size.height)
                drawCircle(Gold.copy(alpha = 0.10f * tw * streak.value), e.r * 5f, c)
                drawCircle(Gold.copy(alpha = 0.7f * tw * streak.value), e.r, c)
            }
            // خط نور آنامورفیک
            val sw = size.width * streak.value
            drawRect(Brush.horizontalGradient(listOf(Color.Transparent, Sky.copy(alpha = 0.55f), Color.White, Sky.copy(alpha = 0.55f), Color.Transparent),
                startX = center.x - sw / 2, endX = center.x + sw / 2),
                Offset(center.x - sw / 2, center.y - 1.5f), Size(sw, 3f))
            drawRect(Brush.horizontalGradient(listOf(Color.Transparent, Grape.copy(alpha = 0.25f), Color.Transparent),
                startX = center.x - sw / 2, endX = center.x + sw / 2),
                Offset(center.x - sw / 2, center.y - 22f), Size(sw, 44f))
            // موج نور و ترکش طلایی
            if (wave.value > 0f && wave.value < 1f) {
                val w = wave.value
                drawCircle(Gold.copy(alpha = 0.45f * (1f - w)), size.minDimension * 0.75f * w, center,
                    style = androidx.compose.ui.graphics.drawscope.Stroke(width = 6f * (1f - w) + 1f))
                shards.forEach { s ->
                    val d0 = s.dist * size.minDimension * 0.55f * w
                    val p0 = Offset(center.x + cos(s.angle) * d0, center.y + sin(s.angle) * d0)
                    val p1 = Offset(p0.x + cos(s.angle) * s.len, p0.y + sin(s.angle) * s.len)
                    drawLine(Gold.copy(alpha = 1f - w), p0, p1, strokeWidth = 3f)
                }
            }
        }

        // صحنه اصلی: لرزش + حرکت دوربین
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.graphicsLayer {
                translationX = shake.value * 10f
                translationY = -shake.value * 4f
                scaleX = push.value; scaleY = push.value
                alpha = out.value
            }
        ) {
            Text(
                "ساخته شده توسط", color = Color.White.copy(alpha = 0.85f), fontSize = 17.sp,
                fontWeight = FontWeight.Bold, fontFamily = Vazir,
                letterSpacing = (8f * (1f - sub.value)).sp,
                modifier = Modifier.graphicsLayer { alpha = sub.value; translationY = (1f - sub.value) * 18f }
            )
            Spacer(Modifier.height(10.dp))

            Box(contentAlignment = Alignment.Center) {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                    Row(verticalAlignment = Alignment.Bottom) {
                        CREATOR.forEachIndexed { i, ch ->
                            val p = hits[i].value
                            val king = ch == 'G'
                            Text(
                                ch.toString(),
                                fontSize = if (king) 58.sp else 48.sp,
                                fontWeight = FontWeight.Black,
                                color = if (king) Gold else Color.White,
                                style = TextStyle(shadow = Shadow(
                                    (if (king) GoldDeep else Gold).copy(alpha = 0.85f * glow), Offset.Zero, 30f * glow)),
                                modifier = Modifier.graphicsLayer {
                                    val s = 1f + (1f - p) * 2.6f
                                    scaleX = s; scaleY = s
                                    alpha = p
                                    translationY = (1f - p) * -40f
                                }
                            )
                        }
                    }
                }
                // لنزفلر که از روی اسم رد میشود
                Canvas(Modifier.matchParentSize()) {
                    val x = flare.value * size.width
                    drawRect(Brush.linearGradient(
                        listOf(Color.Transparent, Color.White.copy(alpha = 0.7f), Color.Transparent),
                        start = Offset(x - 70f, 0f), end = Offset(x + 70f, size.height)))
                    if (flare.value in 0f..1f) {
                        val c = Offset(x, size.height * 0.45f)
                        drawCircle(Brush.radialGradient(listOf(Color.White.copy(alpha = 0.9f), Sky.copy(alpha = 0.25f), Color.Transparent),
                            center = c, radius = 70f), 70f, c)
                    }
                }
            }

            // خط طلایی زیر اسم
            Canvas(Modifier.padding(top = 6.dp).width(250.dp).height(3.dp)) {
                val w = size.width * sub.value
                drawRect(Brush.horizontalGradient(listOf(Color.Transparent, Gold, Color.Transparent),
                    startX = center.x - w / 2, endX = center.x + w / 2),
                    Offset(center.x - w / 2, 0f), Size(w, size.height))
            }
            Text("👑", fontSize = 30.sp, modifier = Modifier.padding(top = 10.dp).graphicsLayer {
                alpha = crown.value.coerceIn(0f, 1f); translationY = (1f - crown.value) * -120f
                rotationZ = (1f - crown.value) * -30f
            })
        }

        // نوارهای سینمایی
        Canvas(Modifier.fillMaxSize()) {
            val h = size.height * 0.11f * bars.value
            drawRect(Color.Black, Offset.Zero, Size(size.width, h))
            drawRect(Color.Black, Offset(0f, size.height - h), Size(size.width, h))
            if (flash.value > 0f) drawRect(Color.White.copy(alpha = flash.value))
        }
    }
}
