package ir.harfchin.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.List
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import ir.harfchin.pipeline.ScanPipeline

private data class TabItem(val title: String, val icon: ImageVector, val color: Color)

@Composable
fun MainScreen(pipeline: ScanPipeline, onStartOverlay: () -> Unit, overlayGranted: Boolean, onSetupFrame: () -> Unit = {}) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val state by pipeline.state.collectAsStateWithLifecycle()
    val snack = remember { SnackbarHostState() }
    LaunchedEffect(state.message) { state.message?.let { snack.showSnackbar(it); pipeline.clearMessage() } }
    val tabs = listOf(
        TabItem("اسکن و حل", Icons.Rounded.Search, Coral),
        TabItem("فرهنگ لغت", Icons.Rounded.List, Mint)
    )
    if (tab >= tabs.size) tab = 0

    Scaffold(
        containerColor = Hc.c.bg,
        topBar = { Header(tabs[tab].title) },
        snackbarHost = {
            SnackbarHost(snack) {
                Snackbar(it, containerColor = Plum, contentColor = Color.White, shape = RoundedCornerShape(14.dp))
            }
        },
        bottomBar = {
            NavigationBar(containerColor = Hc.c.surface, tonalElevation = 0.dp) {
                tabs.forEachIndexed { i, t ->
                    val sel = tab == i
                    NavigationBarItem(
                        selected = sel,
                        onClick = { tab = i },
                        icon = { IconBadge(t.icon, t.color, size = 38.dp, solid = sel) },
                        label = { Text(t.title, fontWeight = if (sel) FontWeight.Bold else FontWeight.Normal) },
                        colors = NavigationBarItemDefaults.colors(
                            indicatorColor = Color.Transparent,
                            selectedTextColor = t.color,
                            unselectedTextColor = Hc.c.sub
                        )
                    )
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) {
                0 -> SolveScreen(pipeline, state, onStartOverlay, overlayGranted, onSetupFrame)
                else -> DictionaryScreen(pipeline, state)
            }
        }
    }
}

/** سرصفحه گرادیان با لوگوی چهار کاشی رنگی */
@Composable
private fun Header(subtitle: String) {
    Box(
        Modifier.fillMaxWidth().background(HeaderBrush).statusBarsPadding()
            .padding(horizontal = 18.dp, vertical = 14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Logo()
            Column {
                Text("حرف‌چین", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
                Text(subtitle, color = Color.White.copy(alpha = 0.8f), fontSize = 13.sp)
            }
        }
    }
}

@Composable
private fun Logo() {
    Column(
        Modifier.size(44.dp).clip(RoundedCornerShape(13.dp)).background(Color.White.copy(alpha = 0.18f)).padding(6.dp),
        verticalArrangement = Arrangement.spacedBy(3.dp)
    ) {
        listOf(listOf(Coral, Sun), listOf(Mint, Sky)).forEach { row ->
            Row(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                row.forEach { c -> Box(Modifier.weight(1f).fillMaxHeight().clip(RoundedCornerShape(4.dp)).background(c)) }
            }
        }
    }
}
