package ir.harfchin.pipeline

import android.content.ContentResolver
import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.provider.OpenableColumns
import ir.harfchin.core.model.FoundWord
import ir.harfchin.core.model.Grid
import ir.harfchin.core.model.MultiplierMode
import ir.harfchin.core.model.Tile
import ir.harfchin.dictionary.DictionaryInfo
import ir.harfchin.dictionary.DictionaryRepository
import ir.harfchin.dictionary.TextDecoding
import ir.harfchin.ocr.BinImage
import ir.harfchin.ocr.GrayImage
import ir.harfchin.ocr.GridRecognizer
import ir.harfchin.ocr.MultiplierReader
import ir.harfchin.ocr.OcrEngine
import ir.harfchin.ocr.Preprocessor
import ir.harfchin.ocr.TemplateClassifier
import ir.harfchin.ocr.TemplateStore
import ir.harfchin.ocr.ZoningClassifier
import ir.harfchin.scanner.FrameProfileStore
import ir.harfchin.solver.Scoring
import ir.harfchin.solver.WordSolver
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.serialization.Serializable
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

/** پیشرفت وارد کردن فرهنگ لغت: done از total تمام شده، current در حال پردازش است */
data class ImportProgress(val done: Int, val total: Int, val current: String, val fraction: Float? = null)

/** وضعیت مشترک بین صفحه اصلی و پنجره شناور */
data class UiState(
    val grid: Grid = Grid.empty(),
    val glyphs: List<BinImage?> = List(16) { null },
    val lastCapture: Bitmap? = null,
    val words: List<FoundWord> = emptyList(),
    val busy: Boolean = false,
    val importing: ImportProgress? = null,
    val message: String? = null,
    val selectedWord: FoundWord? = null,
    val dictionaries: List<DictionaryInfo> = emptyList(),
    val settings: AppSettings = AppSettings()
)

@Serializable
data class AppSettings(
    val minLength: Int = 3,
    val multiplierMode: MultiplierMode = MultiplierMode.LETTER,  // عدد گوشه = امتیاز حرف؛ امتیاز کلمه = جمع
    val letterValuesText: String = "",
    val contrast: Float = 1f,
    val sharpen: Float = 0f,
    val thresholdBias: Int = 0,
    val minConfidence: Float = 0.72f,
    val profile: String = "default"
)

/**
 * هسته برنامه و تنها نقطه اتصال بخشها (DI دستی: یک نمونه در HarfChinApp ساخته میشود).
 * کارهای سنگین روی Dispatchers.Default (پردازش تصویر و حل) یا Dispatchers.IO (فایل) اجرا میشوند.
 */
class ScanPipeline(private val context: Context) {
    val dictionaries = DictionaryRepository(context.filesDir)
    val templates = TemplateStore(context)
    private val frameStore = FrameProfileStore(context)
    private val prefs = context.getSharedPreferences("app", Context.MODE_PRIVATE)
    private val json = Json { ignoreUnknownKeys = true }
    private val engine = OcrEngine(
        listOf(TemplateClassifier(templates::letters), ZoningClassifier(templates::letters)),
        MultiplierReader(templates::digits)
    )
    private val recognizer = GridRecognizer(engine, { templates.bundledReader }, { templates.userSnapshot(templates.activeProfile) })
    /** هر خطای پیشبینینشده در کار پسزمینه به پیام تبدیل میشود، نه بسته شدن برنامه */
    private val errors = CoroutineExceptionHandler { _, e ->
        android.util.Log.e("HarfChin", "background error", e)
        _state.update { it.copy(busy = false, importing = null, message = "خطا: ${e.message ?: e.javaClass.simpleName}") }
    }
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default + errors)
    private var scanJob: Job? = null
    private var solveJob: Job? = null
    private val _state = MutableStateFlow(UiState(settings = loadSettings()))
    val state: StateFlow<UiState> = _state.asStateFlow()

    init {
        // پروفایل تنظیمات و پروفایل کادر شناور همیشه یکی هستند
        frameStore.lastProfile = _state.value.settings.profile
        templates.activeProfile = _state.value.settings.profile
        scope.launch(Dispatchers.IO) { refreshDictionaries() }
    }

    // ---------------- تنظیمات ----------------

    private fun loadSettings(): AppSettings =
        prefs.getString("settings", null)?.let { runCatching { json.decodeFromString<AppSettings>(it) }.getOrNull() }
            ?: AppSettings()

    /** فقط وقتی فراخوانی شود که کاربر تغییر را نهایی کرده (مثلاً onValueChangeFinished اسلایدر) */
    fun updateSettings(f: (AppSettings) -> AppSettings) {
        val next = f(_state.value.settings)
        if (next == _state.value.settings) return
        _state.update { it.copy(settings = next) }
        prefs.edit().putString("settings", json.encodeToString(next)).apply()
    }

    /** اعمال پروفایل فقط با دکمه «ثبت». نام برای استفاده در نام فایل پاکسازی میشود. */
    fun applyProfile(raw: String) {
        val name = raw.trim().replace(Regex("""[^\p{L}\p{N}_\-]"""), "_").take(40).ifBlank { "default" }
        updateSettings { it.copy(profile = name) }
        frameStore.lastProfile = name
        templates.activeProfile = name
        _state.update { it.copy(message = "پروفایل «$name» فعال شد") }
    }

    fun clearUserSamples() {
        val p = _state.value.settings.profile
        scope.launch(Dispatchers.IO) {
            templates.clearUserSamples(p)
            _state.update { it.copy(message = "نمونه‌های یادگرفته پروفایل «$p» پاک شد") }
        }
    }

    // ---------------- فرهنگ لغت ----------------

    /** نصب یکباره فرهنگ لغت پیشفرض همراه برنامه؛ مشخص (builtIn) و قابل غیرفعال/حذف است. */
    fun installBundledDictionaryOnce() {
        if (prefs.getBoolean("bundled_installed", false)) return
        scope.launch(Dispatchers.IO) {
            BundledInstaller.run(
                alreadyInstalled = false,
                install = {
                    val bytes = context.assets.open("dictionaries/common_fa.txt").use { it.readBytes() }
                    dictionaries.importText("کلمات رایج فارسی (پیش‌فرض)", "common_fa.txt", TextDecoding.decode(bytes).text, builtIn = true)
                },
                markInstalled = { prefs.edit().putBoolean("bundled_installed", true).apply() },
                log = { m, e -> android.util.Log.e("HarfChin", m, e) }
            )
            refreshDictionaries()
        }
    }

    private fun refreshDictionaries() {
        val list = dictionaries.list()
        _state.update { it.copy(dictionaries = list) }
    }

    /** وارد کردن فایلهایی که کاربر انتخاب کرده — خواندن، تشخیص کدگذاری و پردازش همه روی IO */
    fun importUris(resolver: ContentResolver, uris: List<Uri>) {
        if (uris.isEmpty() || _state.value.importing != null) return
        scope.launch(Dispatchers.IO) {
            val ok = ArrayList<String>(); val failed = ArrayList<String>()
            uris.forEachIndexed { i, uri ->
                val fileName = displayName(resolver, uri)
                _state.update { it.copy(importing = ImportProgress(i, uris.size, fileName)) }
                runCatching {
                    val bytes = resolver.openInputStream(uri)?.use { it.readBytes() } ?: error("فایل خوانده نشد")
                    val decoded = TextDecoding.decode(bytes)
                    val info = dictionaries.importText(fileName.substringBeforeLast('.'), fileName, decoded.text)
                    val enc = if (decoded.encoding == TextDecoding.Detected.WINDOWS_1256) "، Windows-1256" else ""
                    "«${info.name}» (${info.wordCount} کلمه$enc)"
                }.onSuccess { ok.add(it) }.onFailure { failed.add("«$fileName»: ${it.message}") }
                refreshDictionaries()
            }
            val msg = buildString {
                if (ok.isNotEmpty()) append("اضافه شد: ").append(ok.joinToString("، "))
                if (failed.isNotEmpty()) { if (isNotEmpty()) append(" — "); append("ناموفق: ").append(failed.joinToString("، ")) }
            }
            _state.update { it.copy(importing = null, message = msg) }
        }
    }

    private fun displayName(resolver: ContentResolver, uri: Uri): String =
        runCatching {
            resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (c.moveToFirst() && i >= 0) c.getString(i) else null
            }
        }.getOrNull() ?: uri.lastPathSegment?.substringAfterLast('/') ?: "dictionary.txt"

    /** دانلود فرهنگ لغت آنلاین — فقط وقتی کاربر دکمهاش را بزند */
    fun downloadOnline(src: ir.harfchin.dictionary.OnlineSource) {
        if (_state.value.importing != null) return
        scope.launch(Dispatchers.IO) {
            try {
                _state.update { it.copy(importing = ImportProgress(0, 1, "دانلود «${src.title}»", 0f)) }
                val bytes = ir.harfchin.dictionary.OnlineDictionaries.download(src) { p ->
                    _state.update { it.copy(importing = ImportProgress(0, 1, "دانلود «${src.title}»", if (p < 0) null else p)) }
                }
                _state.update { it.copy(importing = ImportProgress(0, 1, "پردازش «${src.title}»", null)) }
                val text = ir.harfchin.dictionary.OnlineDictionaries.prepare(src, TextDecoding.decode(bytes).text)
                val fileName = if (src.dropPhrases) src.fileName.substringBeforeLast('.') + ".txt" else src.fileName
                val info = dictionaries.importText(src.title, fileName, text, sourceId = src.id)
                refreshDictionaries()
                _state.update { it.copy(importing = null, message = "✅ «${info.name}» با ${info.wordCount} کلمه اضافه شد") }
            } catch (e: Exception) {
                _state.update { it.copy(importing = null, message = "❌ ${e.message ?: "دانلود ناموفق بود"}") }
            }
        }
    }

    fun toggleDictionary(id: String, enabled: Boolean) = scope.launch(Dispatchers.IO) {
        dictionaries.setEnabled(id, enabled); refreshDictionaries()
    }

    fun deleteDictionary(id: String) = scope.launch(Dispatchers.IO) {
        dictionaries.delete(id); refreshDictionaries()
    }

    // ---------------- اسکن و حل ----------------

    /**
     * اسکن یکضربهای: کل صفحه گرفته میشود و ۱۶ کاشی چوبی خودکار پیدا میشوند (روی هر ۷ اسکرینشات واقعی: ۱۶ از ۱۶).
     * اگر پیدا نشد، به برش کادر ذخیرهشده برمیگردیم. true یعنی جدول خودکار پیدا شد.
     */
    fun processFullScreen(full: Bitmap, fallback: android.graphics.Rect?, profile: String): Boolean {
        val px = IntArray(full.width * full.height); full.getPixels(px, 0, full.width, 0, 0, full.width, full.height)
        val found = ir.harfchin.ocr.WoodTileFinder.find(px, full.width, full.height)
        val crop: Bitmap = if (found != null) {
            val x0 = found.minOf { it.x }; val y0 = found.minOf { it.y }
            val x1 = found.maxOf { it.x + it.w }; val y1 = found.maxOf { it.y + it.h }
            val pad = ((x1 - x0) * 0.02f).toInt()
            val x = (x0 - pad).coerceAtLeast(0); val y = (y0 - pad).coerceAtLeast(0)
            Bitmap.createBitmap(full, x, y, (x1 + pad).coerceAtMost(full.width) - x, (y1 + pad).coerceAtMost(full.height) - y)
        } else if (fallback != null) {
            val x = fallback.left.coerceIn(0, full.width - 1); val y = fallback.top.coerceIn(0, full.height - 1)
            Bitmap.createBitmap(full, x, y, fallback.width().coerceIn(1, full.width - x), fallback.height().coerceIn(1, full.height - y))
        } else full
        processCapture(crop, profile)
        return found != null
    }

    fun processCapture(bmp: Bitmap, profile: String) {
        scanJob?.cancel(); solveJob?.cancel()
        _state.update { it.copy(busy = true, lastCapture = bmp, message = null) }
        scanJob = scope.launch {
            val px = IntArray(bmp.width * bmp.height); bmp.getPixels(px, 0, bmp.width, 0, 0, bmp.width, bmp.height)
            val s = _state.value.settings
            templates.activeProfile = profile
            // تنظیمات OCR از رابط حذف شد؛ همیشه مقادیر پیشفرض (مقادیر قدیمی ذخیرهشده مثل وضوح ۱٫۵ نادیده گرفته میشوند)
            engine.settings = OcrEngine.Settings()
            val res = runCatching { recognizer.recognize(GrayImage.fromArgb(px, bmp.width, bmp.height), px) }
            res.onSuccess { r ->
                val unsure = r.grid.tiles.count { it.needsReview }
                _state.update {
                    it.copy(grid = r.grid, glyphs = r.glyphs, busy = false, words = emptyList(), selectedWord = null,
                        message = if (unsure > 0) "$unsure خانه نیاز به تأیید دارد (زرد)" else null)
                }
                if (unsure == 0) solve()
            }.onFailure { e -> _state.update { it.copy(busy = false, message = "خطا در پردازش: ${e.message}") } }
        }
    }

    /** اصلاح یا تأیید دستی یک خانه؛ نمونه حرف برای یادگیری ذخیره میشود. */
    fun setTile(index: Int, letter: String, multiplier: Int? = null) {
        val st = _state.value
        val old = st.grid.tiles[index]
        if (letter.isEmpty()) return
        val tile = Tile(letter, multiplier ?: old.multiplier, 1f, old.alternatives, needsReview = false)
        val glyph = st.glyphs[index]
        // فقط وقتی حرف تأیید/اصلاح شده نمونه ذخیره شود (نه وقتی فقط امتیاز عوض شده)
        val letterConfirmed = multiplier == null || letter != old.letter || old.needsReview
        if (glyph != null && letter.length == 1 && letterConfirmed) {
            scope.launch(Dispatchers.IO) { templates.addUserSample(st.settings.profile, letter, glyph) }
        }
        solveJob?.cancel()
        _state.update { it.copy(grid = it.grid.with(index, tile), words = emptyList(), selectedWord = null, busy = false) }
        // وقتی آخرین خانه زرد تأیید شد، خودکار حل کن
        val g = _state.value.grid
        if (g.isComplete && g.tiles.none { it.needsReview }) solve()
    }

    /** ورود دستی: نرمالسازی (ي→ی، ك→ک و ...) و امتیاز پیشفرض «بازم بازی» (حروف کمیاب = ۲) */
    fun setGridText(text: String) {
        val letters = ir.harfchin.core.PersianNormalizer.normalize(text).filter { it in ir.harfchin.core.PersianNormalizer.ALPHABET }
        if (letters.length != 16) {
            _state.update { it.copy(message = "دقیقاً ۱۶ حرف فارسی لازم است (الان ${letters.length} حرف)") }; return
        }
        val rare = "قعگکخفپشجز"
        val scores = IntArray(16) { if (letters[it] in rare) 2 else 1 }
        _state.update { it.copy(grid = Grid.fromRtlRows(letters, scores), glyphs = List(16) { null }, words = emptyList(), selectedWord = null) }
        solve()
    }

    fun solve() {
        val st = _state.value
        if (!st.grid.isComplete) { _state.update { it.copy(message = "همه ۱۶ خانه باید مشخص باشند") }; return }
        if (st.dictionaries.none { it.enabled }) { _state.update { it.copy(message = "هیچ فرهنگ لغت فعالی وجود ندارد") }; return }
        solveJob?.cancel()
        _state.update { it.copy(busy = true) }
        solveJob = scope.launch {
            val trie = dictionaries.activeTrie()
            val cfg = WordSolver.Config(
                minLength = 2,   // تنظیمات حذف شد: همه کلمات ۲ حرفی به بالا (کوتاهها خودبهخود پایین فهرست میروند)
                // قانون «بازم بازی» ثابت است: امتیاز کلمه = جمع عدد گوشه کاشیها (تنظیمات قدیمی ذخیرهشده نادیده گرفته میشوند)
                multiplierMode = MultiplierMode.LETTER,
                letterValues = emptyMap()
            )
            if (trie.size == 0) {
                _state.update { it.copy(busy = false, message = "فرهنگ لغت خالی است؛ از تب «فرهنگ لغت» یک فایل وارد یا فعال کنید") }
                return@launch
            }
            val hasRare = st.dictionaries.any { it.enabled && it.sourceId == "dehkhoda" }
            val common = if (hasRare) dictionaries.commonWords() else emptySet()
            val words = WordSolver(trie).solve(st.grid, cfg)
                .map { if (hasRare && it.word !in common) it.copy(rare = true) else it }
                .sortedWith(ir.harfchin.solver.TopWords.ORDER)
            val warn = if (st.grid.tiles.any { it.needsReview }) " — برخی خانه‌ها تأیید نشده‌اند" else ""
            // اگر وسط حل، جدول عوض شده باشد، نتیجه قدیمی نمایش داده نشود
            if (_state.value.grid != st.grid) return@launch
            _state.update { it.copy(words = words, busy = false, message = "${words.size} کلمه (بلندترین: ${words.maxOfOrNull { w -> w.word.length } ?: 0} حرف) از ${trie.size} کلمه فرهنگ لغت$warn") }
        }
    }

    fun select(w: FoundWord?) = _state.update { it.copy(selectedWord = w) }
    fun clearMessage() = _state.update { it.copy(message = null) }
}
