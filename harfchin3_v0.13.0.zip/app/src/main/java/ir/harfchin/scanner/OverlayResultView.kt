package ir.harfchin.scanner

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import ir.harfchin.core.PersianNormalizer
import ir.harfchin.core.model.FoundWord
import ir.harfchin.pipeline.ScanPipeline
import ir.harfchin.scanner.OverlayStyle as St
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

/**
 * پنل کامل شناور (پایین صفحه):
 *  سرصفحه: عنوان و وضعیت · «حل» · ⌄ جمع کردن · ⏻ خروج
 *  بدنه: جدول (لمس خانه = اصلاح) | فهرست شماره‌دار کلمات (لمس = نمایش مسیر)
 *  اصلاح خانه: پیشنهادها، امتیاز، همه حروف — با ستون‌بندی بر اساس عرض واقعی
 */
@SuppressLint("ViewConstructor")
class OverlayResultView(ctx: Context, private val pipeline: ScanPipeline, private val onClose: () -> Unit) : LinearLayout(ctx) {
    /** دکمه ⌄: بستن پنل و کلمات کنار ذره‌بین */
    var onCollapseAll: (() -> Unit)? = null

    private val gridView = GridLayout(ctx).apply { columnCount = 4; layoutDirection = View.LAYOUT_DIRECTION_LTR }
    private val list = LinearLayout(ctx).apply { orientation = VERTICAL }
    private val scroll = ScrollView(ctx).apply { addView(list); isVerticalScrollBarEnabled = false }
    private val status = St.text(ctx, "", 12f, SUB).apply { maxLines = 1; ellipsize = TextUtils.TruncateAt.END }
    private val selWord = St.text(ctx, "", 15f, Color.WHITE, true).apply { gravity = Gravity.CENTER }
    private var job: Job? = null
    private var picking = -1
    private fun dp(v: Int) = St.dp(context, v.toFloat()).toInt()

    init {
        orientation = VERTICAL
        layoutDirection = View.LAYOUT_DIRECTION_RTL
        background = GradientDrawable().apply {
            setColor(St.CREAM)
            val r = St.dp(ctx, 24f); cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f)
        }
        clipToOutline = true
        elevation = St.dp(ctx, 16f)
        setPadding(0, dp(6), 0, 0)

        addView(View(ctx).apply { background = St.rounded(ctx, 0x33000000, 3f) },
            LayoutParams(dp(36), dp(4)).apply { gravity = Gravity.CENTER_HORIZONTAL; bottomMargin = dp(6) })

        // سرصفحه
        val head = LinearLayout(ctx).apply { orientation = HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(14), dp(2), dp(10), dp(10)) }
        val titles = LinearLayout(ctx).apply { orientation = VERTICAL }
        titles.addView(St.text(ctx, "حرف\u200cچین", 17f, St.PLUM, true))
        titles.addView(status)
        head.addView(titles, LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f))
        head.addView(St.pill(ctx, "🔍 حل", St.gradient(ctx, intArrayOf(St.MINT, 0xFF26A69A.toInt()), 12f), sizeSp = 14f) {
            picking = -1; pipeline.solve()
        }.apply { setPadding(dp(14), dp(8), dp(14), dp(8)) })
        head.addView(iconBtn("⌄", 0x14000000, St.INK) { onCollapseAll?.invoke() ?: onClose() }, iconLp())
        head.addView(iconBtn("⏻", 0x1FE53935, 0xFFD32F2F.toInt()) { ScreenCaptureService.instance?.stopSelf() }, iconLp())
        addView(head, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT))
        addView(View(ctx).apply { setBackgroundColor(LINE) }, LayoutParams(LayoutParams.MATCH_PARENT, dp(1)))

        // بدنه
        val body = LinearLayout(ctx).apply { orientation = HORIZONTAL; setPadding(dp(10), dp(10), dp(10), dp(8)) }
        val board = LinearLayout(ctx).apply {
            orientation = VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            background = St.rounded(ctx, St.PLUM, 18f); setPadding(dp(6), dp(6), dp(6), dp(6))
        }
        board.addView(gridView)
        board.addView(selWord, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT).apply { topMargin = dp(4) })
        body.addView(board, LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT))
        body.addView(scroll, LayoutParams(0, LayoutParams.MATCH_PARENT, 1f).apply { marginStart = dp(10) })
        addView(body, LayoutParams(LayoutParams.MATCH_PARENT, 0, 1f))
    }

    private fun iconLp() = LayoutParams(dp(36), dp(36)).apply { marginStart = dp(6) }

    private fun iconBtn(t: String, bg: Int, fg: Int, f: () -> Unit) = St.text(context, t, 16f, fg, true).apply {
        gravity = Gravity.CENTER
        background = St.pressable(context, St.rounded(context, bg, 11f), 11f)
        isClickable = true; setOnClickListener { f() }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        job = CoroutineScope(Dispatchers.Main).launch {
            pipeline.state.map { listOf(it.grid, it.words, it.selectedWord, it.busy, it.message) }
                .distinctUntilChanged().collect { render() }
        }
    }

    override fun onDetachedFromWindow() { job?.cancel(); super.onDetachedFromWindow() }

    private fun render() {
        val s = pipeline.state.value
        val unsure = s.grid.tiles.count { it.needsReview }
        status.text = when {
            s.busy -> "در حال پردازش…"
            unsure > 0 -> "$unsure خانه مردد — روی خانه زرد بزنید"
            s.words.isNotEmpty() -> "${s.words.size} کلمه پیدا شد"
            else -> s.message ?: "روی هر خانه بزنید تا اصلاح شود"
        }
        status.setTextColor(if (unsure > 0 && !s.busy) 0xFFB7791F.toInt() else SUB)
        renderGrid(s.selectedWord)
        if (picking >= 0) return
        renderWords(s.words, s.selectedWord)
    }

    private fun renderGrid(sel: FoundWord?) {
        val g = pipeline.state.value.grid
        val path = sel?.path.orEmpty()
        selWord.text = sel?.let { "${it.word} · ${it.score}" } ?: ""
        selWord.visibility = if (sel != null) View.VISIBLE else View.GONE
        gridView.removeAllViews()
        g.tiles.forEachIndexed { i, t ->
            val order = path.indexOf(i)
            val bg = when {
                order == 0 -> St.PATH_START; order > 0 -> St.PATH
                i == picking -> St.SKY; t.needsReview -> St.UNSURE; else -> St.TILE
            }
            val layers = LayerDrawable(arrayOf<Drawable>(St.rounded(context, St.TILE_EDGE, 10f), St.rounded(context, bg, 10f)))
            layers.setLayerInset(1, 0, 0, 0, dp(3))
            val cell = FrameLayout(context).apply {
                background = St.pressable(context, layers, 10f)
                isClickable = true; setOnClickListener { pick(i) }
            }
            val fg = if (order >= 0 || i == picking) Color.WHITE else St.INK
            cell.addView(St.text(context, t.letter.ifEmpty { "؟" }, 19f, fg, true).apply {
                gravity = Gravity.CENTER; setPadding(0, 0, 0, dp(3))
            }, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
            if (t.multiplier > 1) cell.addView(St.text(context, "${t.multiplier}", 9f, Color.WHITE, true).apply {
                gravity = Gravity.CENTER
                background = St.rounded(context, if (t.multiplier >= 3) St.BERRY else St.CORAL, 7f)
            }, FrameLayout.LayoutParams(dp(14), dp(14), Gravity.TOP or Gravity.END).apply { setMargins(0, dp(2), dp(2), 0) })
            gridView.addView(cell, GridLayout.LayoutParams().apply {
                width = dp(CELL); height = dp(CELL); setMargins(dp(2), dp(2), dp(2), dp(2))
            })
        }
    }

    private fun renderWords(words: List<FoundWord>, sel: FoundWord?) {
        list.removeAllViews()
        if (words.isEmpty()) {
            list.addView(St.text(context, if (pipeline.state.value.busy) "…" else "برای دیدن کلمه\u200cها «حل» را بزنید", 13f, SUB).apply {
                gravity = Gravity.CENTER; setPadding(dp(8), dp(28), dp(8), 0)
            }, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT))
            return
        }
        words.take(200).forEachIndexed { k, w ->
            list.addView(wordRow(k, w, w == sel), LayoutParams(LayoutParams.MATCH_PARENT, dp(40)).apply { bottomMargin = dp(5) })
        }
    }

    private fun tint(c: Int, a: Int) = (c and 0x00FFFFFF) or (a shl 24)

    private fun wordRow(k: Int, w: FoundWord, selected: Boolean): View {
        val lc = St.lengthColor(w.word.length)
        val row = LinearLayout(context).apply {
            orientation = HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), 0, dp(6), 0)
            background = St.pressable(context,
                St.rounded(context, if (selected) tint(lc, 0x26) else Color.WHITE, 12f, if (selected) lc else LINE), 12f)
            isClickable = true; setOnClickListener { pipeline.select(if (selected) null else w) }
        }
        row.addView(St.text(context, "${k + 1}", 11f, SUB).apply { gravity = Gravity.CENTER },
            LayoutParams(dp(22), LayoutParams.WRAP_CONTENT))
        row.addView(St.text(context, w.word, 16f, St.INK, true).apply { maxLines = 1 },
            LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(4) })
        if (w.usesUncertainTile) row.addView(St.text(context, "⚠", 12f, 0xFFE0A100.toInt()).apply { setPadding(dp(3), 0, dp(3), 0) })
        if (w.rare) row.addView(St.text(context, "🎲", 11f, St.INK).apply { setPadding(dp(3), 0, dp(3), 0) })
        row.addView(St.text(context, "${w.word.length}", 11f, lc, true).apply {
            gravity = Gravity.CENTER; background = St.rounded(context, tint(lc, 0x22), 8f)
        }, LayoutParams(dp(22), dp(20)).apply { marginStart = dp(4) })
        row.addView(St.text(context, "${w.score}", 13f, Color.WHITE, true).apply {
            gravity = Gravity.CENTER; background = St.rounded(context, St.PLUM, 9f)
        }, LayoutParams(dp(32), dp(24)).apply { marginStart = dp(4) })
        return row
    }

    /** اصلاح خانه: پیشنهادهای OCR، امتیاز، همه حروف */
    private fun pick(i: Int) {
        picking = i
        val t = pipeline.state.value.grid.tiles[i]
        renderGrid(pipeline.state.value.selectedWord)
        list.removeAllViews()
        val cols = letterColumns()
        fun done(l: String, m: Int?) { picking = -1; pipeline.setTile(i, l, m); render() }
        fun section(s: String) {
            list.addView(St.text(context, s, 12f, SUB, true).apply { setPadding(dp(2), dp(10), dp(2), dp(4)) })
        }
        fun newGrid() = GridLayout(context).apply { columnCount = cols }
        fun cellLp() = GridLayout.LayoutParams().apply { width = dp(42); height = dp(42); setMargins(dp(2), dp(2), dp(2), dp(2)) }
        fun cell(txt: String, bg: Int, fg: Int, stroke: Int?, size: Float, f: () -> Unit) = St.text(context, txt, size, fg, true).apply {
            gravity = Gravity.CENTER
            background = St.pressable(context, St.rounded(context, bg, 11f, stroke), 11f)
            isClickable = true; setOnClickListener { f() }
        }

        val top = LinearLayout(context).apply { orientation = HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        top.addView(St.text(context, "اصلاح خانه ${i + 1}", 15f, St.INK, true), LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f))
        top.addView(cell("✕", 0x14000000, St.INK, null, 14f) { picking = -1; render() }, LayoutParams(dp(32), dp(32)))
        list.addView(top)

        if (t.alternatives.isNotEmpty()) {
            section("پیشنهاد")
            val ag = newGrid()
            val colors = intArrayOf(St.MINT, St.SKY, St.GRAPE, St.BERRY)
            t.alternatives.forEachIndexed { k, l -> ag.addView(cell(l, colors[k % 4], Color.WHITE, null, 19f) { done(l, null) }, cellLp()) }
            list.addView(ag)
        }

        section("امتیاز خانه")
        val mg = newGrid()
        listOf(1 to St.SKY, 2 to St.CORAL, 3 to St.BERRY).forEach { (m, col) ->
            val on = t.multiplier == m
            mg.addView(cell("$m", if (on) col else Color.WHITE, if (on) Color.WHITE else col, col, 16f) {
                if (t.letter.isNotEmpty()) done(t.letter, m)
            }, cellLp())
        }
        list.addView(mg)

        section("همه حروف")
        val lg = newGrid()
        PersianNormalizer.TILE_LETTERS.forEach { l ->
            val cur = l == t.letter
            lg.addView(cell(l, if (cur) St.PLUM else St.TILE, if (cur) Color.WHITE else St.INK, St.TILE_EDGE, 17f) { done(l, null) }, cellLp())
        }
        list.addView(lg)
        scroll.scrollTo(0, 0)
    }

    /** چند خانه ۴۶dp در عرض واقعی فهرست جا می‌شود */
    private fun letterColumns(): Int {
        val w = scroll.width.takeIf { it > 0 } ?: (resources.displayMetrics.widthPixels - dp(220))
        return (w / dp(46)).coerceIn(3, 8)
    }

    companion object {
        private const val SUB = 0xFF8A7F94.toInt()
        private const val LINE = 0xFFEAE2D6.toInt()
        private const val CELL = 40
    }
}
