package ir.harfchin.scanner

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color
import android.graphics.Paint
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import ir.harfchin.pipeline.ScanPipeline
import ir.harfchin.scanner.OverlayStyle as St
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

/**
 * کارت جمعوجور کنار ذره‌بین:
 *  سرصفحه (عنوان + 🎯 کادر + ⌄ جمع کردن) · ردیف حرف مردد · ۶ کلمه برتر با امتیاز · «همه n کلمه»
 * لمس کلمه = علامت «زده شد» (کمرنگ و خط‌خورده) و نمایش مسیرش.
 */
@SuppressLint("ViewConstructor")
class TopWordsView(
    ctx: Context,
    private val pipeline: ScanPipeline,
    private val openFull: () -> Unit,
    private val onCollapse: () -> Unit = {},
    private val onSetupFrame: () -> Unit = {},
    private val hasSavedFrame: () -> Boolean = { true }
) : LinearLayout(ctx) {
    private var collapsed = false
    private var job: Job? = null
    private val used = HashSet<String>()
    private var lastGrid: Any? = null
    private fun dp(v: Int) = St.dp(context, v.toFloat()).toInt()

    init {
        orientation = VERTICAL
        layoutDirection = View.LAYOUT_DIRECTION_RTL
        background = St.rounded(ctx, CARD, 18f)
        elevation = St.dp(ctx, 10f)
        setPadding(dp(10), dp(8), dp(10), dp(8))
        minimumWidth = dp(184)
        visibility = View.GONE
    }

    fun collapse() { collapsed = true; removeAllViews(); visibility = View.GONE }

    /** با هر ضربه روی ذره‌بین دوباره باز می‌شود، حتی اگر جدول همان قبلی باشد */
    fun expand() { collapsed = false; render() }

    fun refresh() = render()

    @Suppress("UNUSED_PARAMETER")
    fun alignRight(r: Boolean) { /* کارت عرض ثابت دارد */ }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        job = CoroutineScope(Dispatchers.Main).launch {
            pipeline.state.map { Triple(it.grid, it.words, it.busy) }.distinctUntilChanged().collect { (g, _, _) ->
                if (g != lastGrid) { used.clear(); lastGrid = g; collapsed = false }
                render()
            }
        }
    }

    override fun onDetachedFromWindow() { job?.cancel(); super.onDetachedFromWindow() }

    private fun icon(t: String, bg: Int, f: () -> Unit) = St.text(context, t, 13f, Color.WHITE, true).apply {
        gravity = Gravity.CENTER
        background = St.pressable(context, St.rounded(context, bg, 9f), 9f)
        isClickable = true; setOnClickListener { f() }
    }

    private fun iconLp() = LayoutParams(dp(28), dp(28)).apply { marginStart = dp(4) }
    private fun fullLp() = LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT)
    private fun hint(s: String) = St.text(context, s, 12f, SUB).apply { setPadding(0, dp(6), 0, dp(2)) }

    private fun render() {
        removeAllViews()
        if (collapsed) { visibility = View.GONE; return }
        visibility = View.VISIBLE
        val st = pipeline.state.value
        val words = st.words
        val unsure = st.grid.tiles.count { it.needsReview }
        val saved = hasSavedFrame()

        // سرصفحه
        val head = LinearLayout(context).apply { orientation = HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(St.text(context, if (words.isEmpty()) "حرف\u200cچین" else "کلمات برتر", 13f, SUB, true),
            LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f))
        head.addView(icon("🎯", if (saved) 0x22FFFFFF else St.MINT) { onSetupFrame() }, iconLp())
        if (words.isNotEmpty() || unsure > 0) head.addView(icon("⌄", 0x22FFFFFF) { onCollapse() }, iconLp())
        addView(head, fullLp())

        if (!saved) addView(hint("یک بار کادر را روی جدول بگذارید و «تأیید و ذخیره» را بزنید"), fullLp())
        if (st.busy) { addView(hint("در حال اسکن…"), fullLp()); return }
        if (words.isEmpty() && unsure == 0) {
            if (saved) addView(hint("برای اسکن، ذره\u200cبین را بزنید"), fullLp())
            return
        }

        // حروف مردد
        if (unsure > 0) addView(LinearLayout(context).apply {
            orientation = HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            background = St.pressable(context, St.rounded(context, 0x33FFD54F, 10f), 10f)
            setPadding(dp(8), dp(6), dp(8), dp(6)); isClickable = true; setOnClickListener { openFull() }
            addView(St.text(context, "⚠ $unsure حرف مردد", 12f, St.UNSURE, true), LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f))
            addView(St.text(context, "اصلاح ›", 12f, Color.WHITE, true))
        }, fullLp().apply { topMargin = dp(6) })

        if (words.isEmpty()) return
        addView(View(context).apply { setBackgroundColor(0x22FFFFFF) },
            LayoutParams(LayoutParams.MATCH_PARENT, dp(1)).apply { topMargin = dp(6); bottomMargin = dp(2) })

        // ۶ کلمه برتر
        val top = ir.harfchin.solver.TopWords.pick(words, used)
        top.forEach { w ->
            val done = w.word in used
            val lc = St.lengthColor(w.word.length)
            val row = LinearLayout(context).apply {
                orientation = HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                background = St.pressable(context,
                    St.rounded(context, if (w == st.selectedWord) 0x22FFFFFF else Color.TRANSPARENT, 10f), 10f)
                setPadding(dp(4), 0, dp(2), 0); isClickable = true
                alpha = if (done) 0.45f else 1f
                setOnClickListener {
                    if (done) used.remove(w.word) else used.add(w.word)
                    pipeline.select(w); render()
                }
            }
            row.addView(View(context).apply { background = St.rounded(context, lc, 2f) }, LayoutParams(dp(3), dp(18)))
            row.addView(St.text(context, w.word, 16f, Color.WHITE, true).apply {
                maxLines = 1; setPadding(dp(8), 0, dp(4), 0)
                if (done) paintFlags = paintFlags or Paint.STRIKE_THRU_TEXT_FLAG
            }, LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f))
            if (w.usesUncertainTile) row.addView(St.text(context, "⚠", 11f, St.UNSURE, true).apply { setPadding(dp(2), 0, dp(2), 0) })
            if (w.rare) row.addView(St.text(context, "🎲", 10f, Color.WHITE).apply { setPadding(dp(2), 0, dp(2), 0) })
            row.addView(St.text(context, "${w.score}", 13f, Color.WHITE, true).apply {
                gravity = Gravity.CENTER
                background = St.rounded(context, if (done) 0x33FFFFFF else St.CORAL, 8f)
            }, LayoutParams(dp(30), dp(22)).apply { marginStart = dp(4) })
            addView(row, LayoutParams(LayoutParams.MATCH_PARENT, dp(34)))
        }

        if (words.size > top.size) addView(St.text(context, "همه ${words.size} کلمه ›", 12f, LINK, true).apply {
            gravity = Gravity.CENTER; setPadding(0, dp(8), 0, dp(4))
            background = St.pressable(context, St.rounded(context, Color.TRANSPARENT, 10f), 10f)
            isClickable = true; setOnClickListener { openFull() }
        }, fullLp().apply { topMargin = dp(2) })
    }

    companion object {
        private const val CARD = 0xF21E1A24.toInt()
        private const val SUB = 0xFFA79DB0.toInt()
        private const val LINK = 0xFFC6A4E8.toInt()
    }
}
